﻿
namespace ProjectGroup
{
    partial class FormKhoNhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label maSPLabel;
            System.Windows.Forms.Label tenspLabel;
            System.Windows.Forms.Label soluongLabel;
            System.Windows.Forms.Label gianhapLabel;
            System.Windows.Forms.Label ngaynhapLabel;
            System.Windows.Forms.Label nhaccLabel;
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.maSPTextBox = new System.Windows.Forms.TextBox();
            this.tenspTextBox = new System.Windows.Forms.TextBox();
            this.soluongTextBox = new System.Windows.Forms.TextBox();
            this.gianhapTextBox = new System.Windows.Forms.TextBox();
            this.ngaynhapDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.nhaccTextBox = new System.Windows.Forms.TextBox();
            this.btThoat = new System.Windows.Forms.Button();
            this.btXoa = new System.Windows.Forms.Button();
            this.btTimkiem = new System.Windows.Forms.Button();
            this.btThem = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.khoDataGridView = new System.Windows.Forms.DataGridView();
            maSPLabel = new System.Windows.Forms.Label();
            tenspLabel = new System.Windows.Forms.Label();
            soluongLabel = new System.Windows.Forms.Label();
            gianhapLabel = new System.Windows.Forms.Label();
            ngaynhapLabel = new System.Windows.Forms.Label();
            nhaccLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.khoDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(maSPLabel);
            this.groupBox1.Controls.Add(this.maSPTextBox);
            this.groupBox1.Controls.Add(tenspLabel);
            this.groupBox1.Controls.Add(this.tenspTextBox);
            this.groupBox1.Controls.Add(soluongLabel);
            this.groupBox1.Controls.Add(this.soluongTextBox);
            this.groupBox1.Controls.Add(gianhapLabel);
            this.groupBox1.Controls.Add(this.gianhapTextBox);
            this.groupBox1.Controls.Add(ngaynhapLabel);
            this.groupBox1.Controls.Add(this.ngaynhapDateTimePicker);
            this.groupBox1.Controls.Add(nhaccLabel);
            this.groupBox1.Controls.Add(this.nhaccTextBox);
            this.groupBox1.Location = new System.Drawing.Point(65, 92);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(914, 158);
            this.groupBox1.TabIndex = 62;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin:";
            // 
            // maSPLabel
            // 
            maSPLabel.AutoSize = true;
            maSPLabel.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            maSPLabel.Location = new System.Drawing.Point(19, 39);
            maSPLabel.Name = "maSPLabel";
            maSPLabel.Size = new System.Drawing.Size(114, 21);
            maSPLabel.TabIndex = 49;
            maSPLabel.Text = "Mã sản phẩm:";
            // 
            // maSPTextBox
            // 
            this.maSPTextBox.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maSPTextBox.Location = new System.Drawing.Point(147, 33);
            this.maSPTextBox.Name = "maSPTextBox";
            this.maSPTextBox.Size = new System.Drawing.Size(285, 27);
            this.maSPTextBox.TabIndex = 50;
            // 
            // tenspLabel
            // 
            tenspLabel.AutoSize = true;
            tenspLabel.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            tenspLabel.Location = new System.Drawing.Point(16, 81);
            tenspLabel.Name = "tenspLabel";
            tenspLabel.Size = new System.Drawing.Size(119, 21);
            tenspLabel.TabIndex = 51;
            tenspLabel.Text = "Tên sản phẩm:";
            // 
            // tenspTextBox
            // 
            this.tenspTextBox.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tenspTextBox.Location = new System.Drawing.Point(147, 78);
            this.tenspTextBox.Name = "tenspTextBox";
            this.tenspTextBox.Size = new System.Drawing.Size(285, 27);
            this.tenspTextBox.TabIndex = 52;
            // 
            // soluongLabel
            // 
            soluongLabel.AutoSize = true;
            soluongLabel.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            soluongLabel.Location = new System.Drawing.Point(35, 121);
            soluongLabel.Name = "soluongLabel";
            soluongLabel.Size = new System.Drawing.Size(82, 21);
            soluongLabel.TabIndex = 53;
            soluongLabel.Text = "Số lượng:";
            // 
            // soluongTextBox
            // 
            this.soluongTextBox.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.soluongTextBox.Location = new System.Drawing.Point(147, 117);
            this.soluongTextBox.Name = "soluongTextBox";
            this.soluongTextBox.Size = new System.Drawing.Size(285, 27);
            this.soluongTextBox.TabIndex = 54;
            // 
            // gianhapLabel
            // 
            gianhapLabel.AutoSize = true;
            gianhapLabel.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            gianhapLabel.Location = new System.Drawing.Point(505, 30);
            gianhapLabel.Name = "gianhapLabel";
            gianhapLabel.Size = new System.Drawing.Size(81, 21);
            gianhapLabel.TabIndex = 55;
            gianhapLabel.Text = "Giá nhập:";
            // 
            // gianhapTextBox
            // 
            this.gianhapTextBox.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gianhapTextBox.Location = new System.Drawing.Point(602, 27);
            this.gianhapTextBox.Name = "gianhapTextBox";
            this.gianhapTextBox.Size = new System.Drawing.Size(294, 27);
            this.gianhapTextBox.TabIndex = 56;
            // 
            // ngaynhapLabel
            // 
            ngaynhapLabel.AutoSize = true;
            ngaynhapLabel.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ngaynhapLabel.Location = new System.Drawing.Point(494, 69);
            ngaynhapLabel.Name = "ngaynhapLabel";
            ngaynhapLabel.Size = new System.Drawing.Size(94, 21);
            ngaynhapLabel.TabIndex = 57;
            ngaynhapLabel.Text = "Ngày nhập:";
            // 
            // ngaynhapDateTimePicker
            // 
            this.ngaynhapDateTimePicker.CustomFormat = "dd/MM/yyyy";
            this.ngaynhapDateTimePicker.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ngaynhapDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.ngaynhapDateTimePicker.Location = new System.Drawing.Point(602, 69);
            this.ngaynhapDateTimePicker.Name = "ngaynhapDateTimePicker";
            this.ngaynhapDateTimePicker.Size = new System.Drawing.Size(171, 27);
            this.ngaynhapDateTimePicker.TabIndex = 58;
            // 
            // nhaccLabel
            // 
            nhaccLabel.AutoSize = true;
            nhaccLabel.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            nhaccLabel.Location = new System.Drawing.Point(477, 117);
            nhaccLabel.Name = "nhaccLabel";
            nhaccLabel.Size = new System.Drawing.Size(117, 21);
            nhaccLabel.TabIndex = 59;
            nhaccLabel.Text = "Nhà cung cấp:";
            // 
            // nhaccTextBox
            // 
            this.nhaccTextBox.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nhaccTextBox.Location = new System.Drawing.Point(602, 114);
            this.nhaccTextBox.Name = "nhaccTextBox";
            this.nhaccTextBox.Size = new System.Drawing.Size(294, 27);
            this.nhaccTextBox.TabIndex = 60;
            // 
            // btThoat
            // 
            this.btThoat.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btThoat.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThoat.Location = new System.Drawing.Point(810, 266);
            this.btThoat.Name = "btThoat";
            this.btThoat.Size = new System.Drawing.Size(87, 30);
            this.btThoat.TabIndex = 61;
            this.btThoat.Text = "Thoát";
            this.btThoat.UseVisualStyleBackColor = false;
            this.btThoat.Click += new System.EventHandler(this.btThoat_Click_1);
            // 
            // btXoa
            // 
            this.btXoa.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btXoa.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXoa.Location = new System.Drawing.Point(706, 266);
            this.btXoa.Name = "btXoa";
            this.btXoa.Size = new System.Drawing.Size(87, 30);
            this.btXoa.TabIndex = 60;
            this.btXoa.Text = "Xóa ";
            this.btXoa.UseVisualStyleBackColor = false;
            this.btXoa.Click += new System.EventHandler(this.btXoa_Click_1);
            // 
            // btTimkiem
            // 
            this.btTimkiem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btTimkiem.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTimkiem.Location = new System.Drawing.Point(592, 266);
            this.btTimkiem.Name = "btTimkiem";
            this.btTimkiem.Size = new System.Drawing.Size(97, 30);
            this.btTimkiem.TabIndex = 59;
            this.btTimkiem.Text = "Tìm kiếm";
            this.btTimkiem.UseVisualStyleBackColor = false;
            this.btTimkiem.Click += new System.EventHandler(this.btTimkiem_Click_1);
            // 
            // btThem
            // 
            this.btThem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btThem.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThem.Location = new System.Drawing.Point(481, 266);
            this.btThem.Name = "btThem";
            this.btThem.Size = new System.Drawing.Size(87, 30);
            this.btThem.TabIndex = 58;
            this.btThem.Text = "Thêm ";
            this.btThem.UseVisualStyleBackColor = false;
            this.btThem.Click += new System.EventHandler(this.btThem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(444, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 35);
            this.label1.TabIndex = 57;
            this.label1.Text = "Kho nhập";
            // 
            // khoDataGridView
            // 
            this.khoDataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.khoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.khoDataGridView.GridColor = System.Drawing.SystemColors.Control;
            this.khoDataGridView.Location = new System.Drawing.Point(74, 312);
            this.khoDataGridView.Name = "khoDataGridView";
            this.khoDataGridView.RowHeadersWidth = 51;
            this.khoDataGridView.RowTemplate.Height = 24;
            this.khoDataGridView.Size = new System.Drawing.Size(887, 311);
            this.khoDataGridView.TabIndex = 56;
            // 
            // FormKhoNhap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1044, 659);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btThoat);
            this.Controls.Add(this.btXoa);
            this.Controls.Add(this.btTimkiem);
            this.Controls.Add(this.btThem);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.khoDataGridView);
            this.Name = "FormKhoNhap";
            this.Text = "FormKhoNhap";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.khoDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox maSPTextBox;
        private System.Windows.Forms.TextBox tenspTextBox;
        private System.Windows.Forms.TextBox soluongTextBox;
        private System.Windows.Forms.TextBox gianhapTextBox;
        private System.Windows.Forms.DateTimePicker ngaynhapDateTimePicker;
        private System.Windows.Forms.TextBox nhaccTextBox;
        private System.Windows.Forms.Button btThoat;
        private System.Windows.Forms.Button btXoa;
        private System.Windows.Forms.Button btTimkiem;
        private System.Windows.Forms.Button btThem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView khoDataGridView;
    }
}