﻿
namespace ProjectGroup
{
    partial class FormTimKiemNV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TKtextBox = new System.Windows.Forms.TextBox();
            this.TimKiemdataGridView = new System.Windows.Forms.DataGridView();
            this.TroVebutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.TimKiemdataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TKtextBox
            // 
            this.TKtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.TKtextBox.Location = new System.Drawing.Point(234, 121);
            this.TKtextBox.Name = "TKtextBox";
            this.TKtextBox.Size = new System.Drawing.Size(154, 24);
            this.TKtextBox.TabIndex = 0;
            this.TKtextBox.TextChanged += new System.EventHandler(this.TKtextBox_TextChanged);
            // 
            // TimKiemdataGridView
            // 
            this.TimKiemdataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TimKiemdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TimKiemdataGridView.Location = new System.Drawing.Point(16, 32);
            this.TimKiemdataGridView.Name = "TimKiemdataGridView";
            this.TimKiemdataGridView.RowHeadersWidth = 51;
            this.TimKiemdataGridView.RowTemplate.Height = 24;
            this.TimKiemdataGridView.Size = new System.Drawing.Size(719, 180);
            this.TimKiemdataGridView.TabIndex = 2;
            this.TimKiemdataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.TimKiemdataGridView_CellContentClick);
            // 
            // TroVebutton
            // 
            this.TroVebutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TroVebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.TroVebutton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.TroVebutton.Location = new System.Drawing.Point(26, 24);
            this.TroVebutton.Name = "TroVebutton";
            this.TroVebutton.Size = new System.Drawing.Size(97, 36);
            this.TroVebutton.TabIndex = 3;
            this.TroVebutton.Text = "Trở về";
            this.TroVebutton.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(223, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(313, 32);
            this.label1.TabIndex = 4;
            this.label1.Text = "TÌM KIẾM NHÂN VIÊN";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.Location = new System.Drawing.Point(49, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Nhập tên nhân viên:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TimKiemdataGridView);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox1.Location = new System.Drawing.Point(26, 182);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(757, 242);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Hiển thị thông tin:";
            // 
            // FormTimKiemNV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TroVebutton);
            this.Controls.Add(this.TKtextBox);
            this.Name = "FormTimKiemNV";
            this.Text = "FormTimKiemNV";
            this.Load += new System.EventHandler(this.FormTimKiemNV_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TimKiemdataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TKtextBox;
        private System.Windows.Forms.DataGridView TimKiemdataGridView;
        private System.Windows.Forms.Button TroVebutton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}