﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class FormtimkiemKho : Form
    {
        public FormtimkiemKho()
        {
            InitializeComponent();
            HienThiGirdView1();
        }
        public void HienThiGirdView1()
        {
            DataTable dt = new DataTable();
            App_config configdb = new App_config();

            String sql = "SELECT maSP,tensp,soluong,gianhap,nhacc,";
            sql += " CONVERT(varchar, ngaynhap, 103) AS ngaynhap ";
            sql += " FROM Kho ";

            dt = configdb.SelectDb(sql);

            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "maSP";
            column1.HeaderText = "Mã SP";
            dataGridView.Columns.Add(column1);
            dataGridView.Columns[0].Width = 70;

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "tensp";
            column2.HeaderText = "Tên SP";
            dataGridView.Columns.Add(column2);
            dataGridView.Columns[1].Width = 150;

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "soluong";
            column3.HeaderText = "Số lượng";
            dataGridView.Columns.Add(column3);
            dataGridView.Columns[2].Width = 80;

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "gianhap";
            column4.HeaderText = "Giá nhập";
            dataGridView.Columns.Add(column4);
            dataGridView.Columns[3].Width = 80;

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.DataPropertyName = "nhacc";
            column5.HeaderText = "Nhà cung cấp";
            dataGridView.Columns.Add(column5);
            dataGridView.Columns[4].Width = 130;

            DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
            column6.DataPropertyName = "ngaynhap";
            column6.HeaderText = "Ngày nhập";
            dataGridView.Columns.Add(column6);
            dataGridView.Columns[5].Width = 100;

            dataGridView.DataSource = dt;
        }
        public void LoadGridByKeyword()
        {
            App_config configdb = new App_config();
            dataGridView.DataSource = configdb.SelectDb("SELECT *FROM Kho WHERE tenSP LIKE '%" + textBox1.Text + "%' ");
        }

        private void TKtextbox_TextChanged(object sender, EventArgs e)
        {
            LoadGridByKeyword();
        }

        private void FormtimkiemKho_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
