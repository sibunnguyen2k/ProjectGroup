﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class QuanliPhong : Form
    {
        public QuanliPhong()
        {
            InitializeComponent();
            hienthi();
            Load();
        }

        public void hienthi()
        {
            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            String sql = "SELECT soPhong , Tinhtrang.maTT, tenTT, Loaiphong.maLP,tenLP,gia FROM Phong";
            sql += " INNER JOIN Tinhtrang ON Tinhtrang.maTT= Phong.maTT";
            sql += " INNER JOIN Loaiphong ON Loaiphong.maLP = Phong.maLP";
            dt = configdb.SelectDb(sql);


            if (griddulieu.Rows.Count == null)
            {

                DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
                column.DataPropertyName = "soPhong";
                column.HeaderText = "Số Phòng";
                griddulieu.Columns.Add(column);

                DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
                column1.DataPropertyName = "Tingtrang.maTT";
                column1.HeaderText = "Mã TT";
                griddulieu.Columns.Add(column1);

                DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
                column2.DataPropertyName = "tenTT";
                column2.HeaderText = "Tình Trạng";
                griddulieu.Columns.Add(column2);

                DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
                column3.DataPropertyName = "Loaiphong.maLP";
                column3.HeaderText = "Mã LP";
                griddulieu.Columns.Add(column3);

                DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
                column4.DataPropertyName = "tenLP";
                column4.HeaderText = "Loại phòng";
                griddulieu.Columns.Add(column4);

                DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
                column5.DataPropertyName = "gia";
                column5.HeaderText = "Giá";
                griddulieu.Columns.Add(column5);

                griddulieu.DataSource = dt;
            }
            griddulieu.DataSource = dt;
        }
        private void Quản_Lí_Phòng_Load(object sender, EventArgs e)
        {
            

        }

        private void cbtt_DropDown(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            App_config app = new App_config();
            String sql = "SELECT maTT FROM Tinhtrang";
            dt = app.SelectDb(sql);
            cbtt.DataSource = new BindingSource(dt, null);
            cbtt.ValueMember = dt.Columns[0].ToString();
        }
        private void cbtt_TextChanged(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            App_config app = new App_config();
            String sql = "SELECT * FROM Tinhtrang WHERE maTT = '" + cbtt.Text + "'";
            dt = app.SelectDb(sql);
            if (dt.Rows.Count > 0)
            {
                txttt.Text = dt.Rows[0][1].ToString();
            }
        }


        public void Load()
        {
            DataTable dt = new DataTable();
            App_config app = new App_config();
            String sql = "SELECT * FROM Loaiphong";
            dt = app.SelectDb(sql);
            cblp.DataSource = new BindingSource(dt, null);
            cblp.DisplayMember = dt.Columns[1].ToString();
            cblp.ValueMember = dt.Columns[0].ToString();
            
        }
        //private void cblp_TextChanged(object sender, EventArgs e)
        //{
        //    DataTable dt = new DataTable();
        //    App_config app = new App_config();
        //    String sql = "SELECT * FROM Loaiphong WHERE maLP = '" + cblp.Text + "'";
        //    dt = app.SelectDb(sql);

        //}

        private void btthem_Click(object sender, EventArgs e)
        {
            App_config configdb = new App_config();
            String sql = "INSERT INTO Phong (soPhong,maTT,maLP)";
            sql += " VALUES (N' " + txtsophong.Text + "'";
            sql += "," + cbtt.SelectedValue + "";
            sql += ",N'" + cblp.SelectedValue + "'";
            sql += ")";

            int sosanh = configdb.InsertDb(sql);
            if (sosanh == 0)
            {
                MessageBox.Show("Không thêm được phòng!!!");
            }
            else if (sosanh == -1)
            {
                MessageBox.Show("Phòng này đã tồn tại ,vui lòng nhập lại!!!!");
            }
            else  MessageBox.Show("Đã thêm phòng thành công!!!!");
            hienthi();
        }

        private void btsua_Click(object sender, EventArgs e)
        {
            App_config app = new App_config();
            String sql = "UPDATE Phong set maTT= '" + cbtt.Text + "'";
            sql += ",maLP = N'" + cblp.SelectedValue + "'";
            sql += " WHERE soPhong = N'" + txtsophong.Text + "'";
            app.UpdateDB(sql);
            hienthi();
        }

        private void btxoa_Click(object sender, EventArgs e)
        {
            App_config app = new App_config();
            if (btxoa.Enabled == true)
            {
                DialogResult dialog = MessageBox.Show("Bạn có chắc chắn muốn xóa!!!", "Thông báo",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialog == DialogResult.Yes)
                {
                    string sql = "DELETE Phong WHERE (soPhong = N'" + txtsophong.Text + "')";
                    app.DeleteDB(sql);
                    hienthi();
                }
                else
                {
                    dialog = DialogResult.Cancel;
                }
            }
        }

        private void btthoat_Click(object sender, EventArgs e)
        {
            App_config app = new App_config();
            if (btthoat.Enabled == true)
            {
                DialogResult dialog = MessageBox.Show("Bạn có chắc chắn muốn thoát!!!", "Thông báo",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialog == DialogResult.Yes)
                {
                    Close();
                }
            }
        }

        private void griddulieu_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtsophong.Text = griddulieu.CurrentRow.Cells[0].Value.ToString();
            cbtt.Text = griddulieu.CurrentRow.Cells[1].Value.ToString();
            txttt.Text = griddulieu.CurrentRow.Cells[2].Value.ToString();
            cblp.Text = griddulieu.CurrentRow.Cells[4].Value.ToString();
            //txtlp.Text = griddulieu.CurrentRow.Cells[4].Value.ToString();
            //txtgia.Text = griddulieu.CurrentRow.Cells[5].Value.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}