﻿
namespace ProjectGroup
{
    partial class QuanLiDichVu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonThoatDV = new System.Windows.Forms.Button();
            this.buttonXoaDV = new System.Windows.Forms.Button();
            this.buttonSuaDV = new System.Windows.Forms.Button();
            this.buttonThemDV = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.maDVTextBox = new System.Windows.Forms.TextBox();
            this.tenDVTextBox = new System.Windows.Forms.TextBox();
            this.donViTextBox = new System.Windows.Forms.TextBox();
            this.giaDVTextBox = new System.Windows.Forms.TextBox();
            this.gridViewDichVu = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDichVu)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.groupBox1.Controls.Add(this.giaDVTextBox);
            this.groupBox1.Controls.Add(this.donViTextBox);
            this.groupBox1.Controls.Add(this.tenDVTextBox);
            this.groupBox1.Controls.Add(this.maDVTextBox);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.buttonThoatDV);
            this.groupBox1.Controls.Add(this.buttonXoaDV);
            this.groupBox1.Controls.Add(this.buttonSuaDV);
            this.groupBox1.Controls.Add(this.buttonThemDV);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(26, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1187, 275);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin Dịch vụ";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Location = new System.Drawing.Point(63, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 24);
            this.label1.TabIndex = 37;
            this.label1.Text = "Mã Dịch Vụ:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // buttonThoatDV
            // 
            this.buttonThoatDV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonThoatDV.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonThoatDV.Location = new System.Drawing.Point(869, 200);
            this.buttonThoatDV.Name = "buttonThoatDV";
            this.buttonThoatDV.Size = new System.Drawing.Size(153, 35);
            this.buttonThoatDV.TabIndex = 36;
            this.buttonThoatDV.Text = "Thoát";
            this.buttonThoatDV.UseVisualStyleBackColor = true;
            this.buttonThoatDV.Click += new System.EventHandler(this.buttonThoatDV_Click);
            // 
            // buttonXoaDV
            // 
            this.buttonXoaDV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonXoaDV.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonXoaDV.Location = new System.Drawing.Point(629, 200);
            this.buttonXoaDV.Name = "buttonXoaDV";
            this.buttonXoaDV.Size = new System.Drawing.Size(153, 35);
            this.buttonXoaDV.TabIndex = 35;
            this.buttonXoaDV.Text = "Xóa";
            this.buttonXoaDV.UseVisualStyleBackColor = true;
            this.buttonXoaDV.Click += new System.EventHandler(this.buttonXoaDV_Click);
            // 
            // buttonSuaDV
            // 
            this.buttonSuaDV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSuaDV.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSuaDV.Location = new System.Drawing.Point(405, 200);
            this.buttonSuaDV.Name = "buttonSuaDV";
            this.buttonSuaDV.Size = new System.Drawing.Size(153, 35);
            this.buttonSuaDV.TabIndex = 34;
            this.buttonSuaDV.Text = "Sửa";
            this.buttonSuaDV.UseVisualStyleBackColor = true;
            this.buttonSuaDV.Click += new System.EventHandler(this.buttonSuaDV_Click);
            // 
            // buttonThemDV
            // 
            this.buttonThemDV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonThemDV.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonThemDV.Location = new System.Drawing.Point(183, 200);
            this.buttonThemDV.Name = "buttonThemDV";
            this.buttonThemDV.Size = new System.Drawing.Size(153, 35);
            this.buttonThemDV.TabIndex = 33;
            this.buttonThemDV.Text = "Thêm";
            this.buttonThemDV.UseVisualStyleBackColor = true;
            this.buttonThemDV.Click += new System.EventHandler(this.buttonThemDV_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Location = new System.Drawing.Point(63, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 24);
            this.label2.TabIndex = 38;
            this.label2.Text = "Tên Dịch Vụ:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Location = new System.Drawing.Point(640, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 24);
            this.label3.TabIndex = 39;
            this.label3.Text = "Đơn Vị Tính:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Location = new System.Drawing.Point(640, 124);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 24);
            this.label4.TabIndex = 40;
            this.label4.Text = "Giá Dịch Vụ:";
            // 
            // maDVTextBox
            // 
            this.maDVTextBox.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.maDVTextBox.Enabled = false;
            this.maDVTextBox.ForeColor = System.Drawing.SystemColors.WindowText;
            this.maDVTextBox.Location = new System.Drawing.Point(205, 42);
            this.maDVTextBox.Name = "maDVTextBox";
            this.maDVTextBox.Size = new System.Drawing.Size(351, 30);
            this.maDVTextBox.TabIndex = 41;
            // 
            // tenDVTextBox
            // 
            this.tenDVTextBox.Location = new System.Drawing.Point(205, 121);
            this.tenDVTextBox.Name = "tenDVTextBox";
            this.tenDVTextBox.Size = new System.Drawing.Size(351, 30);
            this.tenDVTextBox.TabIndex = 42;
            // 
            // donViTextBox
            // 
            this.donViTextBox.Location = new System.Drawing.Point(805, 42);
            this.donViTextBox.Name = "donViTextBox";
            this.donViTextBox.Size = new System.Drawing.Size(351, 30);
            this.donViTextBox.TabIndex = 43;
            // 
            // giaDVTextBox
            // 
            this.giaDVTextBox.Location = new System.Drawing.Point(805, 121);
            this.giaDVTextBox.Name = "giaDVTextBox";
            this.giaDVTextBox.Size = new System.Drawing.Size(351, 30);
            this.giaDVTextBox.TabIndex = 44;
            // 
            // gridViewDichVu
            // 
            this.gridViewDichVu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridViewDichVu.Location = new System.Drawing.Point(26, 327);
            this.gridViewDichVu.Name = "gridViewDichVu";
            this.gridViewDichVu.RowHeadersWidth = 51;
            this.gridViewDichVu.RowTemplate.Height = 24;
            this.gridViewDichVu.Size = new System.Drawing.Size(1187, 373);
            this.gridViewDichVu.TabIndex = 6;
            this.gridViewDichVu.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gridViewDichVu_CellMouseClick);
            // 
            // QuanLiDichVu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1248, 774);
            this.Controls.Add(this.gridViewDichVu);
            this.Controls.Add(this.groupBox1);
            this.Name = "QuanLiDichVu";
            this.Text = "Quản Lí Dịch Vụ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDichVu)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonThemDV;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonThoatDV;
        private System.Windows.Forms.Button buttonXoaDV;
        private System.Windows.Forms.Button buttonSuaDV;
        private System.Windows.Forms.TextBox giaDVTextBox;
        private System.Windows.Forms.TextBox donViTextBox;
        private System.Windows.Forms.TextBox tenDVTextBox;
        private System.Windows.Forms.TextBox maDVTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView gridViewDichVu;
    }
}

