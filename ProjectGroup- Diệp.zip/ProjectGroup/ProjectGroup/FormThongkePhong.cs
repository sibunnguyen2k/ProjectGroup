﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class FormThongkePhong : Form
    {
        public FormThongkePhong()
        {
            InitializeComponent();
            HienthigridviewThongke();
        }

        public void HienthigridviewThongke()
        {
            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "maHD";
            column1.HeaderText = "Mã HD";
            ThongKedataGridView.Columns.Add(column1);

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "maPT";
            column3.HeaderText = "Mã PT";
            ThongKedataGridView.Columns.Add(column3);

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "ngayTT";
            column4.HeaderText = "Ngày thanh toán";
            ThongKedataGridView.Columns.Add(column4);

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.DataPropertyName = "tongTien";
            column5.HeaderText = "Tổng tiền";
            ThongKedataGridView.Columns.Add(column5);

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "maNVTT";
            column2.HeaderText = "Mã nhân viên thanh toán";
            ThongKedataGridView.Columns.Add(column2);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dlr = MessageBox.Show("Bạn muốn thoát chương trình?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dlr == DialogResult.Yes) this.Close();
        }

        private void FormThongkePhong_Load(object sender, EventArgs e)
        {
        }

        private void ThongKebutton_Click(object sender, EventArgs e)
        {

            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            String sql = "SELECT maHD,maPT,ngayTT,tongTien,maNVTT";
            sql += " FROM Hoadon";
            //sql += "WHERE ngayDi BETWEEN " + TuNgay.Text + "AND" + denNgay.Text;
            sql += " WHERE (ngayTT >=   CONVERT(datetime, '" + TuNgay.Value.Date + "', 102)  AND ngayTT <= CONVERT(datetime, '" + denNgay.Value.Date + "', 102))";
            dt = configdb.SelectDb(sql);
            ThongKedataGridView.DataSource = dt;
            TinhtongDoanhthu();
        }

        public void TinhtongDoanhthu()
        {
            int sc = ThongKedataGridView.Rows.Count;
            float tongtien = 0;
            for (int i = 0; i < sc - 1; i++)
            { tongtien += float.Parse(ThongKedataGridView.Rows[i].Cells[3].Value.ToString()); }
            TongDoanhThutextBox.Text = tongtien.ToString();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
