﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class qltraphong : Form
    {
        public qltraphong()
        {
            InitializeComponent();
            hienthigview2();
            HienthiGridviewDSTHUEPHONG();
        }
        public void HienthiGridviewDSTHUEPHONG()
        {
            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "maPT";
            column1.HeaderText = "Mã PT";
            dtgview1.Columns.Add(column1);

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "maNV";
            column2.HeaderText = "Mã NV";
            dtgview1.Columns.Add(column2);

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "maKH";
            column3.HeaderText = "Mã KH";
            dtgview1.Columns.Add(column3);

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "ngayDen";
            column4.HeaderText = "Ngày đến";
            dtgview1.Columns.Add(column4);

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.DataPropertyName = "ngayDi";
            column5.HeaderText = "Ngày đi";
            dtgview1.Columns.Add(column5);

            DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
            column6.DataPropertyName = "soPhong";
            column6.HeaderText = "Số phòng";
            dtgview1.Columns.Add(column6);

            DataGridViewTextBoxColumn column7 = new DataGridViewTextBoxColumn();
            column7.DataPropertyName = "gia";
            column7.HeaderText = "Giá";
            dtgview1.Columns.Add(column7);
        }
        public void LoadGridByKeyword()
        {
            App_config cf = new App_config();
            dtgview1.DataSource = cf.SelectDb(" SELECT * FROM DSThuePhong WHERE maPT like '%" + txtnmpt.Text + "%' or maKH like '%"+txtnmpt.Text+"%'");
        }
        public void hienthigview2()
        {
            
            
                DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
                column.DataPropertyName = "soPhong";
                column.HeaderText = "Số phòng";
                dtgview2.Columns.Add(column);
               // dtgview2.Columns[0].Width = 10;

                DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
                column2.DataPropertyName = "gia";
                column2.HeaderText = "Giá(ngày)";
                dtgview2.Columns.Add(column2);
               // dtgview2.Columns[1].Width = 30;
            
        }
        private void btthoat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc muốn thoát!", "Thông báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) ;
            // this.Close();
            mainform mf = new mainform();
            mf.Show();
            this.Hide();
        }

        private void dtgview1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtmpt.Text = dtgview1.CurrentRow.Cells[0].Value.ToString();
            txtmnv.Text = dtgview1.CurrentRow.Cells[1].Value.ToString();
            txtmkh.Text = dtgview1.CurrentRow.Cells[2].Value.ToString();
            txtsp.Text = dtgview1.CurrentRow.Cells[5].Value.ToString();
            txtgia.Text = dtgview1.CurrentRow.Cells[6].Value.ToString();
            int nam = Int32.Parse(dtgview1.CurrentRow.Cells[3].Value.ToString().Split('/')[2]);
            int thang = Int32.Parse(dtgview1.CurrentRow.Cells[3].Value.ToString().Split('/')[1]);
            int ngay = Int32.Parse(dtgview1.CurrentRow.Cells[3].Value.ToString().Split('/')[0]);
            //đưa lên datetimespeaker
            datetime1.Value = new DateTime(nam, thang, ngay);

            int nam1 = Int32.Parse(dtgview1.CurrentRow.Cells[4].Value.ToString().Split('/')[2]);
            int thang1 = Int32.Parse(dtgview1.CurrentRow.Cells[4].Value.ToString().Split('/')[1]);
            int ngay1 = Int32.Parse(dtgview1.CurrentRow.Cells[4].Value.ToString().Split('/')[0]);
            //đưa lên datetimespeaker
            datetime2.Value = new DateTime(nam1, thang1, ngay1);

        }

        private void dtgview2_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //txtsp.Text = dtgview2.CurrentRow.Cells[0].Value.ToString();
            //txtgia.Text = dtgview2.CurrentRow.Cells[1].Value.ToString();
        }

        private void txtnmpt_TextChanged(object sender, EventArgs e)
        {
            LoadGridByKeyword();
        }

        private void bttk_Click(object sender, EventArgs e)
        {
        }

        private void txtsno_TextChanged(object sender, EventArgs e)
        {


        }
        private void tinhngay()
        {
            App_config cf = new App_config();
            DataTable dt = new DataTable();
            String sql = " SELECT DATEDIFF(day,convert(datetime ,'" + datetime1.Value + "',103), convert(datetime, '" + datetime2.Value + "',103))";
            dt = cf.SelectDb(sql);
            txtsno.Text = dt.Rows[0][0].ToString();
        }
        public void tongtien()
        {
            App_config cf = new App_config();
            DataTable dt = new DataTable();  
                int gia = Convert.ToInt32(txtgia.Text);
                int tinhngay = Convert.ToInt32(txtsno.Text);
                int tongtien = gia * tinhngay;
                txttt.Text = tongtien.ToString();
            
        }
        private void bttp_Click(object sender, EventArgs e)
        {
            App_config cf = new App_config();
            String sql = "update DSThuePhong set ngayDi = convert(datetime, '" + datetime2.Text + "', 103) where maPT ='" + txtmpt.Text + "' ";
            cf.UpdateDB(sql);
            qltraphong_Load(sender, e);
            MessageBox.Show("Trả phòng thành công. Tính tiền và tạo hóa đơn");
            
        }

        private void bttt_Click(object sender, EventArgs e)
        {
            tinhngay();
            tongtien();
        }

        private void qltraphong_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            String sql = "SELECT maPT,dbo.DSThuePhong.maNV,maKH,convert(varchar,ngayDen,103) as ngayDen, convert(varchar,ngayDi,103) as ngayDi,soPhong";
            sql += " FROM DSThuePhong ";
            sql += " inner join Nhanvien on Nhanvien.maNV=DSThuePhong.maNV";
            sql += " inner join Loaiphong on Loaiphong.maLP=DSThuePhong.maLP";

            dt = configdb.SelectDb(sql);
            if (dt.Rows.Count == null)
            {
                HienthiGridviewDSTHUEPHONG();
                dtgview1.DataSource = dt;
            }
            else
            {
                dtgview1.DataSource = dt;
            }

            App_config cf = new App_config();
            DataTable dt1 = new DataTable();         //Tạo đối tượng DataTable
            //lấy dữ liệu từ bảng Phong
            String sql1 = "select soPhong,gia from Phong ";
            sql1 += "inner join Loaiphong on Loaiphong.maLP=Phong.maLP ";
            dt1 = cf.SelectDb(sql1);
            if (dt1.Rows.Count == null)
            {
                hienthigview2();
                dtgview2.DataSource = dt1;
            }
            else
            {
                dtgview2.DataSource = dt1;
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        //private void btthd_Click(object sender, EventArgs e)
        //{
        //    hoadon hd = new hoadon();
        //    hd.Show();
        //    this.Hide();
        //}

        //SELECT gia From Loaiphong
        //    INNER JOIN Phong ON Phong.maLP = Loaiphong.maLP
        //   WHERE soPhong = 'P101';
    }
}
