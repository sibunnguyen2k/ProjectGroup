﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class FormKhachhang : Form
    {
        public FormKhachhang()
        {
            InitializeComponent();
            HienThiGirdView();
        }

        public void HienThiGirdView()
        {

            //if (dt.Rows.Count == 0)
            //{
            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "maKH";
            column1.HeaderText = "Mã KH";
            khachhangDataGridView.Columns.Add(column1);
            khachhangDataGridView.Columns[0].Width = 70;

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "nameKH";
            column2.HeaderText = "Tên KH";
            khachhangDataGridView.Columns.Add(column2);
            khachhangDataGridView.Columns[1].Width = 150;

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "CMND";
            column3.HeaderText = "CMND/Hộ chiếu";
            khachhangDataGridView.Columns.Add(column3);
            khachhangDataGridView.Columns[2].Width = 120;

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "gioitinh";
            column4.HeaderText = "Nam/Nữ";
            khachhangDataGridView.Columns.Add(column4);

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.DataPropertyName = "dienthoai";
            column5.HeaderText = "Điện thoại";
            khachhangDataGridView.Columns.Add(column5);
            khachhangDataGridView.Columns[4].Width = 130;

            DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
            column6.DataPropertyName = "quocTich";
            column6.HeaderText = "Quốc tịch";
            khachhangDataGridView.Columns.Add(column6);
            khachhangDataGridView.Columns[5].Width = 80;


            //}
            //    else
            //    {
            //        khachhangDataGridView.DataSource = dt;
            //    }
        }

        private void btThem_Click(object sender, EventArgs e)
        {
            if (maKHTextBox.Text == "")
            {
                int count = 0;
                count = khachhangDataGridView.Rows.Count;
                String ma1 = "KH";
                int ma2;
                if (count == 0) ma2 = count + 1;
                else ma2 = count;
                maKHTextBox.Text = ma1 + ma2.ToString();
            }


            App_config configdb = new App_config();
            if (nameKHTextBox.Text == "")
            {
                MessageBox.Show("Mời nhập tên khách hàng!");
                nameKHTextBox.Focus();
            }
            else if (cMNDTextBox.Text == "")
            {
                MessageBox.Show("Mời nhập CMND/Căn cước/Hộ chiếu khách hàng!");
                cMNDTextBox.Focus();
            }
            else if (dienThoaiTextBox.Text == "")
            {
                MessageBox.Show("Mời nhập số điện thoại khách hàng!");
                dienThoaiTextBox.Focus();
            }
            else if (quocTichTextBox.Text == "")
            {
                MessageBox.Show("Mời nhập Quốc tịch khách hàng!");
            }
            else
            {
                String sql = " INSERT INTO Khachhang (maKH,nameKH,CMND,gioitinh,dienthoai,quocTich) ";
                sql += "VALUES ('" + maKHTextBox.Text + "'";
                sql += ", N'" + nameKHTextBox.Text + "'";
                sql += ",'" + cMNDTextBox.Text + "'";
                sql += ",'" + gtcheckBox.Checked + "'";
                sql += ",'" + dienThoaiTextBox.Text + "' ";
                sql += ",N'" + quocTichTextBox.Text + "'";
                sql += " )";

                int sosanhdulieu = configdb.InsertDb(sql);

                if (sosanhdulieu == 0)
                {
                    MessageBox.Show("Không thêm được dữ liệu");
                }
                else if (sosanhdulieu == -1)
                {
                    MessageBox.Show("Lỗi dữ liệu");
                }
                else
                {
                    MessageBox.Show("Đã thêm dữ liệu thành công");
                    //Load lại dữ liệu gridview
                    FormKhachhang_Load_1(sender, e);
                    maKHTextBox.Text = "";
                    cMNDTextBox.Text = "";
                    nameKHTextBox.Text = "";
                    dienThoaiTextBox.Text = "";
                    quocTichTextBox.Text = "";
                    gtcheckBox.Checked = false;
                }
            }
        }

        private void btsua_Click_1(object sender, EventArgs e)
        {
            App_config configdb = new App_config();

            String sqlupdate = " update Khachhang set nameKH = N'" + nameKHTextBox.Text + "' where (MaKH ='" + maKHTextBox.Text + "') ";
            sqlupdate += " update Khachhang set CMND = '" + cMNDTextBox.Text + "'  where (MaKH ='" + maKHTextBox.Text + "') ";
            sqlupdate += " update Khachhang set GioiTinh ='" + gtcheckBox.Checked + "' where(MaKH ='" + maKHTextBox.Text + "')";
            sqlupdate += " update Khachhang set DienThoai = '" + dienThoaiTextBox.Text + "' where (MaKH ='" + maKHTextBox.Text + "')";
            sqlupdate += " update Khachhang set quocTich = N'" + quocTichTextBox.Text + "' where (MaKH ='" + maKHTextBox.Text + "')";

            configdb.UpdateDB(sqlupdate);
            maKHTextBox.Text = "";
            cMNDTextBox.Text = "";
            nameKHTextBox.Text = "";
            dienThoaiTextBox.Text = "";
            quocTichTextBox.Text = "";
            gtcheckBox.Checked = false;
            //Load lại dữ liệu gridview
            FormKhachhang_Load_1(sender, e);
        }
        private void btxoa_Click_1(object sender, EventArgs e)
        {

        }

        private void btThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void khachhangDataGridView_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            maKHTextBox.Text = khachhangDataGridView.CurrentRow.Cells[0].Value.ToString();
            nameKHTextBox.Text = khachhangDataGridView.CurrentRow.Cells[1].Value.ToString();
            cMNDTextBox.Text = khachhangDataGridView.CurrentRow.Cells[2].Value.ToString();
            dienThoaiTextBox.Text = khachhangDataGridView.CurrentRow.Cells[3].Value.ToString();
            quocTichTextBox.Text = khachhangDataGridView.CurrentRow.Cells[4].Value.ToString();
            String sex = khachhangDataGridView.CurrentRow.Cells[5].Value.ToString();
            if (sex == "Nữ")
            {
                gtcheckBox.Checked = false;
            }
            else if (sex == "Nam")
            {
                gtcheckBox.Checked = true;
            }

        }

        private void bttimkiem_Click_1(object sender, EventArgs e)
        {
            FormTimkiemKH tk = new FormTimkiemKH();
            tk.ShowDialog();
        }

        private void FormKhachhang_Load(object sender, EventArgs e)
        {
            
        }

        private void FormKhachhang_Load_1(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            String sql = "SELECT maKH,nameKH,CMND,dienthoai,quocTich,";
            sql += " CASE WHEN gioitinh = 'False' THEN N'Nữ' ";
            sql += " WHEN gioitinh = 'True' THEN N'Nam' ";
            sql += " END as gioitinh";
            sql += " FROM Khachhang ";

            dt = configdb.SelectDb(sql);
            khachhangDataGridView.DataSource = dt;
        }
    }
}