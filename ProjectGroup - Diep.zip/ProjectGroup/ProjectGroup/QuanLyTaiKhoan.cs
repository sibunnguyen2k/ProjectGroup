﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class QuanLyTaiKhoan : Form
    {
        public QuanLyTaiKhoan()
        {
            InitializeComponent();
            HienThiGridView();
        }
        public void HienThiGridView()
        {

            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "LoaiTk";
            column1.HeaderText = "Loại Tài Khoản";
            gridViewTaiKhoan.Columns.Add(column1);

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "Username";
            column2.HeaderText = "Tên đăng nhập";
            gridViewTaiKhoan.Columns.Add(column2);

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.DataPropertyName = "password";
            column5.HeaderText = "Mật khẩu";
            gridViewTaiKhoan.Columns.Add(column5);

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "maNV";
            column3.HeaderText = "Mã NV";
            gridViewTaiKhoan.Columns.Add(column3);

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "nameNV";
            column4.HeaderText = "Tên NV";
            gridViewTaiKhoan.Columns.Add(column4);

            DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
            column6.DataPropertyName = "tinhTrang";
            column6.HeaderText = "Tình trạng";
            gridViewTaiKhoan.Columns.Add(column6);


        }
        private void buttonKhoa_Click(object sender, EventArgs e)
        {
            if (textBoxTenTK.Text == "")
            {
                MessageBox.Show("Mời chọn tài khoản muốn thay đổi tình trạng trước!");
            }
            else
            {
                String tinhTrang = gridViewTaiKhoan.CurrentRow.Cells[5].Value.ToString();
            String sql;
            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            if ( tinhTrang == "close     ")
            {
                sql = "Update Taikhoan set tinhTrang='open' where Username= '"+textBoxTenTK.Text+"'";
                MessageBox.Show("Mở Tài Khoản thành công!");
            }
            else {

               sql = "Update Taikhoan set tinhTrang='close' where Username= '" + textBoxTenTK.Text + "'";
                MessageBox.Show("Khóa Tài Khoản thành công!");
            }
            configdb.UpdateDB(sql);
            textBoxTenTK.Text = "";
            textBoxMK.Text = "";
            textBoxMaNV.Text = "";
            textBoxTenNV.Text = "";
            textBoxTinhTrang.Text = "";
            
            QuanLyTaiKhoan_Load(sender, e);

            }
            
        }

        private void QuanLyTaiKhoan_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            String sql = "SELECT LoaiTK,Taikhoan.Username,password,maNV,nameNV, tinhTrang";
            sql += " FROM dbo.Taikhoan";
            sql += " INNER JOIN dbo.Nhanvien ON Nhanvien.Username = Taikhoan.Username";
            dt = configdb.SelectDb(sql);
           gridViewTaiKhoan.DataSource = dt;
        }

        private void gridViewTaiKhoan_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            textBoxTenTK.Text = gridViewTaiKhoan.CurrentRow.Cells[1].Value.ToString();
            textBoxMK.Text= gridViewTaiKhoan.CurrentRow.Cells[2].Value.ToString();
            textBoxMaNV.Text = gridViewTaiKhoan.CurrentRow.Cells[3].Value.ToString();
            textBoxTenNV.Text = gridViewTaiKhoan.CurrentRow.Cells[4].Value.ToString();
            String tinhTrang=gridViewTaiKhoan.CurrentRow.Cells[5].Value.ToString();
            if (tinhTrang == "close     ")
            {
                textBoxTinhTrang.Text = "Khóa";
            }
            else if (tinhTrang == "open    ") textBoxTinhTrang.Text = "Mở";
            else textBoxTinhTrang.Text = "";

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void buttonThem_Click(object sender, EventArgs e)
        {
            Dangky dk = new Dangky();
            dk.Show();
        }
    }
}
