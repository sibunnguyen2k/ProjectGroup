﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace ProjectGroup
{
    class App_config
    {       
        public static String connection = ConfigurationManager.ConnectionStrings["ProjectGroup.Properties.Settings.QLKSGroupConnectionString"].ConnectionString;
    public int InsertDb (String sql)
        {
            SqlConnection con = new SqlConnection(connection);
            //DataTable tb = new DataTable();
            SqlCommand cmd = new SqlCommand(sql, con);
            int i = -1;
            try
            {
                con.Open();
                i = cmd.ExecuteNonQuery();
            }
            catch
            {
                i = -1;
            }
            finally
            {
                con.Close();
            }
            return i;
        }
        public DataTable SelectDb(String sql)
        {
            // Cấu hình kết nối
            SqlConnection con = new SqlConnection(connection);
            SqlCommand cmd = new SqlCommand(sql, con);
            //Lưới chứa dữ liệu trả về
            DataTable tb = new DataTable();
            try
            {
                con.Open();
                //SD hàm SQL READER
                SqlDataReader dr = cmd.ExecuteReader();
                tb.Load(dr, LoadOption.OverwriteChanges);
                if(tb.Rows.Count == 0)
                {
                    return null;
                }            
            }
            catch
            {

            }
            finally
            {
                con.Close();
            }
            return tb;
        }
        public static Boolean checkUser(String sql)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read() == true)
            {
                return true;
            }
            else return false;
        }
        public void UpdateDB(String sql)
        {
            SqlConnection con = new SqlConnection(connection);
            SqlCommand cmd = new SqlCommand(sql, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch
            {
            }
            finally
            {
                con.Close();
            }
        }
        public void DeleteDB(String sql)
        {
            SqlConnection con = new SqlConnection(connection);
            SqlCommand cmd = new SqlCommand(sql, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch
            {
            }
            finally
            {
                con.Close();
            }
        }
        //public static string CreateKey(string tiento)
        //{
        //    string key = tiento;
        //    float t=1;
        //    //t++;
        //    key = key + t;
        //    t++;
        //    return key;
        //}
    }  
}
