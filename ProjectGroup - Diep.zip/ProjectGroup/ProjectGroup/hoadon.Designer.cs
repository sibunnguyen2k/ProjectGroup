﻿
namespace ProjectGroup
{
    partial class hoadon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtgview1 = new System.Windows.Forms.DataGridView();
            this.dtgview2 = new System.Windows.Forms.DataGridView();
            this.btttoan = new System.Windows.Forms.Button();
            this.btthoat = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.datetime = new System.Windows.Forms.DateTimePicker();
            this.txttt = new System.Windows.Forms.TextBox();
            this.txtmnv = new System.Windows.Forms.TextBox();
            this.txtsno = new System.Windows.Forms.TextBox();
            this.txtsp = new System.Windows.Forms.TextBox();
            this.txtmp = new System.Windows.Forms.TextBox();
            this.txtmkh = new System.Windows.Forms.TextBox();
            this.txtmpt = new System.Windows.Forms.TextBox();
            this.txtmhd = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtmnv1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtgview1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgview2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtgview1
            // 
            this.dtgview1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgview1.Location = new System.Drawing.Point(26, 37);
            this.dtgview1.Margin = new System.Windows.Forms.Padding(2);
            this.dtgview1.Name = "dtgview1";
            this.dtgview1.RowHeadersWidth = 51;
            this.dtgview1.RowTemplate.Height = 24;
            this.dtgview1.Size = new System.Drawing.Size(717, 141);
            this.dtgview1.TabIndex = 0;
            this.dtgview1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dtgview1_CellMouseClick);
            // 
            // dtgview2
            // 
            this.dtgview2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgview2.Location = new System.Drawing.Point(40, 441);
            this.dtgview2.Margin = new System.Windows.Forms.Padding(2);
            this.dtgview2.Name = "dtgview2";
            this.dtgview2.RowHeadersWidth = 51;
            this.dtgview2.RowTemplate.Height = 24;
            this.dtgview2.Size = new System.Drawing.Size(717, 153);
            this.dtgview2.TabIndex = 1;
            this.dtgview2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgview2_CellContentClick);
            // 
            // btttoan
            // 
            this.btttoan.Location = new System.Drawing.Point(133, 394);
            this.btttoan.Margin = new System.Windows.Forms.Padding(2);
            this.btttoan.Name = "btttoan";
            this.btttoan.Size = new System.Drawing.Size(157, 28);
            this.btttoan.TabIndex = 6;
            this.btttoan.Text = "Trả phòng && Thanh toán";
            this.btttoan.UseVisualStyleBackColor = true;
            this.btttoan.Click += new System.EventHandler(this.btttoan_Click);
            // 
            // btthoat
            // 
            this.btthoat.Location = new System.Drawing.Point(549, 394);
            this.btthoat.Margin = new System.Windows.Forms.Padding(2);
            this.btthoat.Name = "btthoat";
            this.btthoat.Size = new System.Drawing.Size(80, 28);
            this.btthoat.TabIndex = 7;
            this.btthoat.Text = "Thoát";
            this.btthoat.UseVisualStyleBackColor = true;
            this.btthoat.Click += new System.EventHandler(this.btthoat_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtmnv1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.datetime);
            this.groupBox1.Controls.Add(this.txttt);
            this.groupBox1.Controls.Add(this.txtmnv);
            this.groupBox1.Controls.Add(this.txtsno);
            this.groupBox1.Controls.Add(this.txtsp);
            this.groupBox1.Controls.Add(this.txtmp);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtmkh);
            this.groupBox1.Controls.Add(this.txtmpt);
            this.groupBox1.Controls.Add(this.txtmhd);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(40, 215);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(717, 175);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin hóa đơn";
            // 
            // datetime
            // 
            this.datetime.CustomFormat = "dd/MM/yyyy";
            this.datetime.Enabled = false;
            this.datetime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datetime.Location = new System.Drawing.Point(329, 103);
            this.datetime.Margin = new System.Windows.Forms.Padding(2);
            this.datetime.Name = "datetime";
            this.datetime.Size = new System.Drawing.Size(88, 20);
            this.datetime.TabIndex = 18;
            // 
            // txttt
            // 
            this.txttt.Enabled = false;
            this.txttt.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txttt.Location = new System.Drawing.Point(597, 106);
            this.txttt.Margin = new System.Windows.Forms.Padding(2);
            this.txttt.Name = "txttt";
            this.txttt.Size = new System.Drawing.Size(113, 20);
            this.txttt.TabIndex = 17;
            // 
            // txtmnv
            // 
            this.txtmnv.Enabled = false;
            this.txtmnv.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtmnv.Location = new System.Drawing.Point(597, 65);
            this.txtmnv.Margin = new System.Windows.Forms.Padding(2);
            this.txtmnv.Name = "txtmnv";
            this.txtmnv.Size = new System.Drawing.Size(111, 20);
            this.txtmnv.TabIndex = 16;
            // 
            // txtsno
            // 
            this.txtsno.Enabled = false;
            this.txtsno.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtsno.Location = new System.Drawing.Point(597, 24);
            this.txtsno.Margin = new System.Windows.Forms.Padding(2);
            this.txtsno.Name = "txtsno";
            this.txtsno.Size = new System.Drawing.Size(113, 20);
            this.txtsno.TabIndex = 14;
            // 
            // txtsp
            // 
            this.txtsp.Enabled = false;
            this.txtsp.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtsp.Location = new System.Drawing.Point(329, 63);
            this.txtsp.Margin = new System.Windows.Forms.Padding(2);
            this.txtsp.Name = "txtsp";
            this.txtsp.Size = new System.Drawing.Size(88, 20);
            this.txtsp.TabIndex = 13;
            this.txtsp.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // txtmp
            // 
            this.txtmp.Enabled = false;
            this.txtmp.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtmp.Location = new System.Drawing.Point(329, 24);
            this.txtmp.Margin = new System.Windows.Forms.Padding(2);
            this.txtmp.Name = "txtmp";
            this.txtmp.Size = new System.Drawing.Size(88, 20);
            this.txtmp.TabIndex = 12;
            // 
            // txtmkh
            // 
            this.txtmkh.Enabled = false;
            this.txtmkh.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtmkh.Location = new System.Drawing.Point(97, 106);
            this.txtmkh.Margin = new System.Windows.Forms.Padding(2);
            this.txtmkh.Name = "txtmkh";
            this.txtmkh.Size = new System.Drawing.Size(106, 20);
            this.txtmkh.TabIndex = 11;
            this.txtmkh.TextChanged += new System.EventHandler(this.txtmkh_TextChanged);
            // 
            // txtmpt
            // 
            this.txtmpt.Enabled = false;
            this.txtmpt.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtmpt.Location = new System.Drawing.Point(97, 63);
            this.txtmpt.Margin = new System.Windows.Forms.Padding(2);
            this.txtmpt.Name = "txtmpt";
            this.txtmpt.Size = new System.Drawing.Size(106, 20);
            this.txtmpt.TabIndex = 10;
            // 
            // txtmhd
            // 
            this.txtmhd.Enabled = false;
            this.txtmhd.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtmhd.Location = new System.Drawing.Point(97, 24);
            this.txtmhd.Margin = new System.Windows.Forms.Padding(2);
            this.txtmhd.Name = "txtmhd";
            this.txtmhd.Size = new System.Drawing.Size(106, 20);
            this.txtmhd.TabIndex = 9;
            this.txtmhd.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtmhd_MouseClick);
            this.txtmhd.TextChanged += new System.EventHandler(this.txtmhd_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(448, 109);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 13);
            this.label10.TabIndex = 8;
            this.label10.Text = "Tổng tiền";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(448, 66);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(143, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "Mã nhân viên tạo phiếu thuê";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(225, 107);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Ngày thanh toán ";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(448, 27);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Số ngày ở";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(227, 66);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Số phòng";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(225, 27);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Mã phòng";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 109);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Mã khách hàng";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 68);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Mã phiếu thuê";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 27);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Mã HĐ tự động";
            // 
            // txtmnv1
            // 
            this.txtmnv1.Enabled = false;
            this.txtmnv1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtmnv1.Location = new System.Drawing.Point(356, 151);
            this.txtmnv1.Margin = new System.Windows.Forms.Padding(2);
            this.txtmnv1.Name = "txtmnv1";
            this.txtmnv1.Size = new System.Drawing.Size(111, 20);
            this.txtmnv1.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(207, 152);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "Mã nhân viên tạo phiếu thuê";
            // 
            // hoadon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(766, 617);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btthoat);
            this.Controls.Add(this.btttoan);
            this.Controls.Add(this.dtgview2);
            this.Controls.Add(this.dtgview1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "hoadon";
            this.Text = "Hóa đơn";
            this.Load += new System.EventHandler(this.hoadon_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgview1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgview2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dtgview1;
        private System.Windows.Forms.DataGridView dtgview2;
        private System.Windows.Forms.Button btttoan;
        private System.Windows.Forms.Button btthoat;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txttt;
        private System.Windows.Forms.TextBox txtmnv;
        private System.Windows.Forms.TextBox txtsno;
        private System.Windows.Forms.TextBox txtsp;
        private System.Windows.Forms.TextBox txtmp;
        private System.Windows.Forms.TextBox txtmkh;
        private System.Windows.Forms.TextBox txtmpt;
        private System.Windows.Forms.TextBox txtmhd;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker datetime;
        private System.Windows.Forms.TextBox txtmnv1;
        private System.Windows.Forms.Label label1;
    }
}