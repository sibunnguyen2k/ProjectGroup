﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class FormTimKiemNV : Form
    {
        public FormTimKiemNV()
        {
            InitializeComponent();
            HienThiGridView();
        }
        public void LoadGridByKeyword()
        {
            App_config app = new App_config();
            TimKiemdataGridView.DataSource = app.SelectDb(" SELECT * FROM Nhanvien WHERE nameNV like '%"+TKtextBox.Text+"%' ");
        }
        private void TKbutton_Click(object sender, EventArgs e)
        {
            LoadGridByKeyword();
        }
        public void HienThiGridView()
        {

            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "maNV";
            column1.HeaderText = "Mã NV";
            TimKiemdataGridView.Columns.Add(column1);

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "Username";
            column2.HeaderText = "Username";
            TimKiemdataGridView.Columns.Add(column2);

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "nameNV";
            column3.HeaderText = "Tên NV";
            TimKiemdataGridView.Columns.Add(column3);

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "Birth";
            column4.HeaderText = "Ngày sinh";
            TimKiemdataGridView.Columns.Add(column4);

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.DataPropertyName = "CMND";
            column5.HeaderText = "Số CMND";
            TimKiemdataGridView.Columns.Add(column5);

            DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
            column6.DataPropertyName = "gioitinh";
            column6.HeaderText = "Giới Tính";
            TimKiemdataGridView.Columns.Add(column6);

            DataGridViewTextBoxColumn column7 = new DataGridViewTextBoxColumn();
            column7.DataPropertyName = "diaChi";
            column7.HeaderText = "Địa Chỉ";
            TimKiemdataGridView.Columns.Add(column7);

            DataGridViewTextBoxColumn column8 = new DataGridViewTextBoxColumn();
            column8.DataPropertyName = "dienThoai";
            column8.HeaderText = "SĐT";
            TimKiemdataGridView.Columns.Add(column8);

            DataGridViewTextBoxColumn column9 = new DataGridViewTextBoxColumn();
            column9.DataPropertyName = "email";
            column9.HeaderText = "Email";
            TimKiemdataGridView.Columns.Add(column9);

            DataGridViewTextBoxColumn column10 = new DataGridViewTextBoxColumn();
            column10.DataPropertyName = "quocTich";
            column10.HeaderText = "Quốc tịch";
            TimKiemdataGridView.Columns.Add(column10);

            DataGridViewTextBoxColumn column11 = new DataGridViewTextBoxColumn();
            column11.DataPropertyName = "bangCap";
            column11.HeaderText = "Trình độ";
            TimKiemdataGridView.Columns.Add(column11);

            DataGridViewTextBoxColumn column13 = new DataGridViewTextBoxColumn();
            column13.DataPropertyName = "tenCV";
            column13.HeaderText = "Chức vụ";
            TimKiemdataGridView.Columns.Add(column13);

            DataGridViewTextBoxColumn column12 = new DataGridViewTextBoxColumn();
            column12.DataPropertyName = "maCV";
            column12.HeaderText = "Mã CV";
            TimKiemdataGridView.Columns.Add(column12);
            column12.Visible = false;
        }
        public void FormTimKiemNV_Load(object sender, EventArgs e)
        {
        
        }

        private void TKtextBox_TextChanged(object sender, EventArgs e)
        {
            LoadGridByKeyword();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void TimKiemdataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
