﻿
namespace ProjectGroup
{
    partial class QuanLyTaiKhoan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxTenTK = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gridViewTaiKhoan = new System.Windows.Forms.DataGridView();
            this.buttonThem = new System.Windows.Forms.Button();
            this.buttonKhoa = new System.Windows.Forms.Button();
            this.textBoxTenNV = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxMK = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxMaNV = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxTinhTrang = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewTaiKhoan)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxTinhTrang);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.textBoxMaNV);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBoxMK);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBoxTenNV);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBoxTenTK);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(68, 43);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1076, 260);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin tài khoản";
            // 
            // textBoxTenTK
            // 
            this.textBoxTenTK.Location = new System.Drawing.Point(178, 45);
            this.textBoxTenTK.Name = "textBoxTenTK";
            this.textBoxTenTK.ReadOnly = true;
            this.textBoxTenTK.Size = new System.Drawing.Size(321, 30);
            this.textBoxTenTK.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tên Đăng nhập:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.gridViewTaiKhoan);
            this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(78, 360);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1065, 368);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tài khoản";
            // 
            // gridViewTaiKhoan
            // 
            this.gridViewTaiKhoan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridViewTaiKhoan.Location = new System.Drawing.Point(29, 44);
            this.gridViewTaiKhoan.Name = "gridViewTaiKhoan";
            this.gridViewTaiKhoan.RowHeadersWidth = 51;
            this.gridViewTaiKhoan.RowTemplate.Height = 24;
            this.gridViewTaiKhoan.Size = new System.Drawing.Size(1002, 296);
            this.gridViewTaiKhoan.TabIndex = 0;
            this.gridViewTaiKhoan.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gridViewTaiKhoan_CellMouseClick);
            // 
            // buttonThem
            // 
            this.buttonThem.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonThem.Location = new System.Drawing.Point(291, 319);
            this.buttonThem.Name = "buttonThem";
            this.buttonThem.Size = new System.Drawing.Size(177, 31);
            this.buttonThem.TabIndex = 2;
            this.buttonThem.Text = "Cấp tài khoản";
            this.buttonThem.UseVisualStyleBackColor = true;
            this.buttonThem.Click += new System.EventHandler(this.buttonThem_Click);
            // 
            // buttonKhoa
            // 
            this.buttonKhoa.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonKhoa.Location = new System.Drawing.Point(763, 319);
            this.buttonKhoa.Name = "buttonKhoa";
            this.buttonKhoa.Size = new System.Drawing.Size(177, 31);
            this.buttonKhoa.TabIndex = 4;
            this.buttonKhoa.Text = "Khóa/Mở tài khoản";
            this.buttonKhoa.UseVisualStyleBackColor = true;
            this.buttonKhoa.Click += new System.EventHandler(this.buttonKhoa_Click);
            // 
            // textBoxTenNV
            // 
            this.textBoxTenNV.Location = new System.Drawing.Point(719, 45);
            this.textBoxTenNV.Name = "textBoxTenNV";
            this.textBoxTenNV.ReadOnly = true;
            this.textBoxTenNV.Size = new System.Drawing.Size(321, 30);
            this.textBoxTenNV.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(551, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tên Nhân Viên";
            // 
            // textBoxMK
            // 
            this.textBoxMK.Location = new System.Drawing.Point(178, 120);
            this.textBoxMK.Name = "textBoxMK";
            this.textBoxMK.ReadOnly = true;
            this.textBoxMK.Size = new System.Drawing.Size(321, 30);
            this.textBoxMK.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(72, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 23);
            this.label3.TabIndex = 4;
            this.label3.Text = "Mật khẩu:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // textBoxMaNV
            // 
            this.textBoxMaNV.Location = new System.Drawing.Point(719, 120);
            this.textBoxMaNV.Name = "textBoxMaNV";
            this.textBoxMaNV.ReadOnly = true;
            this.textBoxMaNV.Size = new System.Drawing.Size(321, 30);
            this.textBoxMaNV.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(608, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 23);
            this.label4.TabIndex = 6;
            this.label4.Text = "Mã NV:";
            // 
            // textBoxTinhTrang
            // 
            this.textBoxTinhTrang.Location = new System.Drawing.Point(432, 192);
            this.textBoxTinhTrang.Name = "textBoxTinhTrang";
            this.textBoxTinhTrang.ReadOnly = true;
            this.textBoxTinhTrang.Size = new System.Drawing.Size(321, 30);
            this.textBoxTinhTrang.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(321, 195);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 23);
            this.label5.TabIndex = 8;
            this.label5.Text = "Tình trạng";
            // 
            // QuanLyTaiKhoan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1219, 755);
            this.Controls.Add(this.buttonKhoa);
            this.Controls.Add(this.buttonThem);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "QuanLyTaiKhoan";
            this.Text = "QuanLyTaiKhoan";
            this.Load += new System.EventHandler(this.QuanLyTaiKhoan_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridViewTaiKhoan)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBoxTenTK;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView gridViewTaiKhoan;
        private System.Windows.Forms.Button buttonThem;
        private System.Windows.Forms.Button buttonKhoa;
        private System.Windows.Forms.TextBox textBoxMK;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxTenNV;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxMaNV;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxTinhTrang;
        private System.Windows.Forms.Label label5;
    }
}