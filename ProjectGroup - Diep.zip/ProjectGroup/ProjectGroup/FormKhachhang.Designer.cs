﻿
namespace ProjectGroup
{
    partial class FormKhachhang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label maKHLabel;
            System.Windows.Forms.Label nameKHLabel;
            System.Windows.Forms.Label cMNDLabel;
            System.Windows.Forms.Label gioitinhLabel;
            System.Windows.Forms.Label dienThoaiLabel;
            System.Windows.Forms.Label quocTichLabel;
            this.khachhangDataGridView = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.gtcheckBox = new System.Windows.Forms.CheckBox();
            this.maKHTextBox = new System.Windows.Forms.TextBox();
            this.nameKHTextBox = new System.Windows.Forms.TextBox();
            this.cMNDTextBox = new System.Windows.Forms.TextBox();
            this.dienThoaiTextBox = new System.Windows.Forms.TextBox();
            this.quocTichTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btThem = new System.Windows.Forms.Button();
            this.btsua = new System.Windows.Forms.Button();
            this.bttimkiem = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            maKHLabel = new System.Windows.Forms.Label();
            nameKHLabel = new System.Windows.Forms.Label();
            cMNDLabel = new System.Windows.Forms.Label();
            gioitinhLabel = new System.Windows.Forms.Label();
            dienThoaiLabel = new System.Windows.Forms.Label();
            quocTichLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.khachhangDataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // maKHLabel
            // 
            maKHLabel.AutoSize = true;
            maKHLabel.Location = new System.Drawing.Point(24, 47);
            maKHLabel.Name = "maKHLabel";
            maKHLabel.Size = new System.Drawing.Size(68, 19);
            maKHLabel.TabIndex = 42;
            maKHLabel.Text = "Mã KH:";
            // 
            // nameKHLabel
            // 
            nameKHLabel.AutoSize = true;
            nameKHLabel.Location = new System.Drawing.Point(24, 88);
            nameKHLabel.Name = "nameKHLabel";
            nameKHLabel.Size = new System.Drawing.Size(71, 19);
            nameKHLabel.TabIndex = 46;
            nameKHLabel.Text = "Tên KH:";
            // 
            // cMNDLabel
            // 
            cMNDLabel.AutoSize = true;
            cMNDLabel.Location = new System.Drawing.Point(6, 139);
            cMNDLabel.Name = "cMNDLabel";
            cMNDLabel.Size = new System.Drawing.Size(146, 19);
            cMNDLabel.TabIndex = 50;
            cMNDLabel.Text = "CMND / Hộ chiếu:";
            // 
            // gioitinhLabel
            // 
            gioitinhLabel.AutoSize = true;
            gioitinhLabel.Location = new System.Drawing.Point(498, 40);
            gioitinhLabel.Name = "gioitinhLabel";
            gioitinhLabel.Size = new System.Drawing.Size(84, 19);
            gioitinhLabel.TabIndex = 52;
            gioitinhLabel.Text = "Giới tính:";
            // 
            // dienThoaiLabel
            // 
            dienThoaiLabel.AutoSize = true;
            dienThoaiLabel.Location = new System.Drawing.Point(498, 86);
            dienThoaiLabel.Name = "dienThoaiLabel";
            dienThoaiLabel.Size = new System.Drawing.Size(92, 19);
            dienThoaiLabel.TabIndex = 56;
            dienThoaiLabel.Text = "Điện thoại:";
            // 
            // quocTichLabel
            // 
            quocTichLabel.AutoSize = true;
            quocTichLabel.Location = new System.Drawing.Point(498, 139);
            quocTichLabel.Name = "quocTichLabel";
            quocTichLabel.Size = new System.Drawing.Size(87, 19);
            quocTichLabel.TabIndex = 60;
            quocTichLabel.Text = "Quốc tịch:";
            // 
            // khachhangDataGridView
            // 
            this.khachhangDataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.khachhangDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.khachhangDataGridView.GridColor = System.Drawing.SystemColors.Control;
            this.khachhangDataGridView.Location = new System.Drawing.Point(29, 330);
            this.khachhangDataGridView.Name = "khachhangDataGridView";
            this.khachhangDataGridView.RowHeadersWidth = 51;
            this.khachhangDataGridView.RowTemplate.Height = 24;
            this.khachhangDataGridView.Size = new System.Drawing.Size(939, 284);
            this.khachhangDataGridView.TabIndex = 40;
            this.khachhangDataGridView.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.khachhangDataGridView_CellMouseClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.gtcheckBox);
            this.groupBox1.Controls.Add(maKHLabel);
            this.groupBox1.Controls.Add(this.maKHTextBox);
            this.groupBox1.Controls.Add(nameKHLabel);
            this.groupBox1.Controls.Add(this.nameKHTextBox);
            this.groupBox1.Controls.Add(cMNDLabel);
            this.groupBox1.Controls.Add(this.cMNDTextBox);
            this.groupBox1.Controls.Add(gioitinhLabel);
            this.groupBox1.Controls.Add(dienThoaiLabel);
            this.groupBox1.Controls.Add(this.dienThoaiTextBox);
            this.groupBox1.Controls.Add(quocTichLabel);
            this.groupBox1.Controls.Add(this.quocTichTextBox);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(29, 64);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(916, 185);
            this.groupBox1.TabIndex = 42;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin Khách hàng:";
            // 
            // gtcheckBox
            // 
            this.gtcheckBox.AutoSize = true;
            this.gtcheckBox.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gtcheckBox.Location = new System.Drawing.Point(605, 37);
            this.gtcheckBox.Name = "gtcheckBox";
            this.gtcheckBox.Size = new System.Drawing.Size(63, 23);
            this.gtcheckBox.TabIndex = 62;
            this.gtcheckBox.Text = "Nam";
            this.gtcheckBox.UseVisualStyleBackColor = true;
            // 
            // maKHTextBox
            // 
            this.maKHTextBox.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maKHTextBox.Location = new System.Drawing.Point(126, 37);
            this.maKHTextBox.Name = "maKHTextBox";
            this.maKHTextBox.ReadOnly = true;
            this.maKHTextBox.Size = new System.Drawing.Size(308, 27);
            this.maKHTextBox.TabIndex = 43;
            // 
            // nameKHTextBox
            // 
            this.nameKHTextBox.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameKHTextBox.Location = new System.Drawing.Point(126, 83);
            this.nameKHTextBox.Name = "nameKHTextBox";
            this.nameKHTextBox.Size = new System.Drawing.Size(308, 27);
            this.nameKHTextBox.TabIndex = 47;
            // 
            // cMNDTextBox
            // 
            this.cMNDTextBox.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cMNDTextBox.Location = new System.Drawing.Point(173, 139);
            this.cMNDTextBox.Name = "cMNDTextBox";
            this.cMNDTextBox.Size = new System.Drawing.Size(308, 27);
            this.cMNDTextBox.TabIndex = 51;
            // 
            // dienThoaiTextBox
            // 
            this.dienThoaiTextBox.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dienThoaiTextBox.Location = new System.Drawing.Point(605, 85);
            this.dienThoaiTextBox.Name = "dienThoaiTextBox";
            this.dienThoaiTextBox.Size = new System.Drawing.Size(286, 27);
            this.dienThoaiTextBox.TabIndex = 57;
            // 
            // quocTichTextBox
            // 
            this.quocTichTextBox.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quocTichTextBox.Location = new System.Drawing.Point(605, 131);
            this.quocTichTextBox.Name = "quocTichTextBox";
            this.quocTichTextBox.Size = new System.Drawing.Size(286, 27);
            this.quocTichTextBox.TabIndex = 61;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(348, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(268, 35);
            this.label1.TabIndex = 43;
            this.label1.Text = "Quản lý khách hàng";
            // 
            // btThem
            // 
            this.btThem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btThem.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThem.Location = new System.Drawing.Point(402, 273);
            this.btThem.Name = "btThem";
            this.btThem.Size = new System.Drawing.Size(84, 37);
            this.btThem.TabIndex = 44;
            this.btThem.Text = "Thêm";
            this.btThem.UseVisualStyleBackColor = false;
            this.btThem.Click += new System.EventHandler(this.btThem_Click);
            // 
            // btsua
            // 
            this.btsua.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btsua.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btsua.Location = new System.Drawing.Point(507, 273);
            this.btsua.Name = "btsua";
            this.btsua.Size = new System.Drawing.Size(82, 37);
            this.btsua.TabIndex = 45;
            this.btsua.Text = "Sửa";
            this.btsua.UseVisualStyleBackColor = false;
            this.btsua.Click += new System.EventHandler(this.btsua_Click_1);
            // 
            // bttimkiem
            // 
            this.bttimkiem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bttimkiem.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttimkiem.Location = new System.Drawing.Point(634, 273);
            this.bttimkiem.Name = "bttimkiem";
            this.bttimkiem.Size = new System.Drawing.Size(115, 37);
            this.bttimkiem.TabIndex = 47;
            this.bttimkiem.Text = "Tìm kiếm";
            this.bttimkiem.UseVisualStyleBackColor = false;
            this.bttimkiem.Click += new System.EventHandler(this.bttimkiem_Click_1);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(777, 273);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 37);
            this.button1.TabIndex = 48;
            this.button1.Text = "Thoát";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.btThoat_Click);
            // 
            // FormKhachhang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1001, 642);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.bttimkiem);
            this.Controls.Add(this.btsua);
            this.Controls.Add(this.btThem);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.khachhangDataGridView);
            this.Name = "FormKhachhang";
            this.Text = "KHÁCH HÀNG";
            this.Load += new System.EventHandler(this.FormKhachhang_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.khachhangDataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView khachhangDataGridView;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox maKHTextBox;
        private System.Windows.Forms.TextBox nameKHTextBox;
        private System.Windows.Forms.TextBox cMNDTextBox;
        private System.Windows.Forms.TextBox dienThoaiTextBox;
        private System.Windows.Forms.TextBox quocTichTextBox;
        private System.Windows.Forms.CheckBox gtcheckBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btThem;
        private System.Windows.Forms.Button btsua;
        private System.Windows.Forms.Button bttimkiem;
        private System.Windows.Forms.Button button1;
    }
}