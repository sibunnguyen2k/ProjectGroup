﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class FormThuePhong : Form
    {
        public FormThuePhong()
        {
            InitializeComponent();
            HienthiGridViewPHONG();
            HienthiGridviewKHACHHANG();
        }

        // Hiển thị Gridview KHÁCH HÀNG
        public void HienthiGridViewPHONG()
        {
            //DataTable dt = new DataTable();
            //App_config configdb = new App_config();
            //String sql = "SELECT soPhong,tenLP,gia,tenTT";
            //sql += " FROM dbo.Phong";
            //sql += " INNER JOIN dbo.Loaiphong ON dbo.Loaiphong.maLP =dbo.Phong.MaLP";
            //sql += " INNER JOIN dbo.Tinhtrang ON dbo.Tinhtrang.maTT = dbo.Phong.maTT";
            //sql += " WHERE dbo.Phong.maTT = 1";
            //dt = configdb.SelectDb(sql);
                DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
                column1.DataPropertyName = "soPhong";
                column1.HeaderText = "Số phòng";
                PhongdataGridView.Columns.Add(column1);

                DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
                column2.DataPropertyName = "tenLP";
                column2.HeaderText = "Tên loại phòng";
                PhongdataGridView.Columns.Add(column2);

                DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
                column3.DataPropertyName = "gia";
                column3.HeaderText = "Giá phòng";
                PhongdataGridView.Columns.Add(column3);

                DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
                column4.DataPropertyName = "maNV";
                column4.HeaderText = "Mã NV";
                column4.Visible = false;
                PhongdataGridView.Columns.Add(column4);

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.DataPropertyName = "tenTT";
            column5.HeaderText = "Trạng thái";
            PhongdataGridView.Columns.Add(column5);
            //PhongdataGridView.DataSource = dt;
        }
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        // Hiển thị lên textbox PHÒNG
        private void PhongdataGridView_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //MessageBox.Show(PhongdataGridView.CurrentRow.Cells[0].Value.ToString());
            SoPhongtextBox.Text = PhongdataGridView.CurrentRow.Cells[1].Value.ToString();
            GiatextBox.Text = PhongdataGridView.CurrentRow.Cells[3].Value.ToString();
        }

        // Hiển thị Gridview KHÁCH HÀNG
        public void HienthiGridviewKHACHHANG()
        {
            //DataTable dt = new DataTable();
            //App_config configdb = new App_config();

            //String sql = "SELECT maKH,nameKH,CMND,gioitinh,dienthoai,quocTich";
            //sql += " FROM Khachhang ";

            //dt = configdb.SelectDb(sql);
                DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
                column1.DataPropertyName = "maKH";
                column1.HeaderText = "Mã KH";
                khachhangDataGridView.Columns.Add(column1);
                khachhangDataGridView.Columns[0].Width = 70;

                DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
                column2.DataPropertyName = "nameKH";
                column2.HeaderText = "Tên KH";
                khachhangDataGridView.Columns.Add(column2);
                khachhangDataGridView.Columns[1].Width = 150;

                DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
                column3.DataPropertyName = "CMND";
                column3.HeaderText = "CMND";
                khachhangDataGridView.Columns.Add(column3);
                khachhangDataGridView.Columns[2].Width = 80;

                DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
                column4.DataPropertyName = "gioitinh";
                column4.HeaderText = "Giới tính";
                khachhangDataGridView.Columns.Add(column4);

                DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
                column5.DataPropertyName = "dienThoai";
                column5.HeaderText = "Điện thoại";
                khachhangDataGridView.Columns.Add(column5);
                khachhangDataGridView.Columns[4].Width = 130;

                DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
                column6.DataPropertyName = "quocTich";
                column6.HeaderText = "Quốc tịch";
                khachhangDataGridView.Columns.Add(column6);
                khachhangDataGridView.Columns[5].Width = 80;

        }
        private void KhachHangdataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        // Hiển thị textbox mã Khách hàng
        private void khachhangDataGridView_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            MaKHtextBox.Text = khachhangDataGridView.CurrentRow.Cells[0].Value.ToString();

        }

        //Hiển thị textbox Mã Phiếu thuê
        private void MaPhieutextBox_TextChanged(object sender, EventArgs e)
        {
            //MaPhieutextBox.Text = App_config.CreateKey("PT");
        }

        //Hàm load tìm kiếm tên Khách hàng
       public void LoadGridByKeyword()
        {
            App_config app = new App_config();
            khachhangDataGridView.DataSource = app.SelectDb(" SELECT * FROM Khachhang WHERE nameKH like '%" + TKTentextBox.Text + "%' ");
        }

        private void TKTentextBox_TextChanged(object sender, EventArgs e)
        {
            LoadGridByKeyword();
        }
        

        public void HienthiGridviewDSTHUEPHONG()
        {
            //DataTable dt = new DataTable();
            //App_config configdb = new App_config();
            //String sql = "SELECT maPT,maKH,ngayDen,ngayDi,soPhong";
            //sql += " FROM DSThuePhong ";
            //dt = configdb.SelectDb(sql);

                DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
                column1.DataPropertyName = "maPT";
                column1.HeaderText = "Mã PT";
                DSThuePhongdataGridView.Columns.Add(column1);

                DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
                column2.DataPropertyName = "maKH";
                column2.HeaderText = "Mã KH";
                DSThuePhongdataGridView.Columns.Add(column2);

                DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
                column3.DataPropertyName = "ngayDen";
                column3.HeaderText = "Ngày đến";
                DSThuePhongdataGridView.Columns.Add(column3);

                DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
                column4.DataPropertyName = "ngayDi";
                column4.HeaderText = "Ngày đi";
                DSThuePhongdataGridView.Columns.Add(column4);

                DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
                column5.DataPropertyName = "soPhong";
                column5.HeaderText = "Số phòng";
                DSThuePhongdataGridView.Columns.Add(column5);

                DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
                column6.DataPropertyName = "maNV";
                column6.HeaderText = "mã NV";
                DSThuePhongdataGridView.Columns.Add(column6);

            //DSThuePhongdataGridView.DataSource = dt;
        }

        private void ThuePhongbutton_Click(object sender, EventArgs e)
        {

            //MaPhieutextBox.Text = App_config.CreateKey("PT");

            int count = 0;
            count = DSThuePhongdataGridView.Rows.Count; // đếm tất cả các dòng trong dsthuephonggridview rồi đem đi gán cho count
            String ma1 = "PT";
            int ma2 = count+1;
            MaPhieutextBox.Text = ma1 + ma2.ToString();
                App_config configdb = new App_config();
                String sqlThem = "INSERT INTO  DSThuePhong(maPT,maKH,ngayDen,ngayDi,soPhong,maNV)";
                sqlThem += " VALUES (N'" + MaPhieutextBox.Text + "'";
                sqlThem += ",N'" + MaKHtextBox.Text + "'";
                sqlThem += ", CONVERT(datetime,'" + NgayDendateTimePicker.Text + "',103)";
                sqlThem += ",null";
                sqlThem += ",N'" + SoPhongtextBox.Text + "'";
                sqlThem += ",N'" + MaNVtextBox.Text + "'";
            sqlThem += ")";
            int sosanhdulieu = configdb.InsertDb(sqlThem);

            if (sosanhdulieu == 0)
            {
                MessageBox.Show("Không thêm được dữ liệu");
            }
            else if (sosanhdulieu == -1)
            {
                MessageBox.Show("Lỗi không kết nối dữ liệu");
            }
            else
            {
                MessageBox.Show("Đã thêm dữ liệu thành công");
                //HienthiGridviewDSTHUEPHONG();
                String sqlSua = "UPDATE dbo.Phong SET maTT = 2 WHERE soPhong= '" + SoPhongtextBox.Text+"'" ;
                configdb.InsertDb(sqlSua);
                FormThuePhong_Load(sender,e);
                //HienthiGridviewDSTHUEPHONG();
            }

        }

        //Load form
        private void FormThuePhong_Load(object sender, EventArgs e)
        {
            //MaPhieutextBox.Enabled = false;
            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            String sql = "SELECT soPhong,tenLP,gia,tenTT";
            sql += " FROM dbo.Phong";
            sql += " INNER JOIN dbo.Loaiphong ON dbo.Loaiphong.maLP =dbo.Phong.MaLP";
            sql += " INNER JOIN dbo.Tinhtrang ON dbo.Tinhtrang.maTT = dbo.Phong.maTT";
            sql += " WHERE dbo.Phong.maTT = 1";
            dt = configdb.SelectDb(sql);
            PhongdataGridView.DataSource = dt;

            DataTable dt1 = new DataTable();
            App_config configdb1 = new App_config();
            String sql1 = "SELECT maKH,nameKH,CMND,";
            sql1 += " CASE WHEN gioitinh = 'False' THEN N'Nữ' ";
            sql1 += " WHEN gioitinh = 'True' THEN N'Nam' ";
            sql1 += " END as gioitinh,";
            sql1 += " dienthoai,quocTich";
            sql1 += " FROM Khachhang ";
            dt1 = configdb.SelectDb(sql1);
            khachhangDataGridView.DataSource = dt1;

            DataTable dt2 = new DataTable();
            App_config configdb2 = new App_config();
            String sql2 = "SELECT maPT,maKH,CONVERT(VARCHAR,ngayDen,103) AS ngayDen,CONVERT(VARCHAR,ngayDi,103) AS ngayDi,soPhong,maNV";
            sql2 += " FROM DSThuePhong ";
            dt2 = configdb.SelectDb(sql2);
            DSThuePhongdataGridView.DataSource = dt2;
            //if (dt2.Rows.Count == null)
            //{
            //    HienthiGridviewDSTHUEPHONG();
            //    DSThuePhongdataGridView.DataSource = dt2;
            //}
            //else
            //{
            //    DSThuePhongdataGridView.DataSource = dt2;
            //}
        }


        private void GiatextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Xoabutton_Click(object sender, EventArgs e)
        {

            App_config app = new App_config();
            if (Xoabutton.Enabled == true)
            {
                DialogResult dialog = MessageBox.Show("Bạn có chắc chắn muốn xóa ", "Thông báo",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialog == DialogResult.Yes)
                {
                    String sqlSua = "UPDATE dbo.Phong SET maTT = 1 WHERE soPhong= '" + DSThuePhongdataGridView.CurrentRow.Cells[4].Value.ToString() + "'";
                    string sql = "Delete DSThuePhong where ( maPT = '" + DSThuePhongdataGridView.CurrentRow.Cells[0].Value.ToString() + "')";
                    app.DeleteDB(sql);
                    DSThuePhongdataGridView.Rows.RemoveAt(DSThuePhongdataGridView.CurrentRow.Index);
                    // HienthiGridviewDSTHUEPHONG();                  
                    app.InsertDb(sqlSua);
                    FormThuePhong_Load(sender,e);
                }
                else
                {
                    dialog = DialogResult.Cancel;
                }
            }
        }

        public FormThuePhong(String t) : this()
        {
            string chuoi = t;
            MaNVtextBox.Text = chuoi.ToString();
        }
        private void Thoatbutton_Click(object sender, EventArgs e)
        {
            DialogResult dlr = MessageBox.Show("Bạn muốn thoát chương trình?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dlr == DialogResult.Yes) this.Close();
        }
    }
}
