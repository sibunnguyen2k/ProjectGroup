﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class tkhoadon : Form
    {
        public tkhoadon()
        {
            InitializeComponent();
            hienthigview();
        }
        public void LoadGridByKeyword()
        {
            App_config cf = new App_config();
            dtgview.DataSource = cf.SelectDb(" SELECT * FROM Hoadon WHERE maHD like '%" + txtnmhd.Text + "%'");
        }
        private void btsua_Click(object sender, EventArgs e)
        {
        }

        private void tttk_Click(object sender, EventArgs e)
        {
            //LoadGridByKeyword();
        }
        public void hienthigview()
        {

            DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "maHD";
            column.HeaderText = "Mã HĐ";
            dtgview.Columns.Add(column);


            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "maPT";
            column2.HeaderText = "Mã PT";
            dtgview.Columns.Add(column2);


            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "maNV";
            column3.HeaderText = "Mã NV";
            column3.Visible = false;
            dtgview.Columns.Add(column3);

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "maNVTT";
            column4.HeaderText = "Mã NVTT";
            dtgview.Columns.Add(column4);

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.DataPropertyName = "maKH";
            column5.HeaderText = "Mã KH";
            column5.Visible = false;
            dtgview.Columns.Add(column5);

            DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
            column6.DataPropertyName = "soPhong";
            column6.HeaderText = "Số phòng";
            column6.Visible = false;
            dtgview.Columns.Add(column6);

            DataGridViewTextBoxColumn column7 = new DataGridViewTextBoxColumn();
            column7.DataPropertyName = "ngayDen";
            column7.HeaderText = "Ngày đến";
            column7.Visible = false;
            dtgview.Columns.Add(column7);

            DataGridViewTextBoxColumn column8 = new DataGridViewTextBoxColumn();
            column8.DataPropertyName = "ngayTT";
            column8.HeaderText = "Ngày thanh toán";
            //column8.Visible = false;
            dtgview.Columns.Add(column8);

            DataGridViewTextBoxColumn column9 = new DataGridViewTextBoxColumn();
            column9.DataPropertyName = "tongtien";
            column9.HeaderText = "Tổng tiền";
            dtgview.Columns.Add(column9);


        }

        private void dtgview_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtmhd.Text = dtgview.CurrentRow.Cells[0].Value.ToString();
            txtmpt.Text = dtgview.CurrentRow.Cells[1].Value.ToString();
            txtmnv.Text = dtgview.CurrentRow.Cells[2].Value.ToString();
            txtmnvtt.Text= dtgview.CurrentRow.Cells[3].Value.ToString();
            txtmkh.Text = dtgview.CurrentRow.Cells[4].Value.ToString();
            txtsp.Text = dtgview.CurrentRow.Cells[5].Value.ToString();
            txttt.Text = dtgview.CurrentRow.Cells[8].Value.ToString();

            int nam1 = Int32.Parse(dtgview.CurrentRow.Cells[6].Value.ToString().Split('/')[2]);
            int thang1 = Int32.Parse(dtgview.CurrentRow.Cells[6].Value.ToString().Split('/')[1]);
            int ngay1 = Int32.Parse(dtgview.CurrentRow.Cells[6].Value.ToString().Split('/')[0]);
            //đưa lên datetimespeaker
            datetime.Value = new DateTime(nam1, thang1, ngay1);

            int nam = Int32.Parse(dtgview.CurrentRow.Cells[7].Value.ToString().Split('/')[2]);
            int thang = Int32.Parse(dtgview.CurrentRow.Cells[7].Value.ToString().Split('/')[1]);
            int ngay = Int32.Parse(dtgview.CurrentRow.Cells[7].Value.ToString().Split('/')[0]);
            //đưa lên datetimespeaker
            datetime1.Value = new DateTime(nam, thang, ngay);
        }

        private void btthoat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc muốn thoát", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) ;
            this.Close();
            
        }

        private void qlhoadon_Load(object sender, EventArgs e)
        {
            App_config cf = new App_config();
            DataTable dt = new DataTable();
            string sql = " select maHD,dbo.DSThuePhong.maPT,maNV,maNVTT,dbo.DSThuePhong.maKH,soPhong,convert(varchar,dbo.DSThuePhong.ngayDen,103) as ngayDen,convert(varchar,dbo.HoaDon.ngayTT,103) as ngayTT,tongtien ";
            sql += " from HoaDon ";
            sql += " inner join DSThuePhong on DSThuePhong.maPT= HoaDon.maPT ";
            dt = cf.SelectDb(sql);
            if (dt.Rows.Count == null)
            {
                hienthigview();
                dtgview.DataSource = dt;
            }
            else
            {
                dtgview.DataSource = dt;
            }
        }

        private void txtnmhd_TextChanged(object sender, EventArgs e)
        {
            LoadGridByKeyword();
        }
        
    }
}
