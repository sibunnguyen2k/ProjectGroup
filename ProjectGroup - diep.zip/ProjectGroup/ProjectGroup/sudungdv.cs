﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class sudungdv : Form
    {
        public sudungdv()
        {
            InitializeComponent();
            HienThiGirdView();
            //loadtextbox();
            hienthigrid1();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        public void loadtextbox()
        {
            //txtmakh.DataBindings.Clear();
            //txtmakh.DataBindings.Add("text", gridkhachhang.DataSource, "maKH");
        }
        public void HienThiGirdView()
        {

            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "maKH";
            column1.HeaderText = "Mã KH";
            gridkhachhang.Columns.Add(column1);


            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "nameKH";
            column2.HeaderText = "Tên KH";
            gridkhachhang.Columns.Add(column2);


            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "CMND";
            column3.HeaderText = "CMND";
            gridkhachhang.Columns.Add(column3);


            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "gioitinh";
            column4.HeaderText = "Giới tính";
            gridkhachhang.Columns.Add(column4);

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.DataPropertyName = "dienThoai";
            column5.HeaderText = "Điện thoại";
            gridkhachhang.Columns.Add(column5);


            DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
            column6.DataPropertyName = "quocTich";
            column6.HeaderText = "Quốc tịch";
            gridkhachhang.Columns.Add(column6);

        }
        public void loadkey()
        {
            App_config app = new App_config();
            gridkhachhang.DataSource = app.SelectDb(" SELECT * FROM Khachhang WHERE maKH like '%" + txttk.Text + "%'");

        }
        private void txttk_TextChanged(object sender, EventArgs e)
        {
            loadkey();
        }
        private string CreateHang(String tiento)
        {
            string key = tiento;
            int t = gridhoadon.Rows.Count;
            key = key + t;
            return key;
        }

        public void hienthigrid1()
        {
            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "maHDDV";
            column1.HeaderText = "Mã Hóa Đơn DV";
            gridhoadon.Columns.Add(column1);

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "maKH";
            column2.HeaderText = "Mã KH";
            gridhoadon.Columns.Add(column2);


            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "ngaytao";
            column3.HeaderText = "Ngày Tạo";
            gridhoadon.Columns.Add(column3);


            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "tongdoanhthudv";
            column4.HeaderText = " Tổng doanh thu DV";
            gridhoadon.Columns.Add(column4);


        }
        private void gridkhachhang_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtmakh.Text = gridkhachhang.CurrentRow.Cells[0].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtmahd.Text = CreateHang("HDDV");
            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            String sql = "INSERT INTO hoadondv(maHDDV , maKH, ngaytao, tongdoanhthudv)";
            sql += " VALUES (N'" + txtmahd.Text + "'";
            sql += ",N'" + txtmakh.Text + "'";
            sql += ",CONVERT (Datetime ,'" + datetime.Text + "',103)";
            sql += ",null";
            sql += ");";
            int sosanh = configdb.InsertDb(sql);
            if (sosanh == 0)
            {
                MessageBox.Show("Không tạo được hóa đơn!!!");
            }
            else if (sosanh == -1)
            {
                MessageBox.Show("!!!");
            }
            else
            {
                MessageBox.Show("Tạo hóa đơn thành công!!!");
                sudungdv_Load(sender, e);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            hoadonsddv hoadonsddv = new hoadonsddv(txtmahd.Text);
            hoadonsddv.Show();

        }

        private void CapNhatbutton_Click(object sender, EventArgs e)
        {
            sudungdv_Load(sender, e);
        }

        private void sudungdv_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            String sql = "SELECT maKH,nameKH,CMND,";
            sql += " CASE WHEN gioitinh = 'False' THEN N'Nữ' ";
            sql += " WHEN gioitinh = 'True' THEN N'Nam' ";
            sql += " END as gioitinh,";
            sql += " dienthoai,quocTich";
            sql += " FROM Khachhang ";
            dt = configdb.SelectDb(sql);
            gridkhachhang.DataSource = dt;


            DataTable dt1 = new DataTable();
            App_config configdb1 = new App_config();
            String sql1 = "SELECT maHDDV , maKH, CONVERT(VARCHAR,ngaytao,103) AS Ngaytao ,tongdoanhthudv FROM hoadondv";
            dt1 = configdb.SelectDb(sql1);
            gridhoadon.DataSource = dt1;
        }
    }
}