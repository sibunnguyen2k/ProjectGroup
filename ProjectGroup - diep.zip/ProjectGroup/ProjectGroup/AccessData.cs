﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectGroup
{
    //Mở truy cập database
    class AccessData
    {
        string Connection = ConfigurationManager.ConnectionStrings["ProjectGroup.Properties.Settings.QLKSGroupConnectionString"].ConnectionString;
        public void ExcuteNonQuery(String sql)
        {
            SqlConnection con = new SqlConnection(Connection);
            SqlCommand cmd = new SqlCommand(sql, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch
            {

            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
        }
        public SqlDataReader ExcuteReader(String sql)
        {
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader reader = cmd.ExecuteReader(); //đọc dữ liệu database
            return reader;
        }
    }
}
