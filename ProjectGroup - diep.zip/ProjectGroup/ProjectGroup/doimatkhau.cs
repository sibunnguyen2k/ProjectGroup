﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace ProjectGroup
{
    public partial class doimatkhau : Form
    {
        public doimatkhau()
        {
            InitializeComponent();     
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
        }        
        private void btcapnhat_Click(object sender, EventArgs e)
        {

            App_config cf = new App_config();
            DataTable dt = new DataTable();
            String sql = "select password from Taikhoan where Username=N'"+txttdn.Text+"'";
            dt = cf.SelectDb(sql);
            if(txtmkc.Text.Equals(dt.Rows[0][0].ToString()))
            {
                if(txtmkm.Text.Equals(txtxnmk.Text))
                {
                    sql = " update Taikhoan set password='" + txtmkm.Text + "' where Username=N'" + txttdn.Text + "'";
                    cf.UpdateDB(sql);
                    MessageBox.Show("Cap nhat thanh cong");
                    txtmkc.Text = "";
                    txtmkm.Text = "";
                    txtxnmk.Text = "";
                }
                else
                {
                    MessageBox.Show("Xac nhan mat khau khong trung khop");
                    txtmkc.Text = "";
                    txtmkm.Text = "";
                    txtxnmk.Text = "";
                }
            }
            else
            {
                MessageBox.Show("Mat khau cu khong dung");
                txtmkc.Text = "";
                txtmkm.Text = "";
                txtxnmk.Text = "";
            }  
        }
        private void doimatkhau_Load(object sender, EventArgs e)
        {
        }

        private void cpass_CheckedChanged(object sender, EventArgs e)
        {
            if (cpass.Checked)
            {
                txtmkc.PasswordChar = '*';
                txtmkm.PasswordChar = '*';
                txtxnmk.PasswordChar = '*';
                txtmkc.BringToFront();
                txtmkm.BringToFront();
                txtxnmk.BringToFront();
                txtmkc.PasswordChar = '\0';
                txtmkm.PasswordChar = '\0';
                txtxnmk.PasswordChar = '\0';
            }
            else
            {
                txtmkc.PasswordChar = '\0';
                txtmkm.PasswordChar = '\0';
                txtxnmk.PasswordChar = '\0';
                txtmkc.BringToFront();
                txtmkm.BringToFront();
                txtxnmk.BringToFront();
                txtmkc.PasswordChar = '*';
                txtmkm.PasswordChar = '*';
                txtxnmk.PasswordChar = '*';
            }
        }

        private void btthoat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc muốn thoát!", "Thông báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) ;
            this.Close();
        }
        String giatri = " ";
        public doimatkhau(String Username) : this()
        {
            giatri = Username;
            txttdn.Text =giatri.ToString();
        }

    }
}
