﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class FormKhachhang : Form
    {
        public FormKhachhang()
        {
            InitializeComponent();
            HienThiGirdView();
        }

        public void HienThiGirdView()
        {
            DataTable dt = new DataTable();
            App_config configdb = new App_config();

            String sql = "SELECT maKH,nameKH,CMND,dienthoai,quocTich,";
            sql += " CASE WHEN gioitinh = 'False' THEN N'Nữ' ";
            sql += " WHEN gioitinh = 'True' THEN N'Nam' ";
            sql += " END as gioitinh";
            sql += " FROM Khachhang ";

            dt = configdb.SelectDb(sql);
            //if (dt.Rows.Count == 0)
            //{
                DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
                column1.DataPropertyName = "maKH";
                column1.HeaderText = "Mã KH";
                khachhangDataGridView.Columns.Add(column1);
                khachhangDataGridView.Columns[0].Width = 70;

                DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
                column2.DataPropertyName = "nameKH";
                column2.HeaderText = "Tên KH";
                khachhangDataGridView.Columns.Add(column2);
                khachhangDataGridView.Columns[1].Width = 150;

                DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
                column3.DataPropertyName = "CMND";
                column3.HeaderText = "CMND/Hộ chiếu";
                khachhangDataGridView.Columns.Add(column3);
                khachhangDataGridView.Columns[2].Width = 120;

                DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
                column4.DataPropertyName = "gioitinh";
                column4.HeaderText = "Nam/Nữ";
                khachhangDataGridView.Columns.Add(column4);

                DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
                column5.DataPropertyName = "dienthoai";
                column5.HeaderText = "Điện thoại";
                khachhangDataGridView.Columns.Add(column5);
                khachhangDataGridView.Columns[4].Width = 130;

                DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
                column6.DataPropertyName = "quocTich";
                column6.HeaderText = "Quốc tịch";
                khachhangDataGridView.Columns.Add(column6);
                khachhangDataGridView.Columns[5].Width = 80;

                khachhangDataGridView.DataSource = dt;
        //}
        //    else
        //    {
        //        khachhangDataGridView.DataSource = dt;
        //    }
}

        private void btThem_Click(object sender, EventArgs e)
        {
            App_config configdb = new App_config();

            String sql = " INSERT INTO Khachhang (maKH,nameKH,CMND,gioitinh,dienthoai,quocTich) ";
            sql += "VALUES (N'" + maKHTextBox.Text + "'";
            sql += ", N'" + nameKHTextBox.Text + "'";
            sql += ",N'" + cMNDTextBox.Text + "'";
            sql += ",'" + gtcheckBox.Checked + "'";
            sql += ",N'" + dienThoaiTextBox.Text + "' ";
            sql += ",N'" + quocTichTextBox.Text + "'";
            sql += " )";

            int sosanhdulieu = configdb.InsertDb(sql);

            if (sosanhdulieu == 0)
            {
                MessageBox.Show("Không thêm được dữ liệu");
            }
            else if (sosanhdulieu == -1)
            {
                MessageBox.Show("Lỗi dữ liệu");
            }
            else
            {
                MessageBox.Show("Đã thêm dữ liệu thành công");
                //Load lại dữ liệu gridview
                HienThiGirdView();
            }
        }

        private void btsua_Click_1(object sender, EventArgs e)
        {
            App_config configdb = new App_config();

            String sqlupdate = " update Khachhang set nameKH = N'" + nameKHTextBox.Text + "' where (MaKH ='" + maKHTextBox.Text + "') ";
            sqlupdate += " update Khachhang set CMND = '" +cMNDTextBox.Text + "'  where (MaKH ='" + maKHTextBox.Text + "') ";
            sqlupdate += " update Khachhang set GioiTinh ='" + gtcheckBox.Checked + "' where(MaKH ='" + maKHTextBox.Text + "')";
            sqlupdate += " update Khachhang set DienThoai = '" + dienThoaiTextBox.Text + "' where (MaKH ='" + maKHTextBox.Text + "')";
            sqlupdate += " update Khachhang set quocTich = '" + quocTichTextBox.Text + "' where (MaKH ='" + maKHTextBox.Text + "')";

            configdb.UpdateDB(sqlupdate);
            //Load lại dữ liệu gridview
            HienThiGirdView();
        }
        private void btxoa_Click_1(object sender, EventArgs e)
        {
            App_config configdb = new App_config();
            if (btxoa.Enabled == true)
            {
                DialogResult dialog = MessageBox.Show("Bạn chắc chắn sẽ xóa CSDL này không!", "Thông báo",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialog == DialogResult.Yes)
                {
                    string sqldel = "delete Khachhang  where (maKH = '" + maKHTextBox.Text + " ' ) ";
                    configdb.DeleteDB(sqldel);
                    HienThiGirdView();
                }
                else
                {
                    dialog = DialogResult.Cancel;
                }
            }
        }

        private void btThoat_Click(object sender, EventArgs e)
        {
           this.Close();
        }

        private void khachhangDataGridView_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            maKHTextBox.Text = khachhangDataGridView.CurrentRow.Cells[0].Value.ToString();
            nameKHTextBox.Text = khachhangDataGridView.CurrentRow.Cells[1].Value.ToString();
            cMNDTextBox.Text = khachhangDataGridView.CurrentRow.Cells[2].Value.ToString();
            dienThoaiTextBox.Text = khachhangDataGridView.CurrentRow.Cells[4].Value.ToString();
            quocTichTextBox.Text = khachhangDataGridView.CurrentRow.Cells[5].Value.ToString();
        }

        private void bttimkiem_Click_1(object sender, EventArgs e)
        {
            FormTimkiemKH tk = new FormTimkiemKH();
            tk.ShowDialog();
        }
    }
}
