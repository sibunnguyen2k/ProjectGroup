﻿
namespace ProjectGroup
{
    partial class FormThuePhong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.khachhangDataGridView = new System.Windows.Forms.DataGridView();
            this.PhongdataGridView = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.MaPhieutextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ThemKHbutton = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.TKTentextBox = new System.Windows.Forms.TextBox();
            this.MaKHtextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.NgayDendateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.GiatextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.SoPhongtextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.MaNVtextBox = new System.Windows.Forms.TextBox();
            this.DSThuePhongdataGridView = new System.Windows.Forms.DataGridView();
            this.ThuePhongbutton = new System.Windows.Forms.Button();
            this.Xoabutton = new System.Windows.Forms.Button();
            this.Thoatbutton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.khachhangDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PhongdataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DSThuePhongdataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // khachhangDataGridView
            // 
            this.khachhangDataGridView.AccessibleRole = System.Windows.Forms.AccessibleRole.SplitButton;
            this.khachhangDataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.khachhangDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.khachhangDataGridView.Location = new System.Drawing.Point(12, 30);
            this.khachhangDataGridView.Name = "khachhangDataGridView";
            this.khachhangDataGridView.RowHeadersWidth = 51;
            this.khachhangDataGridView.RowTemplate.Height = 24;
            this.khachhangDataGridView.Size = new System.Drawing.Size(798, 151);
            this.khachhangDataGridView.TabIndex = 1;
            this.khachhangDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.KhachHangdataGridView_CellContentClick);
            this.khachhangDataGridView.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.khachhangDataGridView_CellMouseClick);
            // 
            // PhongdataGridView
            // 
            this.PhongdataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.PhongdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PhongdataGridView.Location = new System.Drawing.Point(14, 23);
            this.PhongdataGridView.Name = "PhongdataGridView";
            this.PhongdataGridView.RowHeadersWidth = 51;
            this.PhongdataGridView.RowTemplate.Height = 24;
            this.PhongdataGridView.Size = new System.Drawing.Size(798, 153);
            this.PhongdataGridView.TabIndex = 3;
            this.PhongdataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            this.PhongdataGridView.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.PhongdataGridView_CellMouseClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(37, 455);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 18);
            this.label3.TabIndex = 4;
            this.label3.Text = "Mã phiếu thuê tự động";
            // 
            // MaPhieutextBox
            // 
            this.MaPhieutextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.MaPhieutextBox.Location = new System.Drawing.Point(207, 455);
            this.MaPhieutextBox.Name = "MaPhieutextBox";
            this.MaPhieutextBox.Size = new System.Drawing.Size(100, 24);
            this.MaPhieutextBox.TabIndex = 5;
            this.MaPhieutextBox.TextChanged += new System.EventHandler(this.MaPhieutextBox_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(126, 497);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 18);
            this.label4.TabIndex = 6;
            this.label4.Text = "Mã KH";
            // 
            // ThemKHbutton
            // 
            this.ThemKHbutton.BackColor = System.Drawing.Color.Maroon;
            this.ThemKHbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.ThemKHbutton.ForeColor = System.Drawing.SystemColors.Control;
            this.ThemKHbutton.Location = new System.Drawing.Point(901, 146);
            this.ThemKHbutton.Name = "ThemKHbutton";
            this.ThemKHbutton.Size = new System.Drawing.Size(124, 37);
            this.ThemKHbutton.TabIndex = 7;
            this.ThemKHbutton.Text = "Thêm khách";
            this.ThemKHbutton.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.Location = new System.Drawing.Point(888, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(147, 18);
            this.label5.TabIndex = 8;
            this.label5.Text = "Nhập tên khách hàng";
            // 
            // TKTentextBox
            // 
            this.TKTentextBox.Location = new System.Drawing.Point(876, 105);
            this.TKTentextBox.Name = "TKTentextBox";
            this.TKTentextBox.Size = new System.Drawing.Size(178, 22);
            this.TKTentextBox.TabIndex = 11;
            this.TKTentextBox.TextChanged += new System.EventHandler(this.TKTentextBox_TextChanged);
            // 
            // MaKHtextBox
            // 
            this.MaKHtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.MaKHtextBox.Location = new System.Drawing.Point(207, 497);
            this.MaKHtextBox.Name = "MaKHtextBox";
            this.MaKHtextBox.Size = new System.Drawing.Size(100, 24);
            this.MaKHtextBox.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label7.Location = new System.Drawing.Point(365, 458);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 18);
            this.label7.TabIndex = 13;
            this.label7.Text = "Ngày đến";
            // 
            // NgayDendateTimePicker
            // 
            this.NgayDendateTimePicker.CustomFormat = "dd/MM/yyyy";
            this.NgayDendateTimePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.NgayDendateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.NgayDendateTimePicker.Location = new System.Drawing.Point(459, 458);
            this.NgayDendateTimePicker.Name = "NgayDendateTimePicker";
            this.NgayDendateTimePicker.Size = new System.Drawing.Size(200, 24);
            this.NgayDendateTimePicker.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label8.Location = new System.Drawing.Point(369, 503);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 18);
            this.label8.TabIndex = 15;
            this.label8.Text = "Giá/ngày";
            // 
            // GiatextBox
            // 
            this.GiatextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.GiatextBox.Location = new System.Drawing.Point(459, 503);
            this.GiatextBox.Name = "GiatextBox";
            this.GiatextBox.Size = new System.Drawing.Size(200, 24);
            this.GiatextBox.TabIndex = 16;
            this.GiatextBox.TextChanged += new System.EventHandler(this.GiatextBox_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label9.Location = new System.Drawing.Point(761, 458);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 18);
            this.label9.TabIndex = 17;
            this.label9.Text = "Số phòng";
            // 
            // SoPhongtextBox
            // 
            this.SoPhongtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.SoPhongtextBox.Location = new System.Drawing.Point(846, 460);
            this.SoPhongtextBox.Name = "SoPhongtextBox";
            this.SoPhongtextBox.Size = new System.Drawing.Size(100, 24);
            this.SoPhongtextBox.TabIndex = 18;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label10.Location = new System.Drawing.Point(761, 506);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 18);
            this.label10.TabIndex = 19;
            this.label10.Text = "Mã NV";
            // 
            // MaNVtextBox
            // 
            this.MaNVtextBox.Enabled = false;
            this.MaNVtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.MaNVtextBox.Location = new System.Drawing.Point(846, 503);
            this.MaNVtextBox.Name = "MaNVtextBox";
            this.MaNVtextBox.ReadOnly = true;
            this.MaNVtextBox.Size = new System.Drawing.Size(100, 24);
            this.MaNVtextBox.TabIndex = 20;
            // 
            // DSThuePhongdataGridView
            // 
            this.DSThuePhongdataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.DSThuePhongdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DSThuePhongdataGridView.Location = new System.Drawing.Point(15, 33);
            this.DSThuePhongdataGridView.Name = "DSThuePhongdataGridView";
            this.DSThuePhongdataGridView.RowHeadersWidth = 51;
            this.DSThuePhongdataGridView.RowTemplate.Height = 24;
            this.DSThuePhongdataGridView.Size = new System.Drawing.Size(798, 150);
            this.DSThuePhongdataGridView.TabIndex = 21;
            // 
            // ThuePhongbutton
            // 
            this.ThuePhongbutton.BackColor = System.Drawing.Color.Maroon;
            this.ThuePhongbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.ThuePhongbutton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ThuePhongbutton.Location = new System.Drawing.Point(891, 597);
            this.ThuePhongbutton.Name = "ThuePhongbutton";
            this.ThuePhongbutton.Size = new System.Drawing.Size(134, 44);
            this.ThuePhongbutton.TabIndex = 23;
            this.ThuePhongbutton.Text = "Thuê phòng";
            this.ThuePhongbutton.UseVisualStyleBackColor = false;
            this.ThuePhongbutton.Click += new System.EventHandler(this.ThuePhongbutton_Click);
            // 
            // Xoabutton
            // 
            this.Xoabutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.Xoabutton.Location = new System.Drawing.Point(912, 647);
            this.Xoabutton.Name = "Xoabutton";
            this.Xoabutton.Size = new System.Drawing.Size(99, 32);
            this.Xoabutton.TabIndex = 24;
            this.Xoabutton.Text = "Xóa";
            this.Xoabutton.UseVisualStyleBackColor = true;
            this.Xoabutton.Click += new System.EventHandler(this.Xoabutton_Click);
            // 
            // Thoatbutton
            // 
            this.Thoatbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.Thoatbutton.Location = new System.Drawing.Point(912, 685);
            this.Thoatbutton.Name = "Thoatbutton";
            this.Thoatbutton.Size = new System.Drawing.Size(99, 30);
            this.Thoatbutton.TabIndex = 25;
            this.Thoatbutton.Text = "Thoát";
            this.Thoatbutton.UseVisualStyleBackColor = true;
            this.Thoatbutton.Click += new System.EventHandler(this.Thoatbutton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.khachhangDataGridView);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox1.Location = new System.Drawing.Point(26, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(835, 187);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin Khách Hàng";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.PhongdataGridView);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox2.Location = new System.Drawing.Point(26, 241);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(835, 191);
            this.groupBox2.TabIndex = 27;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thông tin phòng";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.DSThuePhongdataGridView);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox3.Location = new System.Drawing.Point(23, 551);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(838, 189);
            this.groupBox3.TabIndex = 28;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Danh sách thuê phòng";
            // 
            // FormThuePhong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1084, 752);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Thoatbutton);
            this.Controls.Add(this.Xoabutton);
            this.Controls.Add(this.ThuePhongbutton);
            this.Controls.Add(this.MaNVtextBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.SoPhongtextBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.GiatextBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.NgayDendateTimePicker);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.MaKHtextBox);
            this.Controls.Add(this.TKTentextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ThemKHbutton);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.MaPhieutextBox);
            this.Controls.Add(this.label3);
            this.Name = "FormThuePhong";
            this.Text = "PHIẾU THUÊ PHÒNG";
            this.Load += new System.EventHandler(this.FormThuePhong_Load);
            ((System.ComponentModel.ISupportInitialize)(this.khachhangDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PhongdataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DSThuePhongdataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView khachhangDataGridView;
        private System.Windows.Forms.DataGridView PhongdataGridView;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox MaPhieutextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button ThemKHbutton;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TKTentextBox;
        private System.Windows.Forms.TextBox MaKHtextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker NgayDendateTimePicker;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox GiatextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox SoPhongtextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox MaNVtextBox;
        private System.Windows.Forms.DataGridView DSThuePhongdataGridView;
        private System.Windows.Forms.Button ThuePhongbutton;
        private System.Windows.Forms.Button Xoabutton;
        private System.Windows.Forms.Button Thoatbutton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}