﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using COMExcel = Microsoft.Office.Interop.Excel;

namespace ProjectGroup
{
    public partial class FormThongkePhong : Form
    {
        public FormThongkePhong()
        {
            InitializeComponent();
            HienthigridviewThongke();
        }

        public void HienthigridviewThongke()
        {
            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "maHD";
            column1.HeaderText = "Mã HD";
            ThongKedataGridView.Columns.Add(column1);

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "maPT";
            column3.HeaderText = "Mã PT";
            ThongKedataGridView.Columns.Add(column3);

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "ngayTT";
            column4.HeaderText = "Ngày thanh toán";
            ThongKedataGridView.Columns.Add(column4);

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.DataPropertyName = "tongTien";
            column5.HeaderText = "Tổng tiền";
            ThongKedataGridView.Columns.Add(column5);

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "maNVTT";
            column2.HeaderText = "Mã nhân viên thanh toán";
            ThongKedataGridView.Columns.Add(column2);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dlr = MessageBox.Show("Bạn muốn thoát chương trình?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dlr == DialogResult.Yes) this.Close();
        }

        private void FormThongkePhong_Load(object sender, EventArgs e)
        {
        }

        private void ThongKebutton_Click(object sender, EventArgs e)
        {

            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            String sql = "SELECT maHD,maPT,ngayTT,tongTien,maNVTT";
            sql += " FROM Hoadon";
            //sql += "WHERE ngayDi BETWEEN " + TuNgay.Text + "AND" + denNgay.Text;
            sql += " WHERE (ngayTT >=   CONVERT(datetime, '" + TuNgay.Value.Date + "', 102)  AND ngayTT <= CONVERT(datetime, '" + denNgay.Value.Date + "', 102))";
            dt = configdb.SelectDb(sql);
            ThongKedataGridView.DataSource = dt;
            TinhtongDoanhthu();
        }

        public void TinhtongDoanhthu()
        {
            int sc = ThongKedataGridView.Rows.Count;
            float tongtien = 0;
            for (int i = 0; i < sc - 1; i++)
            { tongtien += float.Parse(ThongKedataGridView.Rows[i].Cells[3].Value.ToString()); }
            TongDoanhThutextBox.Text = tongtien.ToString();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btxuat_Click(object sender, EventArgs e)
        {
            
        }

        private void btxuat_Click_1(object sender, EventArgs e)
        {
            COMExcel.Application exApp = new COMExcel.Application();
            COMExcel.Workbook workbook;
            COMExcel.Worksheet worksheet;
            COMExcel.Range exrang;
            String sql;
            int hang = 0, cot = 0;

            DataTable tbHoadon;
            workbook = exApp.Workbooks.Add(COMExcel.XlWBATemplate.xlWBATWorksheet);
            worksheet = workbook.Worksheets[1];

            //Định dạng chung
            exrang = worksheet.Cells[1, 1];
            exrang.Range["A1:Z300"].Font.Name = "Times new roman"; //định dạng font chữ
            exrang.Range["B1:E1"].Font.Size = 18;//định dạng cỡ chữ
            exrang.Range["B1:E1"].Font.Bold = true;//định dạng in đậm
            exrang.Range["B1:E1"].Font.ColorIndex = 3;//định dạng màu chữ
            exrang.Range["B1:E1"].MergeCells = true;//gộp ô
            exrang.Range["B1:E1"].HorizontalAlignment = COMExcel.XlHAlign.xlHAlignCenter; //căn lề
            exrang.Range["B1:E1"].Value = "THỐNG KÊ HÓA ĐƠN THEO PHÒNG";

            //Hiển thị thông tin
            sql = " select maHD,maPT,ngayTT,tongTien,nameNV From Hoadon inner join Nhanvien on Nhanvien.maNV = Hoadon.maNVTT";
            sql += " WHERE (ngayTT >=   CONVERT(datetime, '" + TuNgay.Value.Date + "', 102)  AND ngayTT <= CONVERT(datetime, '" + denNgay.Value.Date + "', 102))";
            App_config app_Config = new App_config();
            tbHoadon = app_Config.SelectDb(sql);

            exrang.Range["A3:F3"].Font.Bold = true;
            exrang.Range["A3:F3"].HorizontalAlignment = COMExcel.XlHAlign.xlHAlignCenter;
            exrang.Range["A3:F3"].ColumnWidth = 18;
            exrang.Range["A3:A3"].Value = "STT";
            exrang.Range["B3:B3"].Value = "Mã hóa đơn";
            exrang.Range["C3:C3"].Value = "Mã phiếu thuê";
            exrang.Range["D3:D3"].Value = "Ngày thanh toán";
            exrang.Range["E3:E3"].Value = "Tổng tiền";
            exrang.Range["F3:F3"].Value = "Nhân viên thanh toán";

            for (hang = 0; hang < tbHoadon.Rows.Count; hang++)
            {
                worksheet.Cells[1][hang + 4] = hang + 1; //điền stt vào hàng 4 cột 1
                for (cot = 0; cot < tbHoadon.Columns.Count; cot++)
                {
                    worksheet.Cells[cot + 2][hang + 4] = tbHoadon.Rows[hang][cot].ToString();
                }
            }

            exrang = worksheet.Cells[cot][hang + 7];
            exrang.Font.Bold = true;
            exrang.Value2 = "Tổng tiền";
            exrang = worksheet.Cells[cot + 1][hang + 7];
            exrang.Font.Bold = true;
            exrang.Value2 = TongDoanhThutextBox.Text;
            exrang = worksheet.Cells[4][hang + 10];
            exrang.Range["A1:C1"].MergeCells = true;
            exrang.Range["A1:C1"].Font.Italic = true;
            exrang.Range["A1:C1"].HorizontalAlignment = COMExcel.XlHAlign.xlHAlignCenter;
            DateTime d = Convert.ToDateTime(tbHoadon.Rows[0][2]);
            exrang.Range["A1:C1"].Value = "Hà Nội,ngày " + d.Day + " tháng " + d.Month + " năm " + d.Year;
            exrang.Range["A2:C2"].MergeCells = true;
            exrang.Range["A2:C2"].HorizontalAlignment = COMExcel.XlHAlign.xlHAlignCenter;
            exrang.Range["A2:C2"].Value = "Nhân viên bán hàng";
            exrang.Range["A6:C6"].MergeCells = true;
            exrang.Range["A6:C6"].Font.Italic = true;
            exrang.Range["A6:C6"].HorizontalAlignment = COMExcel.XlHAlign.xlHAlignCenter;
            exrang.Range["A6:C6"].Value = tbHoadon.Rows[0][4];
            worksheet.Name = "Thống kê doanh thu";
            exApp.Visible = true;
        }
    }
}