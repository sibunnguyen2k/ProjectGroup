﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class FormThongkeDichVu : Form
    {
        public FormThongkeDichVu()
        {
            InitializeComponent();
        }
        public void HienthigridviewThongkeDichVu()
        {
            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "maHDDV";
            column1.HeaderText = "Mã HDDV";
            ThongKedataGridView.Columns.Add(column1);

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "maKH";
            column3.HeaderText = "Mã KH";
            ThongKedataGridView.Columns.Add(column3);

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "ngaytao";
            column4.HeaderText = "Ngày lập hóa đơn";
            ThongKedataGridView.Columns.Add(column4);

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.DataPropertyName = "tongdoanhthudv";
            column5.HeaderText = "Tổng tiền";
            ThongKedataGridView.Columns.Add(column5);
        }
        public void TinhtongDoanhthu()
        {
            int sc = ThongKedataGridView.Rows.Count;
            int tongtien = 0;
            for (int i = 0; i < sc - 1; i++)
            { tongtien += int.Parse(ThongKedataGridView.Rows[i].Cells[3].Value.ToString()); }
            TongDoanhThutextBox.Text = tongtien.ToString();
        }
        private void Thoatbutton_Click(object sender, EventArgs e)
        {
            DialogResult dlr = MessageBox.Show("Bạn muốn thoát chương trình?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dlr == DialogResult.Yes) this.Close();
        }

        private void ThongKebutton_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            String sql = "SELECT maHDDV,maKH,ngaytao,tongdoanhthudv";
            sql += " FROM hoadondv";
            //sql += "WHERE ngayDi BETWEEN " + TuNgay.Text + "AND" + denNgay.Text;
            sql += " WHERE (ngaytao >=   CONVERT(datetime, '" + TuNgay.Value.Date + "', 102)  AND ngaytao <= CONVERT(datetime, '" + denNgay.Value.Date + "', 102))";
            dt = configdb.SelectDb(sql);
            ThongKedataGridView.DataSource = dt;
            TinhtongDoanhthu();
        }
    }
}
