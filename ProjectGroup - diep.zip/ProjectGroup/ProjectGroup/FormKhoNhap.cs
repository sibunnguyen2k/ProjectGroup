﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class FormKhoNhap : Form
    {
        public FormKhoNhap()
        {
            InitializeComponent();
        }
        public void HienThiGirdView()
        {
            DataTable dt = new DataTable();
            App_config configdb = new App_config();

            String sql = "SELECT maSP,tensp,soluong,gianhap,nhacc,";
            sql += " CONVERT(varchar, ngaynhap, 103) AS ngaynhap ";
            sql += " FROM Kho ";

            dt = configdb.SelectDb(sql);

            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "maSP";
            column1.HeaderText = "Mã SP";
            khoDataGridView.Columns.Add(column1);
            khoDataGridView.Columns[0].Width = 70;

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "tensp";
            column2.HeaderText = "Tên SP";
            khoDataGridView.Columns.Add(column2);
            khoDataGridView.Columns[1].Width = 150;

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "soluong";
            column3.HeaderText = "Số lượng";
            khoDataGridView.Columns.Add(column3);
            khoDataGridView.Columns[2].Width = 80;

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "gianhap";
            column4.HeaderText = "Giá nhập";
            khoDataGridView.Columns.Add(column4);
            khoDataGridView.Columns[3].Width = 80;

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.DataPropertyName = "nhacc";
            column5.HeaderText = "Nhà cung cấp";
            khoDataGridView.Columns.Add(column5);
            khoDataGridView.Columns[4].Width = 130;

            DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
            column6.DataPropertyName = "ngaynhap";
            column6.HeaderText = "Ngày nhập";
            khoDataGridView.Columns.Add(column6);
            khoDataGridView.Columns[5].Width = 100;

            khoDataGridView.DataSource = dt;
        }

        private void Formkhonhap_Load(object sender, EventArgs e)
        {

        }

       

        private void khoDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            maSPTextBox.Text = khoDataGridView.CurrentRow.Cells[0].Value.ToString();
            tenspTextBox.Text = khoDataGridView.CurrentRow.Cells[1].Value.ToString();
            soluongTextBox.Text = khoDataGridView.CurrentRow.Cells[2].Value.ToString();
            gianhapTextBox.Text = khoDataGridView.CurrentRow.Cells[3].Value.ToString();
            nhaccTextBox.Text = khoDataGridView.CurrentRow.Cells[4].Value.ToString();

            int nam = Int32.Parse(khoDataGridView.CurrentRow.Cells[5].Value.ToString().Split('/')[2]);
            int thang = Int32.Parse(khoDataGridView.CurrentRow.Cells[5].Value.ToString().Split('/')[1]);
            int ngay = Int32.Parse(khoDataGridView.CurrentRow.Cells[5].Value.ToString().Split('/')[0]);
            //đưa lên datetimepicker 
            ngaynhapDateTimePicker.Value = new DateTime(nam, thang, ngay);
        }


        private void btThem_Click(object sender, EventArgs e)
        {
            App_config configdb = new App_config();

            String sql = " INSERT INTO Kho (maSP,tensp,soluong,gianhap,ngaynhap,nhacc) ";
            sql += "VALUES (" + maSPTextBox.Text + "";
            sql += ", N'" + tenspTextBox.Text + "'";
            sql += ",'" + soluongTextBox.Text + "'";
            sql += ",'" + gianhapTextBox.Text + "'";
            sql += ", CONVERT(datetime,'" + ngaynhapDateTimePicker.Text + "',103)";
            sql += ",N'" + nhaccTextBox.Text + "'";
            sql += " )";

            int sosanhdulieu = configdb.InsertDb(sql);

            if (sosanhdulieu == 0)
            {
                MessageBox.Show("Không thêm được dữ liệu");
            }
            else if (sosanhdulieu == -1)
            {
                MessageBox.Show("Lỗi dữ liệu");
            }
            else
            {
                MessageBox.Show("Đã thêm dữ liệu thành công");
                //Load lại dữ liệu gridview
                HienThiGirdView();
            }
        }

        private void btTimkiem_Click_1(object sender, EventArgs e)
        {
            FormtimkiemKho childForm = new FormtimkiemKho();
            childForm.ShowDialog();
        }

        private void btXoa_Click_1(object sender, EventArgs e)
        {
            App_config configdb = new App_config();
            if (btXoa.Enabled == true)
            {
                DialogResult dialog = MessageBox.Show("Bạn chắc chắn sẽ xóa CSDL này không!", "Thông báo",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialog == DialogResult.Yes)
                {
                    string sqldel = "delete Kho   where (maSP = '" + maSPTextBox.Text + " ' ) ";
                    configdb.DeleteDB(sqldel);
                    HienThiGirdView();
                }
                else;
                {
                    dialog = DialogResult.Cancel;
                }
            }
        }

        private void btThoat_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
