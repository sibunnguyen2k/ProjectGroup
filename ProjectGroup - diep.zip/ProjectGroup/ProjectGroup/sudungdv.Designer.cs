﻿
namespace ProjectGroup
{
    partial class sudungdv
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gridkhachhang = new System.Windows.Forms.DataGridView();
            this.gridhoadon = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txttk = new System.Windows.Forms.TextBox();
            this.lbmahd = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtmahd = new System.Windows.Forms.TextBox();
            this.txtmakh = new System.Windows.Forms.TextBox();
            this.bttaohd = new System.Windows.Forms.Button();
            this.btchitiet = new System.Windows.Forms.Button();
            this.datetime = new System.Windows.Forms.DateTimePicker();
            this.CapNhatbutton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gridkhachhang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridhoadon)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gridkhachhang
            // 
            this.gridkhachhang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridkhachhang.Location = new System.Drawing.Point(12, 77);
            this.gridkhachhang.Name = "gridkhachhang";
            this.gridkhachhang.RowHeadersWidth = 51;
            this.gridkhachhang.RowTemplate.Height = 24;
            this.gridkhachhang.Size = new System.Drawing.Size(774, 215);
            this.gridkhachhang.TabIndex = 0;
            this.gridkhachhang.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gridkhachhang_CellMouseClick);
            // 
            // gridhoadon
            // 
            this.gridhoadon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridhoadon.Location = new System.Drawing.Point(12, 421);
            this.gridhoadon.Name = "gridhoadon";
            this.gridhoadon.RowHeadersWidth = 51;
            this.gridhoadon.RowTemplate.Height = 24;
            this.gridhoadon.Size = new System.Drawing.Size(1068, 214);
            this.gridhoadon.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txttk);
            this.groupBox1.Location = new System.Drawing.Point(815, 77);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(265, 215);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tìm Kiếm";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(90, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 17);
            this.label4.TabIndex = 1;
            this.label4.Text = "Nhập Mã KH";
            // 
            // txttk
            // 
            this.txttk.Location = new System.Drawing.Point(37, 94);
            this.txttk.Name = "txttk";
            this.txttk.Size = new System.Drawing.Size(207, 22);
            this.txttk.TabIndex = 0;
            this.txttk.TextChanged += new System.EventHandler(this.txttk_TextChanged);
            // 
            // lbmahd
            // 
            this.lbmahd.AutoSize = true;
            this.lbmahd.Location = new System.Drawing.Point(93, 323);
            this.lbmahd.Name = "lbmahd";
            this.lbmahd.Size = new System.Drawing.Size(51, 17);
            this.lbmahd.TabIndex = 3;
            this.lbmahd.Text = "Mã HĐ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(349, 326);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Mã KH";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(580, 325);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Ngày tạo";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtmahd
            // 
            this.txtmahd.Location = new System.Drawing.Point(176, 323);
            this.txtmahd.Name = "txtmahd";
            this.txtmahd.ReadOnly = true;
            this.txtmahd.Size = new System.Drawing.Size(100, 22);
            this.txtmahd.TabIndex = 6;
            // 
            // txtmakh
            // 
            this.txtmakh.Location = new System.Drawing.Point(423, 323);
            this.txtmakh.Name = "txtmakh";
            this.txtmakh.Size = new System.Drawing.Size(100, 22);
            this.txtmakh.TabIndex = 7;
            // 
            // bttaohd
            // 
            this.bttaohd.Location = new System.Drawing.Point(324, 375);
            this.bttaohd.Name = "bttaohd";
            this.bttaohd.Size = new System.Drawing.Size(75, 23);
            this.bttaohd.TabIndex = 9;
            this.bttaohd.Text = "Tạo HĐ";
            this.bttaohd.UseVisualStyleBackColor = true;
            this.bttaohd.Click += new System.EventHandler(this.button1_Click);
            // 
            // btchitiet
            // 
            this.btchitiet.Location = new System.Drawing.Point(570, 375);
            this.btchitiet.Name = "btchitiet";
            this.btchitiet.Size = new System.Drawing.Size(75, 23);
            this.btchitiet.TabIndex = 10;
            this.btchitiet.Text = "Chi tiết";
            this.btchitiet.UseVisualStyleBackColor = true;
            this.btchitiet.Click += new System.EventHandler(this.button2_Click);
            // 
            // datetime
            // 
            this.datetime.CustomFormat = "dd/MM/yyyy";
            this.datetime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datetime.Location = new System.Drawing.Point(705, 323);
            this.datetime.Name = "datetime";
            this.datetime.Size = new System.Drawing.Size(200, 22);
            this.datetime.TabIndex = 11;
            // 
            // CapNhatbutton
            // 
            this.CapNhatbutton.Location = new System.Drawing.Point(726, 375);
            this.CapNhatbutton.Name = "CapNhatbutton";
            this.CapNhatbutton.Size = new System.Drawing.Size(96, 23);
            this.CapNhatbutton.TabIndex = 12;
            this.CapNhatbutton.Text = "Cập nhật";
            this.CapNhatbutton.UseVisualStyleBackColor = true;
            this.CapNhatbutton.Click += new System.EventHandler(this.CapNhatbutton_Click);
            // 
            // sudungdv
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1107, 647);
            this.Controls.Add(this.CapNhatbutton);
            this.Controls.Add(this.datetime);
            this.Controls.Add(this.btchitiet);
            this.Controls.Add(this.bttaohd);
            this.Controls.Add(this.txtmakh);
            this.Controls.Add(this.txtmahd);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbmahd);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gridhoadon);
            this.Controls.Add(this.gridkhachhang);
            this.Name = "sudungdv";
            this.Text = "sudungdv";
            this.Load += new System.EventHandler(this.sudungdv_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridkhachhang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridhoadon)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView gridkhachhang;
        private System.Windows.Forms.DataGridView gridhoadon;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txttk;
        private System.Windows.Forms.Label lbmahd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtmahd;
        private System.Windows.Forms.TextBox txtmakh;
        private System.Windows.Forms.Button bttaohd;
        private System.Windows.Forms.Button btchitiet;
        private System.Windows.Forms.DateTimePicker datetime;
        private System.Windows.Forms.Button CapNhatbutton;
    }
}