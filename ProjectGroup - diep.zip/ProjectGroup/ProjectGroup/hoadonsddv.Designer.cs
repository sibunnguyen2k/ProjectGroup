﻿
namespace ProjectGroup
{
    partial class hoadonsddv
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.griddichvu = new System.Windows.Forms.DataGridView();
            this.gridndhddv = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtmadv = new System.Windows.Forms.TextBox();
            this.txtgia = new System.Windows.Forms.TextBox();
            this.txtsoluong = new System.Windows.Forms.TextBox();
            this.txtsotien = new System.Windows.Forms.TextBox();
            this.txtmahddv = new System.Windows.Forms.TextBox();
            this.txttongtien = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btchon = new System.Windows.Forms.Button();
            this.btbochon = new System.Windows.Forms.Button();
            this.bttinhtien = new System.Windows.Forms.Button();
            this.btluuhd = new System.Windows.Forms.Button();
            this.btthoat = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txttendv = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtdonvi = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.griddichvu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridndhddv)).BeginInit();
            this.SuspendLayout();
            // 
            // griddichvu
            // 
            this.griddichvu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.griddichvu.Location = new System.Drawing.Point(12, 51);
            this.griddichvu.Name = "griddichvu";
            this.griddichvu.RowHeadersWidth = 51;
            this.griddichvu.RowTemplate.Height = 24;
            this.griddichvu.Size = new System.Drawing.Size(690, 281);
            this.griddichvu.TabIndex = 0;
            this.griddichvu.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.griddichvu_CellMouseClick);
            // 
            // gridndhddv
            // 
            this.gridndhddv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridndhddv.Location = new System.Drawing.Point(13, 365);
            this.gridndhddv.Name = "gridndhddv";
            this.gridndhddv.RowHeadersWidth = 51;
            this.gridndhddv.RowTemplate.Height = 24;
            this.gridndhddv.Size = new System.Drawing.Size(838, 279);
            this.gridndhddv.TabIndex = 1;
            this.gridndhddv.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gridndhddv_CellMouseClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(726, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Mã DV";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(726, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Giá";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(726, 216);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Số Lượng";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(726, 271);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "Số Tiền";
            // 
            // txtmadv
            // 
            this.txtmadv.Location = new System.Drawing.Point(800, 91);
            this.txtmadv.Name = "txtmadv";
            this.txtmadv.Size = new System.Drawing.Size(150, 22);
            this.txtmadv.TabIndex = 6;
            // 
            // txtgia
            // 
            this.txtgia.Location = new System.Drawing.Point(800, 173);
            this.txtgia.Name = "txtgia";
            this.txtgia.Size = new System.Drawing.Size(84, 22);
            this.txtgia.TabIndex = 7;
            // 
            // txtsoluong
            // 
            this.txtsoluong.Location = new System.Drawing.Point(801, 213);
            this.txtsoluong.Name = "txtsoluong";
            this.txtsoluong.Size = new System.Drawing.Size(149, 22);
            this.txtsoluong.TabIndex = 8;
            // 
            // txtsotien
            // 
            this.txtsotien.Location = new System.Drawing.Point(801, 271);
            this.txtsotien.Name = "txtsotien";
            this.txtsotien.ReadOnly = true;
            this.txtsotien.Size = new System.Drawing.Size(149, 22);
            this.txtsotien.TabIndex = 9;
            // 
            // txtmahddv
            // 
            this.txtmahddv.Location = new System.Drawing.Point(905, 427);
            this.txtmahddv.Name = "txtmahddv";
            this.txtmahddv.Size = new System.Drawing.Size(164, 22);
            this.txtmahddv.TabIndex = 11;
            // 
            // txttongtien
            // 
            this.txttongtien.Location = new System.Drawing.Point(905, 501);
            this.txttongtien.Name = "txttongtien";
            this.txttongtien.Size = new System.Drawing.Size(164, 22);
            this.txttongtien.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(949, 389);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 17);
            this.label6.TabIndex = 14;
            this.label6.Text = "Mã HDDV";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(949, 468);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 17);
            this.label7.TabIndex = 15;
            this.label7.Text = "Tổng Tiền";
            // 
            // btchon
            // 
            this.btchon.Location = new System.Drawing.Point(1007, 120);
            this.btchon.Name = "btchon";
            this.btchon.Size = new System.Drawing.Size(75, 31);
            this.btchon.TabIndex = 18;
            this.btchon.Text = "Chọn";
            this.btchon.UseVisualStyleBackColor = true;
            this.btchon.Click += new System.EventHandler(this.btchon_Click);
            // 
            // btbochon
            // 
            this.btbochon.Location = new System.Drawing.Point(1007, 188);
            this.btbochon.Name = "btbochon";
            this.btbochon.Size = new System.Drawing.Size(75, 33);
            this.btbochon.TabIndex = 19;
            this.btbochon.Text = "Bỏ Chọn";
            this.btbochon.UseVisualStyleBackColor = true;
            this.btbochon.Click += new System.EventHandler(this.btbochon_Click);
            // 
            // bttinhtien
            // 
            this.bttinhtien.Location = new System.Drawing.Point(992, 265);
            this.bttinhtien.Name = "bttinhtien";
            this.bttinhtien.Size = new System.Drawing.Size(106, 28);
            this.bttinhtien.TabIndex = 20;
            this.bttinhtien.Text = "Tính Tiền";
            this.bttinhtien.UseVisualStyleBackColor = true;
            this.bttinhtien.Click += new System.EventHandler(this.bttinhtien_Click);
            // 
            // btluuhd
            // 
            this.btluuhd.Location = new System.Drawing.Point(890, 557);
            this.btluuhd.Name = "btluuhd";
            this.btluuhd.Size = new System.Drawing.Size(75, 23);
            this.btluuhd.TabIndex = 21;
            this.btluuhd.Text = "Lưu HĐ";
            this.btluuhd.UseVisualStyleBackColor = true;
            this.btluuhd.Click += new System.EventHandler(this.btluuhd_Click);
            // 
            // btthoat
            // 
            this.btthoat.Location = new System.Drawing.Point(1023, 557);
            this.btthoat.Name = "btthoat";
            this.btthoat.Size = new System.Drawing.Size(75, 23);
            this.btthoat.TabIndex = 22;
            this.btthoat.Text = "Thoát";
            this.btthoat.UseVisualStyleBackColor = true;
            this.btthoat.Click += new System.EventHandler(this.btthoat_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(726, 133);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 17);
            this.label5.TabIndex = 23;
            this.label5.Text = "Tên DV";
            // 
            // txttendv
            // 
            this.txttendv.Location = new System.Drawing.Point(801, 133);
            this.txttendv.Name = "txttendv";
            this.txttendv.Size = new System.Drawing.Size(149, 22);
            this.txttendv.TabIndex = 24;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(890, 176);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(12, 17);
            this.label8.TabIndex = 25;
            this.label8.Text = "/";
            // 
            // txtdonvi
            // 
            this.txtdonvi.Location = new System.Drawing.Point(905, 173);
            this.txtdonvi.Name = "txtdonvi";
            this.txtdonvi.Size = new System.Drawing.Size(45, 22);
            this.txtdonvi.TabIndex = 26;
            // 
            // hoadonsddv
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1142, 656);
            this.Controls.Add(this.txtdonvi);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txttendv);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btthoat);
            this.Controls.Add(this.btluuhd);
            this.Controls.Add(this.bttinhtien);
            this.Controls.Add(this.btbochon);
            this.Controls.Add(this.btchon);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txttongtien);
            this.Controls.Add(this.txtmahddv);
            this.Controls.Add(this.txtsotien);
            this.Controls.Add(this.txtsoluong);
            this.Controls.Add(this.txtgia);
            this.Controls.Add(this.txtmadv);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gridndhddv);
            this.Controls.Add(this.griddichvu);
            this.Name = "hoadonsddv";
            this.Text = "Hóa Đơn Sử Dụng Dịch Vụ";
            this.Load += new System.EventHandler(this.hoadonsddv_Load);
            ((System.ComponentModel.ISupportInitialize)(this.griddichvu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridndhddv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView griddichvu;
        private System.Windows.Forms.DataGridView gridndhddv;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtmadv;
        private System.Windows.Forms.TextBox txtgia;
        private System.Windows.Forms.TextBox txtsoluong;
        private System.Windows.Forms.TextBox txtsotien;
        private System.Windows.Forms.TextBox txtmahddv;
        private System.Windows.Forms.TextBox txttongtien;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btchon;
        private System.Windows.Forms.Button btbochon;
        private System.Windows.Forms.Button bttinhtien;
        private System.Windows.Forms.Button btluuhd;
        private System.Windows.Forms.Button btthoat;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txttendv;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtdonvi;
    }
}