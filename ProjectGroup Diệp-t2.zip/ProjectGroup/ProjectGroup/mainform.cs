﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class mainform : Form
    {
        public bool isThoat = true; // tạo biến ktra
        private int childFormNumber = 0;

        public mainform()
        {
            InitializeComponent();
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void ToolBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormNhanVien nhanvien = new FormNhanVien();
            nhanvien.ShowDialog();
            this.Hide();
        }

        private void StatusBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormKhachhang nhanvien = new FormKhachhang();
            nhanvien.ShowDialog();
            this.Hide();
        }

 
        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void mndx_Click(object sender, EventArgs e)
        {
            //isThoat = false;
            //this.Close();
            //if (MessageBox.Show("Bạn thật sự muốn đăng xuất! ", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) ;
            //Form1 f = new Form1();
            //f.Show();
            
        }

        private void mainform_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (isThoat)
                Application.Exit();
        }

        
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //loaiphong lp = new loaiphong();
            //lp.ShowDialog();
            //this.Hide();
        }

        private void đăngKíToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Dangky dk = new Dangky();
            dk.ShowDialog();
            this.Hide();
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isThoat = false;
            this.Close();
            if (MessageBox.Show("Bạn thật sự muốn đăng xuất! ", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) ;
            FormDangNhap f = new FormDangNhap();
            f.Show();
        }

        private void quảnLíNhânViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormNhanVien nv = new FormNhanVien();
            nv.ShowDialog();
        }

        private void quảnLíKháchHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormKhachhang kh = new FormKhachhang();
            kh.ShowDialog();
        }

        private void quảnLíKhoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormKhoNhap khonhap = new FormKhoNhap();
            khonhap.ShowDialog();
        }

        private void quảnLíDịchVụToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QuanLiDichVu dv = new QuanLiDichVu();
            dv.ShowDialog();
        }

        private void quảnLíHóaĐơnToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
