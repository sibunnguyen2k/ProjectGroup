﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class QuanLiDichVu : Form
    {
        public QuanLiDichVu()
        {
            InitializeComponent();
            HienThiGridView();
        }
        public void HienThiGridView()
        {
            
            DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "maloaiDV";
            column.HeaderText = "Mã Dịch Vụ";
            gridViewDichVu.Columns.Add(column);

            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "tenDV";
            column1.HeaderText = "Tên Dịch Vụ";
            gridViewDichVu.Columns.Add(column1);

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "donGia";
            column2.HeaderText = "Đơn Giá";
            gridViewDichVu.Columns.Add(column2);

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "donVi";
            column3.HeaderText = "Đơn vị";
            gridViewDichVu.Columns.Add(column3);
            
           
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            App_config configDB = new App_config();
            DataTable dt = new DataTable();


            String sql = " SELECT maloaiDV , tenDV, donGia, donVi";
            sql += " FROM loaiDV";

            dt = configDB.SelectDb(sql);
            
             gridViewDichVu.DataSource = dt;
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttonThemDV_Click(object sender, EventArgs e)
        {
            //điền mã tự động cho mã DV
            int count = 0;
            count = gridViewDichVu.Rows.Count;
            String ma1 = "DV";
            int ma2 = count;//-1=-1+1 trừ 1 hàng thừa cộng 1 hàng mới..
            maDVTextBox.Text = ma1 + ma2.ToString();
            

            App_config configDB = new App_config();
            String sqlThemDuLieu = "INSERT INTO loaiDV (maloaiDV , tenDV, donGia, donVi)";
            sqlThemDuLieu += "VALUES('" + maDVTextBox.Text + "',N'" + tenDVTextBox.Text + "'";
            sqlThemDuLieu += "," + giaDVTextBox.Text + ",N'" + donViTextBox.Text + "');";
            configDB.InsertDb(sqlThemDuLieu);

            Form1_Load(sender, e);
        }

        private void buttonSuaDV_Click(object sender, EventArgs e)
        {
            App_config configDB = new App_config();
            String sqlThemDuLieu = "UPDATE loaiDV SET tenDV=N'"+tenDVTextBox.Text+"'";  
            sqlThemDuLieu += ",donGia=" + giaDVTextBox.Text + ",donVi=N'" + donViTextBox.Text + "'";
            sqlThemDuLieu += " WHERE maloaiDV='"+maDVTextBox.Text+"'";
            configDB.InsertDb(sqlThemDuLieu);

            Form1_Load(sender, e);
        }

        private void gridViewDichVu_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            maDVTextBox.Text = gridViewDichVu.CurrentRow.Cells[0].Value.ToString();
            tenDVTextBox.Text = gridViewDichVu.CurrentRow.Cells[1].Value.ToString();
            giaDVTextBox.Text = gridViewDichVu.CurrentRow.Cells[2].Value.ToString();
            donViTextBox.Text = gridViewDichVu.CurrentRow.Cells[3].Value.ToString();
        }

        private void buttonXoaDV_Click(object sender, EventArgs e)
        {
            DialogResult dlr = MessageBox.Show("Bạn muốn xóa?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dlr == DialogResult.Yes)
            {
                App_config configDB = new App_config();
                 String sqlThemDuLieu = "DELETE FROM loaiDV ";
                 sqlThemDuLieu += " WHERE maloaiDV='" + maDVTextBox.Text + "'";
                configDB.InsertDb(sqlThemDuLieu);
                 Form1_Load(sender, e);

            }

            
        }

        private void buttonThoatDV_Click(object sender, EventArgs e)
        {
            DialogResult dlr = MessageBox.Show("Bạn muốn thoát chương trình?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dlr == DialogResult.Yes) this.Close();

        }
    }
}
