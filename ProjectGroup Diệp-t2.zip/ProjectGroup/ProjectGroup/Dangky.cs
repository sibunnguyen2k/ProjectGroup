﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjectGroup
{
    public partial class Dangky : Form
    {
        public Dangky()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
      
        private void btDangky_Click(object sender, EventArgs e)
        {

            AccessData acc = new AccessData();
            SqlDataReader reader = acc.ExcuteReader("Select Username from Taikhoan where Username='"+UnametextBox.Text+"'"); //đọc với lệnh select
            if(reader.Read()==false)
            {
                if (PasstextBox.Text.Equals(Xacnhanpass.Text))
                {
                    App_config config = new App_config();
                    String sql = "insert into Taikhoan (LoaiTK,Username,password)";
                    sql += " values('" + "KH" + "',N'" + UnametextBox.Text + "',N'" + PasstextBox.Text + "')";
                    config.InsertDb(sql);
                    //MessageBox.Show(sql);
                    MessageBox.Show("Đăng ký thành công!!");
                }
                else
                {
                    MessageBox.Show("Xác nhân mật khẩu không trùng khớp", "Warring", MessageBoxButtons.OK);
                }
            }
            else
            {
                MessageBox.Show("Tên đăng nhập đã tồn tại");
            }
        }

        private void Dangky_Enter(object sender, EventArgs e)
        {
            btDangky_Click(sender, e);
        }

        private void ckpw_CheckedChanged(object sender, EventArgs e)
        {

            //cách 2 để PasswordChar theo ý
            if (checkBox1.Checked)
            {
                PasstextBox.PasswordChar = '*';
                PasstextBox.BringToFront();
                PasstextBox.PasswordChar = '\0';
                Xacnhanpass.PasswordChar = '*';
                Xacnhanpass.BringToFront();
                Xacnhanpass.PasswordChar = '\0';
            }
            else
            {
                PasstextBox.PasswordChar = '\0';
                PasstextBox.BringToFront();
                PasstextBox.PasswordChar = '*';
                Xacnhanpass.PasswordChar = '\0';
                Xacnhanpass.BringToFront();
                Xacnhanpass.PasswordChar = '*';
            }
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            ckpw_CheckedChanged(sender,e);
        }
    }
}
