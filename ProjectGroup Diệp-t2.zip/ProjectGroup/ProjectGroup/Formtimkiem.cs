﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class FormtimkiemKH : Form
    {
        public FormtimkiemKH()
        {
            InitializeComponent();
            //LoadGridByKeyword();
            HienThiGirdView();
        }
        public void HienThiGirdView()
        {
            DataTable dt = new DataTable();
            App_config configdb = new App_config();

            String sql = "SELECT maKH,nameKH,CMND,dienthoai,quocTich,";
            sql += " CASE WHEN gioitinh = 'False' THEN N'Nữ' ";
            sql += " WHEN gioitinh = 'True' THEN N'Nam' ";
            sql += " END as gioitinh";
            sql += " FROM Khachhang ";

            dt = configdb.SelectDb(sql);

             DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "maKH";
            column1.HeaderText = "Mã KH";
            timkiemKHdataGridView.Columns.Add(column1);
            timkiemKHdataGridView.Columns[0].Width = 70;

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "nameKH";
            column2.HeaderText = "Tên KH";
            timkiemKHdataGridView.Columns.Add(column2);
            timkiemKHdataGridView.Columns[1].Width = 150;

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "CMND";
            column3.HeaderText = "CMND/Hộ chiếu";
            timkiemKHdataGridView.Columns.Add(column3);
            timkiemKHdataGridView.Columns[2].Width = 120;

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "gioitinh";
            column4.HeaderText = "Nam/Nữ";
            timkiemKHdataGridView.Columns.Add(column4);

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.DataPropertyName = "dienthoai";
            column5.HeaderText = "Điện thoại";
            timkiemKHdataGridView.Columns.Add(column5);
            timkiemKHdataGridView.Columns[4].Width = 130;

            DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
            column6.DataPropertyName = "quocTich";
            column6.HeaderText = "Quốc tịch";
            timkiemKHdataGridView.Columns.Add(column6);
            timkiemKHdataGridView.Columns[5].Width = 80;

            timkiemKHdataGridView.DataSource = dt;
        }
            private void FormtimkiemKH_Load(object sender, EventArgs e)
        {

        }
        public void LoadGridByKeyword()
        {
            App_config configdb = new App_config();
            timkiemKHdataGridView.DataSource = configdb.SelectDb("SELECT *FROM Khachhang WHERE nameKH LIKE '%" + textBox1.Text + "%' ");
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            LoadGridByKeyword();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormtimkiemKH_Load_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }
    }

       
    }
