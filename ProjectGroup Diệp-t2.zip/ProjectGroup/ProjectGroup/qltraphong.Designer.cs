﻿
namespace ProjectGroup
{
    partial class qltraphong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtnmpt = new System.Windows.Forms.TextBox();
            this.bttk = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dtgview2 = new System.Windows.Forms.DataGridView();
            this.dtgview1 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.bttp = new System.Windows.Forms.Button();
            this.bttt = new System.Windows.Forms.Button();
            this.btthd = new System.Windows.Forms.Button();
            this.btthoat = new System.Windows.Forms.Button();
            this.txtmpt = new System.Windows.Forms.TextBox();
            this.txtmnv = new System.Windows.Forms.TextBox();
            this.txtmkh = new System.Windows.Forms.TextBox();
            this.txtsno = new System.Windows.Forms.TextBox();
            this.txttt = new System.Windows.Forms.TextBox();
            this.txtsp = new System.Windows.Forms.TextBox();
            this.txtgia = new System.Windows.Forms.TextBox();
            this.datetime2 = new System.Windows.Forms.DateTimePicker();
            this.datetime1 = new System.Windows.Forms.DateTimePicker();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgview2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgview1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtnmpt);
            this.groupBox1.Controls.Add(this.bttk);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 47);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1191, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tìm kiếm phiếu thuê";
            // 
            // txtnmpt
            // 
            this.txtnmpt.Location = new System.Drawing.Point(336, 43);
            this.txtnmpt.Name = "txtnmpt";
            this.txtnmpt.Size = new System.Drawing.Size(291, 28);
            this.txtnmpt.TabIndex = 2;
            this.txtnmpt.TextChanged += new System.EventHandler(this.txtnmpt_TextChanged);
            // 
            // bttk
            // 
            this.bttk.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttk.Location = new System.Drawing.Point(919, 32);
            this.bttk.Name = "bttk";
            this.bttk.Size = new System.Drawing.Size(134, 31);
            this.bttk.TabIndex = 1;
            this.bttk.Text = "Tìm kiếm";
            this.bttk.UseVisualStyleBackColor = true;
            this.bttk.Click += new System.EventHandler(this.bttk_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(130, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nhập mã phiếu thuê";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dtgview2);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 434);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(397, 347);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Giá phòng";
            // 
            // dtgview2
            // 
            this.dtgview2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgview2.Location = new System.Drawing.Point(6, 34);
            this.dtgview2.Name = "dtgview2";
            this.dtgview2.RowHeadersWidth = 51;
            this.dtgview2.RowTemplate.Height = 24;
            this.dtgview2.Size = new System.Drawing.Size(385, 307);
            this.dtgview2.TabIndex = 0;
            this.dtgview2.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dtgview2_CellMouseClick);
            // 
            // dtgview1
            // 
            this.dtgview1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgview1.Location = new System.Drawing.Point(39, 169);
            this.dtgview1.Name = "dtgview1";
            this.dtgview1.RowHeadersWidth = 51;
            this.dtgview1.RowTemplate.Height = 24;
            this.dtgview1.Size = new System.Drawing.Size(1136, 259);
            this.dtgview1.TabIndex = 2;
            this.dtgview1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dtgview1_CellMouseClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(434, 468);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Mã phiếu thuê";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(438, 520);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Mã nhân viên";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(438, 565);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Mã khách hàng";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(438, 616);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Số ngày ở";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(443, 669);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 20);
            this.label6.TabIndex = 7;
            this.label6.Text = "Tổng tiền";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(819, 468);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 20);
            this.label7.TabIndex = 8;
            this.label7.Text = "Ngày đến";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(819, 518);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 20);
            this.label8.TabIndex = 9;
            this.label8.Text = "Ngày đi";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(819, 565);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 20);
            this.label9.TabIndex = 10;
            this.label9.Text = "Số phòng";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(819, 616);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 20);
            this.label10.TabIndex = 11;
            this.label10.Text = "Giá";
            // 
            // bttp
            // 
            this.bttp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttp.Location = new System.Drawing.Point(531, 740);
            this.bttp.Name = "bttp";
            this.bttp.Size = new System.Drawing.Size(119, 35);
            this.bttp.TabIndex = 12;
            this.bttp.Text = "Trả phòng";
            this.bttp.UseVisualStyleBackColor = true;
            this.bttp.Click += new System.EventHandler(this.bttp_Click);
            // 
            // bttt
            // 
            this.bttt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttt.Location = new System.Drawing.Point(671, 740);
            this.bttt.Name = "bttt";
            this.bttt.Size = new System.Drawing.Size(134, 35);
            this.bttt.TabIndex = 13;
            this.bttt.Text = "Tính tiền";
            this.bttt.UseVisualStyleBackColor = true;
            this.bttt.Click += new System.EventHandler(this.bttt_Click);
            // 
            // btthd
            // 
            this.btthd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btthd.Location = new System.Drawing.Point(823, 740);
            this.btthd.Name = "btthd";
            this.btthd.Size = new System.Drawing.Size(242, 35);
            this.btthd.TabIndex = 14;
            this.btthd.Text = "Tạo hóa đơn thanh toán";
            this.btthd.UseVisualStyleBackColor = true;
            //this.btthd.Click += new System.EventHandler(this.btthd_Click);
            // 
            // btthoat
            // 
            this.btthoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btthoat.Location = new System.Drawing.Point(1079, 740);
            this.btthoat.Name = "btthoat";
            this.btthoat.Size = new System.Drawing.Size(96, 35);
            this.btthoat.TabIndex = 15;
            this.btthoat.Text = "Thoát";
            this.btthoat.UseVisualStyleBackColor = true;
            this.btthoat.Click += new System.EventHandler(this.btthoat_Click);
            // 
            // txtmpt
            // 
            this.txtmpt.Location = new System.Drawing.Point(585, 468);
            this.txtmpt.Name = "txtmpt";
            this.txtmpt.Size = new System.Drawing.Size(171, 22);
            this.txtmpt.TabIndex = 16;
            // 
            // txtmnv
            // 
            this.txtmnv.Location = new System.Drawing.Point(585, 518);
            this.txtmnv.Name = "txtmnv";
            this.txtmnv.Size = new System.Drawing.Size(171, 22);
            this.txtmnv.TabIndex = 17;
            // 
            // txtmkh
            // 
            this.txtmkh.Location = new System.Drawing.Point(585, 565);
            this.txtmkh.Name = "txtmkh";
            this.txtmkh.Size = new System.Drawing.Size(171, 22);
            this.txtmkh.TabIndex = 18;
            // 
            // txtsno
            // 
            this.txtsno.Enabled = false;
            this.txtsno.Location = new System.Drawing.Point(585, 613);
            this.txtsno.Name = "txtsno";
            this.txtsno.Size = new System.Drawing.Size(171, 22);
            this.txtsno.TabIndex = 19;
            this.txtsno.TextChanged += new System.EventHandler(this.txtsno_TextChanged);
            // 
            // txttt
            // 
            this.txttt.Enabled = false;
            this.txttt.Location = new System.Drawing.Point(585, 667);
            this.txttt.Name = "txttt";
            this.txttt.Size = new System.Drawing.Size(171, 22);
            this.txttt.TabIndex = 20;
            // 
            // txtsp
            // 
            this.txtsp.Location = new System.Drawing.Point(965, 565);
            this.txtsp.Name = "txtsp";
            this.txtsp.Size = new System.Drawing.Size(200, 22);
            this.txtsp.TabIndex = 22;
            // 
            // txtgia
            // 
            this.txtgia.Location = new System.Drawing.Point(965, 616);
            this.txtgia.Name = "txtgia";
            this.txtgia.Size = new System.Drawing.Size(200, 22);
            this.txtgia.TabIndex = 23;
            // 
            // datetime2
            // 
            this.datetime2.CustomFormat = "dd/ MM/yyyy";
            this.datetime2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datetime2.Location = new System.Drawing.Point(965, 518);
            this.datetime2.Name = "datetime2";
            this.datetime2.Size = new System.Drawing.Size(200, 22);
            this.datetime2.TabIndex = 24;
            // 
            // datetime1
            // 
            this.datetime1.CustomFormat = "dd/ MM/yyyy";
            this.datetime1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datetime1.Location = new System.Drawing.Point(965, 468);
            this.datetime1.Name = "datetime1";
            this.datetime1.Size = new System.Drawing.Size(200, 22);
            this.datetime1.TabIndex = 25;
            // 
            // qltraphong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1243, 793);
            this.Controls.Add(this.datetime1);
            this.Controls.Add(this.datetime2);
            this.Controls.Add(this.txtgia);
            this.Controls.Add(this.txtsp);
            this.Controls.Add(this.txttt);
            this.Controls.Add(this.txtsno);
            this.Controls.Add(this.txtmkh);
            this.Controls.Add(this.txtmnv);
            this.Controls.Add(this.txtmpt);
            this.Controls.Add(this.btthoat);
            this.Controls.Add(this.btthd);
            this.Controls.Add(this.bttt);
            this.Controls.Add(this.bttp);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtgview1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "qltraphong";
            this.Text = "Quản lý trả phòng";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgview2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgview1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtnmpt;
        private System.Windows.Forms.Button bttk;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dtgview2;
        private System.Windows.Forms.DataGridView dtgview1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button bttp;
        private System.Windows.Forms.Button bttt;
        private System.Windows.Forms.Button btthd;
        private System.Windows.Forms.Button btthoat;
        private System.Windows.Forms.TextBox txtmpt;
        private System.Windows.Forms.TextBox txtmnv;
        private System.Windows.Forms.TextBox txtmkh;
        private System.Windows.Forms.TextBox txtsno;
        private System.Windows.Forms.TextBox txttt;
        private System.Windows.Forms.TextBox txtsp;
        private System.Windows.Forms.TextBox txtgia;
        private System.Windows.Forms.DateTimePicker datetime2;
        private System.Windows.Forms.DateTimePicker datetime1;
    }
}