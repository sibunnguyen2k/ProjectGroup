﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class FormThongkePhong : Form
    {
        public FormThongkePhong()
        {
            InitializeComponent();
            HienthigridviewThongke();
        }

        public void HienthigridviewThongke()
        {
            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "maHD";
            column1.HeaderText = "Mã HD";
            ThongKedataGridView.Columns.Add(column1);

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "maKH";
            column2.HeaderText = "Mã KH";
            ThongKedataGridView.Columns.Add(column2);

            DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
            column6.DataPropertyName = "maNV";
            column6.HeaderText = "Mã NV";
            ThongKedataGridView.Columns.Add(column6);

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "maPT";
            column3.HeaderText = "Mã PT";
            ThongKedataGridView.Columns.Add(column3);

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "ngayDi";
            column4.HeaderText = "Ngày đi";
            ThongKedataGridView.Columns.Add(column4);

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.DataPropertyName = "tongTien";
            column5.HeaderText = "Tổng tiền";
            ThongKedataGridView.Columns.Add(column5);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dlr = MessageBox.Show("Bạn muốn thoát chương trình?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dlr == DialogResult.Yes) this.Close();
        }

        private void FormThongkePhong_Load(object sender, EventArgs e)
        {
        }

        private void ThongKebutton_Click(object sender, EventArgs e)
        {

            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            String sql = "SELECT maHD,maKH,maNV,maPT,ngayDi,tongTien";
            sql += " FROM Hoadon";
            //sql += "WHERE ngayDi BETWEEN " + TuNgay.Text + "AND" + denNgay.Text;
            sql += " WHERE (ngayDi >=   CONVERT(datetime, '" + TuNgay.Value.Date + "', 103)  AND ngayDi <= CONVERT(datetime, '" + denNgay.Value.Date + "', 103))";
            dt = configdb.SelectDb(sql);
            ThongKedataGridView.DataSource = dt;
            TinhtongDoanhthu();
        }

        public void TinhtongDoanhthu()
        {
            int sc = ThongKedataGridView.Rows.Count;
            float tongtien = 0;
            for (int i = 0; i < sc - 1; i++)
            { tongtien += float.Parse(ThongKedataGridView.Rows[i].Cells[5].Value.ToString()); }
            TongDoanhThutextBox.Text = tongtien.ToString();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
