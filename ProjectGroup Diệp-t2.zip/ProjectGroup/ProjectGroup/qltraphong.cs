﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class qltraphong : Form
    {
        public qltraphong()
        {
            InitializeComponent();
            hienthigview2();
            HienthiGridviewDSTHUEPHONG();
        }
        public void HienthiGridviewDSTHUEPHONG()
        {
            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            String sql = "SELECT maPT,maKH,convert(varchar,ngayDen,103) as ngayDen, convert(varchar,ngayDi,103) as ngayDi,soPhong";
            sql += " FROM DSThuePhong ";
            dt = configdb.SelectDb(sql);

            if (dt.Rows.Count == null)
            {
                DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
                column1.DataPropertyName = "maPT";
                column1.HeaderText = "Mã PT";
                dtgview1.Columns.Add(column1);

                DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
                column2.DataPropertyName = "maKH";
                column2.HeaderText = "Mã KH";
                dtgview1.Columns.Add(column2);

                DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
                column3.DataPropertyName = "ngayDen";
                column3.HeaderText = "Ngày đến";
                dtgview1.Columns.Add(column3);

                DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
                column4.DataPropertyName = "ngayDi";
                column4.HeaderText = "Ngày đi";
                dtgview1.Columns.Add(column4);

                DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
                column5.DataPropertyName = "soPhong";
                column5.HeaderText = "Số phòng";
                dtgview1.Columns.Add(column5);

                dtgview1.DataSource = dt;
            }
            else
            {
                dtgview1.DataSource = dt;
            }

        }
        public void LoadGridByKeyword()
        {
            App_config cf = new App_config();
            dtgview1.DataSource = cf.SelectDb(" SELECT * FROM DSThuePhong WHERE maPT like '%" + txtnmpt.Text + "%' or maKH like '%"+txtnmpt.Text+"%'");
        }
        public void hienthigview2()
        {
            App_config cf = new App_config();
            DataTable dt = new DataTable();
            String sql = "select soPhong,gia from Phong ";
            sql += "inner join Loaiphong on Loaiphong.maLP=Phong.maLP ";
            dt = cf.SelectDb(sql);
            if(dt.Rows.Count==0)
            {
                DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
                column.DataPropertyName = "soPhong";
                column.HeaderText = "Số phòng";
                dtgview2.Columns.Add(column);
               // dtgview2.Columns[0].Width = 10;

                DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
                column2.DataPropertyName = "gia";
                column2.HeaderText = "Giá(ngày)";
                dtgview2.Columns.Add(column2);
               // dtgview2.Columns[1].Width = 30;

                dtgview2.DataSource = dt;
            }
            else
            {
                dtgview2.DataSource = dt;
            }
            
        }
        private void btthoat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc muốn thoát!", "Thông báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) ;
            // this.Close();
            mainform mf = new mainform();
            mf.Show();
            this.Hide();
        }

        private void dtgview1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtmpt.Text= dtgview1.CurrentRow.Cells[0].Value.ToString();
            txtmkh.Text= dtgview1.CurrentRow.Cells[1].Value.ToString();
            txtsp.Text= dtgview1.CurrentRow.Cells[4].Value.ToString();
            int nam = Int32.Parse(dtgview1.CurrentRow.Cells[2].Value.ToString().Split('/')[2]);
            int thang = Int32.Parse(dtgview1.CurrentRow.Cells[2].Value.ToString().Split('/')[1]);
            int ngay = Int32.Parse(dtgview1.CurrentRow.Cells[2].Value.ToString().Split('/')[0]);
            //đưa lên datetimespeaker
            datetime1.Value = new DateTime(nam, thang, ngay);
        }

        private void dtgview2_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtsp.Text = dtgview2.CurrentRow.Cells[0].Value.ToString();
            txtgia.Text = dtgview2.CurrentRow.Cells[1].Value.ToString();
        }

        private void txtnmpt_TextChanged(object sender, EventArgs e)
        {
            LoadGridByKeyword();
        }

        private void bttk_Click(object sender, EventArgs e)
        {
            LoadGridByKeyword();
        }

        private void txtsno_TextChanged(object sender, EventArgs e)
        {


        }
        private void tinhngay()
        {
            App_config cf = new App_config();
            DataTable dt = new DataTable();
            String sql = " SELECT DATEDIFF(day,convert(datetime ,'" + datetime1.Value + "',103), convert(datetime, '" + datetime2.Value + "',103))";
            dt = cf.SelectDb(sql);
            txtsno.Text = dt.Rows[0][0].ToString();
        }
        public void tongtien()
        {
            App_config cf = new App_config();
            DataTable dt = new DataTable();  
                int gia = Convert.ToInt32(txtgia.Text);
                int tinhngay = Convert.ToInt32(txtsno.Text);
                int tongtien = gia * tinhngay;
                txttt.Text = tongtien.ToString();
            
        }
        private void bttp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Trả phòng thành công. Tính tiền và tạo hóa đơn");
           
        }

        private void bttt_Click(object sender, EventArgs e)
        {
            tinhngay();
            tongtien();
        }

        //private void btthd_Click(object sender, EventArgs e)
        //{
        //    hoadon hd = new hoadon();
        //    hd.Show();
        //    this.Hide();
        //}
    }
}
