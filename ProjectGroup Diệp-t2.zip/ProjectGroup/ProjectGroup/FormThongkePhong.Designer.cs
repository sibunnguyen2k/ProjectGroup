﻿
namespace ProjectGroup
{
    partial class FormThongkePhong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TuNgay = new System.Windows.Forms.DateTimePicker();
            this.denNgay = new System.Windows.Forms.DateTimePicker();
            this.ThongKedataGridView = new System.Windows.Forms.DataGridView();
            this.ThongKebutton = new System.Windows.Forms.Button();
            this.Thoatbutton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.TongDoanhThutextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.ThongKedataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Từ ngày";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(373, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Đến ngày";
            // 
            // TuNgay
            // 
            this.TuNgay.CustomFormat = "dd/MM/yyyy";
            this.TuNgay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.TuNgay.Location = new System.Drawing.Point(150, 59);
            this.TuNgay.Name = "TuNgay";
            this.TuNgay.Size = new System.Drawing.Size(200, 22);
            this.TuNgay.TabIndex = 3;
            // 
            // denNgay
            // 
            this.denNgay.CustomFormat = "dd/MM/yyyy";
            this.denNgay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.denNgay.Location = new System.Drawing.Point(458, 64);
            this.denNgay.Name = "denNgay";
            this.denNgay.Size = new System.Drawing.Size(200, 22);
            this.denNgay.TabIndex = 4;
            // 
            // ThongKedataGridView
            // 
            this.ThongKedataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ThongKedataGridView.Location = new System.Drawing.Point(64, 162);
            this.ThongKedataGridView.Name = "ThongKedataGridView";
            this.ThongKedataGridView.RowHeadersWidth = 51;
            this.ThongKedataGridView.RowTemplate.Height = 24;
            this.ThongKedataGridView.Size = new System.Drawing.Size(694, 261);
            this.ThongKedataGridView.TabIndex = 5;
            // 
            // ThongKebutton
            // 
            this.ThongKebutton.Location = new System.Drawing.Point(346, 117);
            this.ThongKebutton.Name = "ThongKebutton";
            this.ThongKebutton.Size = new System.Drawing.Size(128, 30);
            this.ThongKebutton.TabIndex = 6;
            this.ThongKebutton.Text = "Thống kê";
            this.ThongKebutton.UseVisualStyleBackColor = true;
            this.ThongKebutton.Click += new System.EventHandler(this.ThongKebutton_Click);
            // 
            // Thoatbutton
            // 
            this.Thoatbutton.Location = new System.Drawing.Point(516, 117);
            this.Thoatbutton.Name = "Thoatbutton";
            this.Thoatbutton.Size = new System.Drawing.Size(96, 30);
            this.Thoatbutton.TabIndex = 7;
            this.Thoatbutton.Text = "Thoát";
            this.Thoatbutton.UseVisualStyleBackColor = true;
            this.Thoatbutton.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(367, 451);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "Tổng doanh thu:";
            // 
            // TongDoanhThutextBox
            // 
            this.TongDoanhThutextBox.Location = new System.Drawing.Point(504, 451);
            this.TongDoanhThutextBox.Name = "TongDoanhThutextBox";
            this.TongDoanhThutextBox.Size = new System.Drawing.Size(154, 22);
            this.TongDoanhThutextBox.TabIndex = 9;
            this.TongDoanhThutextBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // FormThongkePhong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(873, 509);
            this.Controls.Add(this.TongDoanhThutextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Thoatbutton);
            this.Controls.Add(this.ThongKebutton);
            this.Controls.Add(this.ThongKedataGridView);
            this.Controls.Add(this.denNgay);
            this.Controls.Add(this.TuNgay);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormThongkePhong";
            this.Text = "Thống kê phòng";
            this.Load += new System.EventHandler(this.FormThongkePhong_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ThongKedataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker TuNgay;
        private System.Windows.Forms.DateTimePicker denNgay;
        private System.Windows.Forms.DataGridView ThongKedataGridView;
        private System.Windows.Forms.Button ThongKebutton;
        private System.Windows.Forms.Button Thoatbutton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TongDoanhThutextBox;
    }
}