﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class sudungdv : Form
    {
        public sudungdv()
        {
            InitializeComponent();
            HienThiGirdView();
            loadtextbox();
            hienthigrid1();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        public void loadtextbox()
        {
            txtmakh.DataBindings.Clear();
            txtmakh.DataBindings.Add("text", gridkhachhang.DataSource, "maKH");
        }
        public void HienThiGirdView()
        {
            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            String sql = "SELECT maKH,nameKH,CMND,";
            sql += " CASE WHEN gioitinh = 'False' THEN N'Nữ' ";
            sql += " WHEN gioitinh = 'True' THEN N'Nam' ";
            sql += " END as gioitinh,";
            sql += " dienthoai,quocTich";
            sql += " FROM Khachhang ";

            dt = configdb.SelectDb(sql);
            if (dt.Rows.Count == 0)
            {
                DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
                column1.DataPropertyName = "maKH";
                column1.HeaderText = "Mã KH";
                gridkhachhang.Columns.Add(column1);
                gridkhachhang.Columns[0].Width = 50;

                DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
                column2.DataPropertyName = "nameKH";
                column2.HeaderText = "Tên KH";
                gridkhachhang.Columns.Add(column2);
                gridkhachhang.Columns[1].Width = 150;

                DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
                column3.DataPropertyName = "CMND";
                column3.HeaderText = "CMND";
                gridkhachhang.Columns.Add(column3);
                gridkhachhang.Columns[2].Width = 80;

                DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
                column4.DataPropertyName = "gioitinh";
                column4.HeaderText = "Giới tính";
                gridkhachhang.Columns.Add(column4);

                DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
                column5.DataPropertyName = "diemThoai";
                column5.HeaderText = "Điện thoại";
                gridkhachhang.Columns.Add(column5);
                gridkhachhang.Columns[4].Width = 130;

                DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
                column6.DataPropertyName = "quocTich";
                column6.HeaderText = "Quốc tịch";
                gridkhachhang.Columns.Add(column6);
                gridkhachhang.Columns[5].Width = 80;

                gridkhachhang.DataSource = dt;
            }
            else
            {
                gridkhachhang.DataSource = dt;
            }
        }
        public void loadkey()
        {
            App_config app = new App_config();
            gridkhachhang.DataSource = app.SelectDb(" SELECT * FROM Khachhang WHERE maKH like '%" + txttk.Text + "%'");

        }
        private void txttk_TextChanged(object sender, EventArgs e)
        {
            loadkey();
        }
        private string CreateHang(String tiento)
        {
            string key = tiento;
            int t = gridhoadon.Rows.Count;
            key = key + t;
            return key;
        }

        public void hienthigrid1()
        {
            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            String sql = "SELECT maHDDV , maKH, CONVERT(VARCHAR,ngaytao,103) AS Ngaytao ,tongdoanhthudv FROM hoadondv";
            dt = configdb.SelectDb(sql);

            if(gridhoadon.Rows.Count == null)
            {

                DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
                column1.DataPropertyName = "maHDDV";
                column1.HeaderText = "Mã Hóa Đơn DV";
                gridhoadon.Columns.Add(column1);

                DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
                column2.DataPropertyName = "maKH";
                column2.HeaderText = "Mã KH";
                gridhoadon.Columns.Add(column2);
                gridhoadon.Columns[1].Width = 80;

                DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
                column3.DataPropertyName = "ngaytao";
                column3.HeaderText = "Ngày Tạo";
                gridhoadon.Columns.Add(column3);
                gridhoadon.Columns[2].Width = 30;

                DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
                column4.DataPropertyName = "tongdoanhthudv";
                column4.HeaderText = " Tổng doanh thu DV";
                gridhoadon.Columns.Add(column4);
                gridhoadon.Columns[3].Width = 50;

                gridhoadon.DataSource = dt;
            }
            gridhoadon.DataSource = dt;
        }
        private void gridkhachhang_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtmahd.Text = CreateHang("HDDV");
            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            String sql = "INSERT INTO hoadondv(maHDDV , maKH, ngaytao, tongdoanhthudv)";
            sql += " VALUES (N'" + txtmahd.Text + "'";
            sql += ",N'" + txtmakh.Text + "'";
            sql += ",CONVERT (Datetime ,'"+datetime.Text + "',103)";
            sql += ",null";
            sql += ");";
            int sosanh = configdb.InsertDb(sql);
            if(sosanh == 0)
            {
                MessageBox.Show("Không tạo được hóa đơn!!!");
            }
            else if(sosanh == -1)
            {
                MessageBox.Show("!!!");
            }
            else
            {
                MessageBox.Show("Tạo hóa đơn thành công!!!");
                hienthigrid1();
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            hoadonsddv hoadonsddv = new hoadonsddv(txtmahd.Text);
            hoadonsddv.Show();

        }

        private void CapNhatbutton_Click(object sender, EventArgs e)
        {
            hienthigrid1();
        }
    }
}
