﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class FormNhanVien : Form
    {
        public FormNhanVien()
        {
            InitializeComponent();
            loadDuLieuComboboxChucVu();
            HienThiGridView();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void HoTentextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void FormNhanVien_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            //String sql = "SELECT maNV,Username,nameNV,Birth,CMND,gioitinh,diaChi,dienThoai,email,quocTich,bangCap,maCV FROM Nhanvien";
            String sql = "SELECT maNV,Username,nameNV,";
            sql += " CONVERT(VARCHAR,Birth,103) AS Birth,";
            sql += " CMND,";
            sql += " CASE WHEN gioitinh = 'True' THEN N'Nữ'";
            sql += " WHEN gioitinh = 'False' THEN 'Nam'";
            sql += " END AS gioitinh,";
            sql += " diaChi,dienThoai,email,quocTich,bangCap,";
            sql += " tenCV, chucVu.maCV";
            sql += " FROM dbo.Nhanvien";
            sql += " INNER JOIN dbo.chucVu ON chucVu.maCV = Nhanvien.maCV";
            dt = configdb.SelectDb(sql);
            NhanViendataGridView.DataSource = dt;
        }
        public void HienThiGridView()
        {

                DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
                column1.DataPropertyName = "maNV";
                column1.HeaderText = "Mã NV";
                NhanViendataGridView.Columns.Add(column1);

                DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
                column2.DataPropertyName = "Username";
                column2.HeaderText = "Username";
                NhanViendataGridView.Columns.Add(column2);

                DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
                column3.DataPropertyName = "nameNV";
                column3.HeaderText = "Tên NV";
                NhanViendataGridView.Columns.Add(column3);

                DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
                column4.DataPropertyName = "Birth";
                column4.HeaderText = "Ngày sinh";
                NhanViendataGridView.Columns.Add(column4);

                DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
                column5.DataPropertyName = "CMND";
                column5.HeaderText = "Số CMND";
                NhanViendataGridView.Columns.Add(column5);

                DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
                column6.DataPropertyName = "gioitinh";
                column6.HeaderText = "Giới Tính";
                NhanViendataGridView.Columns.Add(column6);

                DataGridViewTextBoxColumn column7 = new DataGridViewTextBoxColumn();
                column7.DataPropertyName = "diaChi";
                column7.HeaderText = "Địa Chỉ";
                NhanViendataGridView.Columns.Add(column7);

                DataGridViewTextBoxColumn column8 = new DataGridViewTextBoxColumn();
                column8.DataPropertyName = "dienThoai";
                column8.HeaderText = "SĐT";
                NhanViendataGridView.Columns.Add(column8);

                DataGridViewTextBoxColumn column9 = new DataGridViewTextBoxColumn();
                column9.DataPropertyName = "email";
                column9.HeaderText = "Email";
                NhanViendataGridView.Columns.Add(column9);

                DataGridViewTextBoxColumn column10 = new DataGridViewTextBoxColumn();
                column10.DataPropertyName = "quocTich";
                column10.HeaderText = "Quốc tịch";
                NhanViendataGridView.Columns.Add(column10);

                DataGridViewTextBoxColumn column11 = new DataGridViewTextBoxColumn();
                column11.DataPropertyName = "bangCap";
                column11.HeaderText = "Trình độ";
                NhanViendataGridView.Columns.Add(column11);

                DataGridViewTextBoxColumn column13 = new DataGridViewTextBoxColumn();
                column13.DataPropertyName = "tenCV";
                column13.HeaderText = "Chức vụ";
                NhanViendataGridView.Columns.Add(column13);

                DataGridViewTextBoxColumn column12 = new DataGridViewTextBoxColumn();
                column12.DataPropertyName = "maCV";
                column12.HeaderText = "Mã CV";
                NhanViendataGridView.Columns.Add(column12);
                column12.Visible = false;
            }
        public void loadDuLieuComboboxChucVu()
        {
            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            String sql = "SELECT maCV,tenCV FROM chucVu";
            //Hứng dữ liệu trả về từ sql vào datatable
            dt =configdb.SelectDb(sql);
            // gán dt vào combobox
            ChucVucomboBox.DataSource = new BindingSource(dt, null);
            // gán hiển thị và giá trị dữ liệu cho combobox
            ChucVucomboBox.DisplayMember = dt.Columns[1].ToString();
            ChucVucomboBox.ValueMember = dt.Columns[0].ToString();
        }
        private void Thembutton_Click(object sender, EventArgs e)
        {
            int count = 0;
            count = NhanViendataGridView.Rows.Count; // đếm tất cả các dòng trong dsthuephonggridview rồi đem đi gán cho count
            String ma1 = "NV";
            int ma2;
            if (count == 0) { ma2 = count + 1; }
            else ma2 = count;
            MaNVtextbox.Text = ma1 + ma2.ToString();
            App_config configdb = new App_config();
            String sqlThem = "INSERT INTO Nhanvien (maNV,Username,nameNV,Birth,CMND,gioitinh,diaChi,dienThoai,email,quocTich,bangCap,maCV)";
            sqlThem += " VALUES (N'" + MaNVtextbox.Text + "'";
            sqlThem += ",N'" + UserNametextBox.Text + "'";
            sqlThem += ",N'" + HoTentextBox.Text+"'";
            sqlThem += ", CONVERT(datetime,'" + NgaySinhdateTime.Text + "',103)";
            sqlThem += ",N'" + CMNDtextBox.Text + "'";
            sqlThem += ",N'" + Nucheckbox.Checked + "'";
            sqlThem += ",N'" + DiaChitextBox.Text + "'";
            sqlThem += ",N'" + DienThoaitextBox.Text + "'";
            sqlThem += ",N'" + EmailtextBox.Text + "'";
            sqlThem += ",N'" + QuocTichtextBox.Text + "'";
            sqlThem += ",N'" + BangCaptextBox.Text + "'";
            sqlThem += ",'" + ChucVucomboBox.SelectedValue + "'";
            sqlThem += ")";

            int sosanhdulieu = configdb.InsertDb(sqlThem);
            if(sosanhdulieu==0)
            {
                MessageBox.Show("Không thêm được dữ liệu");
            }    
            else if (sosanhdulieu == -1)
            {
                MessageBox.Show("Lỗi không kết nối dữ liệu");
            }
            else
            {
                MessageBox.Show("Đã thêm dữ liệu thành công");
                //HienThiGridView();
                FormNhanVien_Load(sender, e);
            }

        }

        private void Suabutton_Click(object sender, EventArgs e)
        {
            App_config app = new App_config();
            String sql = " Update Nhanvien set nameNV=N'" + HoTentextBox.Text + "'WHERE maNV=N'" + MaNVtextbox.Text + "'";
            sql += " Update Nhanvien set Birth= CONVERT(DATETIME,'" + NgaySinhdateTime.Text + "',103) WHERE maNV=N'" + MaNVtextbox.Text + "'";
            sql += " Update Nhanvien set CMND=N'" + CMNDtextBox.Text + "'WHERE(maNV=N'" + MaNVtextbox.Text + "')";
            sql += " Update Nhanvien set gioitinh=N'" + Nucheckbox.Checked + "'WHERE(maNV=N'" + MaNVtextbox.Text + "')";
            sql += " Update Nhanvien set diaChi=N'" + DiaChitextBox.Text + "'WHERE(maNV=N'" + MaNVtextbox.Text + "')";
            sql += " Update Nhanvien set dienThoai=N'" + DienThoaitextBox.Text + "'WHERE(maNV=N'" + MaNVtextbox.Text + "')";
            sql += " Update Nhanvien set email=N'" + EmailtextBox.Text + "'WHERE(maNV=N'" + MaNVtextbox.Text + "')";
            sql += " Update Nhanvien set quocTich=N'" + QuocTichtextBox.Text + "'WHERE(maNV=N'" + MaNVtextbox.Text + "')";
            sql += " Update Nhanvien set bangCap=N'" + BangCaptextBox.Text + "'WHERE(maNV=N'" + MaNVtextbox.Text + "')";
            sql += " Update Nhanvien set maCV=N'" + ChucVucomboBox.Text + "'WHERE(maNV=N'" + MaNVtextbox.Text + "')";
            app.UpdateDB(sql);
            HienThiGridView();
        }

        private void NhanViendataGridView_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            MaNVtextbox.Text = NhanViendataGridView.CurrentRow.Cells[0].Value.ToString();
            UserNametextBox.Text = NhanViendataGridView.CurrentRow.Cells[1].Value.ToString();
            HoTentextBox.Text = NhanViendataGridView.CurrentRow.Cells[2].Value.ToString();
            int nam = Int32.Parse(NhanViendataGridView.CurrentRow.Cells[3].Value.ToString().Split('/')[2]);
            int thang = Int32.Parse(NhanViendataGridView.CurrentRow.Cells[3].Value.ToString().Split('/')[1]);
            int ngay = Int32.Parse(NhanViendataGridView.CurrentRow.Cells[3].Value.ToString().Split('/')[0]);
            NgaySinhdateTime.Value = new DateTime(nam, thang, ngay);
            CMNDtextBox.Text = NhanViendataGridView.CurrentRow.Cells[4].Value.ToString();
            if (NhanViendataGridView.CurrentRow.Cells[5].Value.ToString().Equals("Nữ"))
            {
                Nucheckbox.Checked = true;
            }
            else
            {
                Nucheckbox.Checked = false;
            }
            DiaChitextBox.Text = NhanViendataGridView.CurrentRow.Cells[6].Value.ToString();
            DienThoaitextBox.Text = NhanViendataGridView.CurrentRow.Cells[7].Value.ToString();
            EmailtextBox.Text = NhanViendataGridView.CurrentRow.Cells[8].Value.ToString();
            QuocTichtextBox.Text = NhanViendataGridView.CurrentRow.Cells[9].Value.ToString();
            BangCaptextBox.Text = NhanViendataGridView.CurrentRow.Cells[10].Value.ToString();
            ChucVucomboBox.Text = NhanViendataGridView.CurrentRow.Cells[11].Value.ToString();
        }

        private void Xoabutton_Click(object sender, EventArgs e)
        {
            App_config app = new App_config();
            if(Xoabutton.Enabled == true)
            {
                DialogResult dialog = MessageBox.Show("Bạn có chắc chắn muốn xóa ", "Thông báo",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialog == DialogResult.Yes)
                {
                    string sql = "Delete Nhanvien where ( maNV = '" + MaNVtextbox.Text + "')";
                    app.DeleteDB(sql);
                    HienThiGridView();
                }
                else
                {
                    dialog = DialogResult.Cancel;
                }    
            }          
        }

        private void NamradioButton_CheckedChanged(object sender, EventArgs e)
        {
            //if (NamradioButton.Checked == true) { gioitinh = true }
           // If Nam.Check = true then GioiTinh = True; 
        }

        private void TimKiembutton_Click(object sender, EventArgs e)
        {
            FormTimKiemNV formTimKiemNV = new FormTimKiemNV();
            formTimKiemNV.ShowDialog();
        }

        private void TroVebutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
