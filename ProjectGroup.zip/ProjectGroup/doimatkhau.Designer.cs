﻿
namespace ProjectGroup
{
    partial class doimatkhau
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btcapnhat = new System.Windows.Forms.Button();
            this.btthoat = new System.Windows.Forms.Button();
            this.txttdn = new System.Windows.Forms.TextBox();
            this.txtmkc = new System.Windows.Forms.TextBox();
            this.txtmkm = new System.Windows.Forms.TextBox();
            this.txtxnmk = new System.Windows.Forms.TextBox();
            this.cpass = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(149, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(183, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "ĐỔI MẬT KHẨU";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(81, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên đăng nhập";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(81, 165);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Mật khẩu cũ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(81, 212);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Mật khẩu mới";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(81, 265);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(156, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Xác nhận mật khẩu mới";
            // 
            // btcapnhat
            // 
            this.btcapnhat.Location = new System.Drawing.Point(88, 373);
            this.btcapnhat.Name = "btcapnhat";
            this.btcapnhat.Size = new System.Drawing.Size(98, 35);
            this.btcapnhat.TabIndex = 5;
            this.btcapnhat.Text = "Cập nhật";
            this.btcapnhat.UseVisualStyleBackColor = true;
            this.btcapnhat.Click += new System.EventHandler(this.btcapnhat_Click);
            // 
            // btthoat
            // 
            this.btthoat.Location = new System.Drawing.Point(291, 373);
            this.btthoat.Name = "btthoat";
            this.btthoat.Size = new System.Drawing.Size(92, 35);
            this.btthoat.TabIndex = 6;
            this.btthoat.Text = "Thoát";
            this.btthoat.UseVisualStyleBackColor = true;
            this.btthoat.Click += new System.EventHandler(this.btthoat_Click);
            // 
            // txttdn
            // 
            this.txttdn.Enabled = false;
            this.txttdn.Location = new System.Drawing.Point(266, 106);
            this.txttdn.Name = "txttdn";
            this.txttdn.Size = new System.Drawing.Size(100, 22);
            this.txttdn.TabIndex = 7;
            // 
            // txtmkc
            // 
            this.txtmkc.Location = new System.Drawing.Point(266, 165);
            this.txtmkc.Name = "txtmkc";
            this.txtmkc.PasswordChar = '*';
            this.txtmkc.Size = new System.Drawing.Size(100, 22);
            this.txtmkc.TabIndex = 8;
            // 
            // txtmkm
            // 
            this.txtmkm.Location = new System.Drawing.Point(266, 212);
            this.txtmkm.Name = "txtmkm";
            this.txtmkm.PasswordChar = '*';
            this.txtmkm.Size = new System.Drawing.Size(100, 22);
            this.txtmkm.TabIndex = 9;
            // 
            // txtxnmk
            // 
            this.txtxnmk.Location = new System.Drawing.Point(266, 265);
            this.txtxnmk.Name = "txtxnmk";
            this.txtxnmk.PasswordChar = '*';
            this.txtxnmk.Size = new System.Drawing.Size(100, 22);
            this.txtxnmk.TabIndex = 10;
            this.txtxnmk.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // cpass
            // 
            this.cpass.AutoSize = true;
            this.cpass.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cpass.Location = new System.Drawing.Point(84, 320);
            this.cpass.Name = "cpass";
            this.cpass.Size = new System.Drawing.Size(129, 21);
            this.cpass.TabIndex = 11;
            this.cpass.Text = "Show Password";
            this.cpass.UseVisualStyleBackColor = true;
            this.cpass.CheckedChanged += new System.EventHandler(this.cpass_CheckedChanged);
            // 
            // doimatkhau
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(439, 450);
            this.Controls.Add(this.cpass);
            this.Controls.Add(this.txtxnmk);
            this.Controls.Add(this.txtmkm);
            this.Controls.Add(this.txtmkc);
            this.Controls.Add(this.txttdn);
            this.Controls.Add(this.btthoat);
            this.Controls.Add(this.btcapnhat);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "doimatkhau";
            this.Text = "Đổi mật khẩu";
            this.Load += new System.EventHandler(this.doimatkhau_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btcapnhat;
        private System.Windows.Forms.Button btthoat;
        private System.Windows.Forms.TextBox txttdn;
        private System.Windows.Forms.TextBox txtmkc;
        private System.Windows.Forms.TextBox txtmkm;
        private System.Windows.Forms.TextBox txtxnmk;
        private System.Windows.Forms.CheckBox cpass;
    }
}