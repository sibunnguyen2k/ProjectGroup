﻿
namespace ProjectGroup
{
    partial class tkhoadon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtgview = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtnmhd = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txttt = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.datetime = new System.Windows.Forms.DateTimePicker();
            this.datetime1 = new System.Windows.Forms.DateTimePicker();
            this.txtmpt = new System.Windows.Forms.TextBox();
            this.txtsp = new System.Windows.Forms.TextBox();
            this.txtmkh = new System.Windows.Forms.TextBox();
            this.txtmnvtt = new System.Windows.Forms.TextBox();
            this.txtmnv = new System.Windows.Forms.TextBox();
            this.txtmhd = new System.Windows.Forms.TextBox();
            this.btthoat = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtgview)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtgview
            // 
            this.dtgview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgview.Location = new System.Drawing.Point(37, 181);
            this.dtgview.Name = "dtgview";
            this.dtgview.RowHeadersWidth = 51;
            this.dtgview.RowTemplate.Height = 24;
            this.dtgview.Size = new System.Drawing.Size(959, 233);
            this.dtgview.TabIndex = 0;
            this.dtgview.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dtgview_CellMouseClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtnmhd);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(37, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(959, 97);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tìm kiếm hóa đơn";
            // 
            // txtnmhd
            // 
            this.txtnmhd.Location = new System.Drawing.Point(350, 46);
            this.txtnmhd.Name = "txtnmhd";
            this.txtnmhd.Size = new System.Drawing.Size(171, 22);
            this.txtnmhd.TabIndex = 1;
            this.txtnmhd.TextChanged += new System.EventHandler(this.txtnmhd_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(192, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nhập mã hóa đơn";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txttt);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.datetime);
            this.groupBox2.Controls.Add(this.datetime1);
            this.groupBox2.Controls.Add(this.txtmpt);
            this.groupBox2.Controls.Add(this.txtsp);
            this.groupBox2.Controls.Add(this.txtmkh);
            this.groupBox2.Controls.Add(this.txtmnvtt);
            this.groupBox2.Controls.Add(this.txtmnv);
            this.groupBox2.Controls.Add(this.txtmhd);
            this.groupBox2.Controls.Add(this.btthoat);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(37, 439);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(959, 224);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thông tin hóa đơn";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(288, 164);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 17);
            this.label10.TabIndex = 19;
            this.label10.Text = "Tổng tiền";
            // 
            // txttt
            // 
            this.txttt.Location = new System.Drawing.Point(374, 159);
            this.txttt.Name = "txttt";
            this.txttt.Size = new System.Drawing.Size(148, 22);
            this.txttt.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(551, 58);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 17);
            this.label9.TabIndex = 17;
            this.label9.Text = "Ngày đến";
            // 
            // datetime
            // 
            this.datetime.CustomFormat = "dd/MM/yyyy";
            this.datetime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datetime.Location = new System.Drawing.Point(673, 53);
            this.datetime.Name = "datetime";
            this.datetime.Size = new System.Drawing.Size(200, 22);
            this.datetime.TabIndex = 16;
            // 
            // datetime1
            // 
            this.datetime1.CustomFormat = "dd/MM/yyyy";
            this.datetime1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datetime1.Location = new System.Drawing.Point(673, 92);
            this.datetime1.Name = "datetime1";
            this.datetime1.Size = new System.Drawing.Size(200, 22);
            this.datetime1.TabIndex = 15;
            // 
            // txtmpt
            // 
            this.txtmpt.Location = new System.Drawing.Point(124, 114);
            this.txtmpt.Name = "txtmpt";
            this.txtmpt.Size = new System.Drawing.Size(138, 22);
            this.txtmpt.TabIndex = 14;
            // 
            // txtsp
            // 
            this.txtsp.Location = new System.Drawing.Point(673, 139);
            this.txtsp.Name = "txtsp";
            this.txtsp.Size = new System.Drawing.Size(200, 22);
            this.txtsp.TabIndex = 13;
            // 
            // txtmkh
            // 
            this.txtmkh.Location = new System.Drawing.Point(374, 53);
            this.txtmkh.Name = "txtmkh";
            this.txtmkh.Size = new System.Drawing.Size(132, 22);
            this.txtmkh.TabIndex = 12;
            // 
            // txtmnvtt
            // 
            this.txtmnvtt.Location = new System.Drawing.Point(127, 164);
            this.txtmnvtt.Name = "txtmnvtt";
            this.txtmnvtt.Size = new System.Drawing.Size(135, 22);
            this.txtmnvtt.TabIndex = 11;
            // 
            // txtmnv
            // 
            this.txtmnv.Location = new System.Drawing.Point(374, 109);
            this.txtmnv.Name = "txtmnv";
            this.txtmnv.Size = new System.Drawing.Size(132, 22);
            this.txtmnv.TabIndex = 10;
            // 
            // txtmhd
            // 
            this.txtmhd.Location = new System.Drawing.Point(124, 48);
            this.txtmhd.Name = "txtmhd";
            this.txtmhd.Size = new System.Drawing.Size(138, 22);
            this.txtmhd.TabIndex = 9;
            // 
            // btthoat
            // 
            this.btthoat.Location = new System.Drawing.Point(827, 184);
            this.btthoat.Name = "btthoat";
            this.btthoat.Size = new System.Drawing.Size(90, 29);
            this.btthoat.TabIndex = 8;
            this.btthoat.Text = "Thoát";
            this.btthoat.UseVisualStyleBackColor = true;
            this.btthoat.Click += new System.EventHandler(this.btthoat_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(551, 144);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 17);
            this.label8.TabIndex = 6;
            this.label8.Text = "Số phòng";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(551, 97);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(113, 17);
            this.label7.TabIndex = 5;
            this.label7.Text = "Ngày thanh toán";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(34, 164);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 17);
            this.label6.TabIndex = 4;
            this.label6.Text = "Mã NVTT";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 114);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 17);
            this.label5.TabIndex = 3;
            this.label5.Text = "Mã PT";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(288, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 17);
            this.label4.TabIndex = 2;
            this.label4.Text = "Mã NV";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(297, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 17);
            this.label3.TabIndex = 1;
            this.label3.Text = "Mã KH";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Mã HĐ";
            // 
            // tkhoadon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1037, 686);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dtgview);
            this.Name = "tkhoadon";
            this.Text = "Tìm kiếm hóa đơn";
            this.Load += new System.EventHandler(this.qlhoadon_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgview)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dtgview;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtnmhd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker datetime1;
        private System.Windows.Forms.TextBox txtmpt;
        private System.Windows.Forms.TextBox txtsp;
        private System.Windows.Forms.TextBox txtmkh;
        private System.Windows.Forms.TextBox txtmnvtt;
        private System.Windows.Forms.TextBox txtmnv;
        private System.Windows.Forms.TextBox txtmhd;
        private System.Windows.Forms.Button btthoat;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker datetime;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txttt;
    }
}