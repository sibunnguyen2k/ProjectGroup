﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class hoadonsddv : Form
    {
        public hoadonsddv()
        {
            InitializeComponent();
            HienThiGridView();
            hienthigrid1();
            
        }
        private void griddichvu_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtmadv.Text = griddichvu.CurrentRow.Cells[0].Value.ToString();
            txttendv.Text = griddichvu.CurrentRow.Cells[1].Value.ToString();
            txtdonvi.Text = griddichvu.CurrentRow.Cells[3].Value.ToString();
            txtgia.Text = griddichvu.CurrentRow.Cells[2].Value.ToString();
        }
        public void hienthigrid1()
        {
            DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "maHDDV";
            column.HeaderText = "Mã HDDV";
            gridndhddv.Columns.Add(column);

            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "maloaiDV";
            column1.HeaderText = "Mã Loại DV";
            gridndhddv.Columns.Add(column1);

            

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "soluong";
            column3.HeaderText = "Số Lượng";
            gridndhddv.Columns.Add(column3);

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "tinhtien";
            column4.HeaderText = "Tiền DV";
            gridndhddv.Columns.Add(column4);

           
        }

        public void HienThiGridView()
        {

            DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "maloaiDV";
            column.HeaderText = "Mã Dịch Vụ";
            griddichvu.Columns.Add(column);

            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "tenDV";
            column1.HeaderText = "Tên Dịch Vụ";
            griddichvu.Columns.Add(column1);

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "donGia";
            column2.HeaderText = "Đơn Giá";
            griddichvu.Columns.Add(column2);

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "donVi";
            column3.HeaderText = "Đơn vị";
            griddichvu.Columns.Add(column3);


        }

        private void hoadonsddv_Load(object sender, EventArgs e)
        {
            App_config configdb = new App_config();
            DataTable dt = new DataTable();
            String sql = " SELECT maloaiDV,tenDV,donGia,donVi FROM loaiDV";
            dt = configdb.SelectDb(sql);
            griddichvu.DataSource = dt;

            DataTable td = new DataTable();
            App_config config = new App_config();
            String sql1 = "SELECT  maHDDV, maloaiDV,soluong,tinhtien";
            sql1 += " FROM Dichvu";
            sql1 += " WHERE maHDDV = '" + txtmahddv.Text + "'";
            td = config.SelectDb(sql1);
            
            gridndhddv.DataSource = td;
            toti();
        }
        String chuoi = "";
        public hoadonsddv(string str) :this()
        {
            chuoi = str;
            txtmahddv.Text = chuoi.ToString();
        }
        //private void load()
        //{
        //    DataTable dt = new DataTable();
        //    dt.Columns.Add("tinhtien", typeof(int));
        //    gridndhddv.DataSource = dt;
        //}
        public void toti()
        {
            int tt = gridndhddv.Rows.Count;
            int ttien = 0;
            for(int i=0;i<tt-1;i++)
            {
                ttien += int.Parse(gridndhddv.Rows[i].Cells[3].Value.ToString());
            }
            txttongtien.Text = ttien.ToString();
        }
        private void btchon_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            App_config configdb = new App_config();
            String sql = "INSERT INTO Dichvu ( maHDDV,maloaiDV,soluong, tinhtien )";
            sql += " VALUES( N'" + txtmahddv.Text + "'";
            sql += ",N'" + txtmadv.Text + "'";
            sql += ",'" + txtsoluong.Text + "'";
            sql += ",'" + txtsotien.Text + "' ";
            sql += ")";

            
           
            configdb.InsertDb(sql);
            hoadonsddv_Load(sender, e);
            
        }
        public void tinhtien()
        {
            App_config app = new App_config();
            DataTable dt = new DataTable();
            int gia = Convert.ToInt32(txtgia.Text);
            int sl = Convert.ToInt32(txtsoluong.Text);
            int tongtien = gia * sl;
            txtsotien.Text = tongtien.ToString();

        }
        private void bttinhtien_Click(object sender, EventArgs e)
        {
            tinhtien();
            //DataTable dt = new DataTable();
            //dt.Rows.Add(txtsotien.Text);
            //gridndhddv.DataSource = dt;
        }

        private void btbochon_Click(object sender, EventArgs e)
        {
            App_config app = new App_config();
            if(btbochon.Enabled == true)
            {
                DialogResult dialog = MessageBox.Show("Bạn có chắc chắn bỏ sản phẩm  này!!", "Thông báo",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if(dialog == DialogResult.Yes)
                {
                    String sql = "DELETE Dichvu WHERE (maloaiDV = '" + txtmadv.Text + "')";
                    app.DeleteDB(sql);
                    hoadonsddv_Load(sender, e);
                }
                else
                {
                    dialog = DialogResult.Cancel;
                }
            }
        }

        private void btthoat_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void gridndhddv_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtmahddv.Text = gridndhddv.CurrentRow.Cells[0].Value.ToString();
            txtmadv.Text = gridndhddv.CurrentRow.Cells[1].Value.ToString();
            txtsoluong.Text = gridndhddv.CurrentRow.Cells[2].Value.ToString();
            txtsotien.Text = gridndhddv.CurrentRow.Cells[3].Value.ToString();
        }

        private void btluuhd_Click(object sender, EventArgs e)
        {
            string sql = "Update hoadondv set tongdoanhthudv = '" + txttongtien.Text + "' WHERE maHDDV = N'"+txtmahddv.Text+"'" ;
            App_config app = new App_config();
            app.UpdateDB(sql);
                }
    }
}
