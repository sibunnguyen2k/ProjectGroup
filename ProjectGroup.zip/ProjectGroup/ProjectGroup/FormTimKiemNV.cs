﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectGroup
{
    public partial class FormTimKiemNV : Form
    {
        public FormTimKiemNV()
        {
            InitializeComponent();
        }
        public void LoadGridByKeyword()
        {
            App_config app = new App_config();
            TimKiemdataGridView.DataSource = app.SelectDb(" SELECT * FROM Nhanvien WHERE nameNV like '%"+TKtextBox.Text+"%' ");
        }
        private void TKbutton_Click(object sender, EventArgs e)
        {
            LoadGridByKeyword();
        }

        public void FormTimKiemNV_Load(object sender, EventArgs e)
        {
        
        }

        private void TKtextBox_TextChanged(object sender, EventArgs e)
        {
            LoadGridByKeyword();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void TimKiemdataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
