﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace ProjectGroup
{
    public partial class FormDangNhap : Form
    {
        public FormDangNhap()
        {
            InitializeComponent();
        }

        private void btdangnhap_Click(object sender, EventArgs e)
        {
            App_config app = new App_config();
            String connection = ConfigurationManager.ConnectionStrings["ProjectGroup.Properties.Settings.QLKSGroupConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(connection); //tạo thể hiện của kết nối đến database
            try
            {
                con.Open();
                string sql = "select Username, password from Taikhoan where Username =N'" + txtttk.Text + "' and password = '" + txtmk.Text + "'";
                SqlCommand cmd = new SqlCommand(sql, con);              //khởi tạo lệnh kết nối câu truy vấn csdl
                DataTable tb = new DataTable();                         //tạo thể hiên của datatable
                SqlDataReader dt = cmd.ExecuteReader();                 //tạo thể hiện để đọc dữ liệu trong database
                //DataTable tb1 = new DataTable();
                if (dt.Read() == true)
                {
                    sql = "select maNV from Nhanvien where Username =N'" + txtttk.Text + "'";
                    tb = app.SelectDb(sql);
                   
                    //    MessageBox.Show("Đăng nhập thành công");
                    mainform mf = new mainform(tb.Rows[0][0].ToString());
                    mainformNV mf1 = new mainformNV(tb.Rows[0][0].ToString());
                    String sqlTK = "Select LoaiTk from Taikhoan where Username ='"+ txtttk.Text+"'";
                    tb = app.SelectDb(sqlTK);
                    string loaitk = tb.Rows[0][0].ToString();
                    if (loaitk == "NV")
                    {
                        mf1.Show();
                    }
                    //if(loaitk == "QL")
                    else
                    {
                        mf.Show();
                    }   
                    this.Hide(); // ẩn form phía trc
                }
                else
                {
                    MessageBox.Show("Tên đăng nhập hoặc mật khẩu sai", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối ");
                con.Close();
            }
        }

        private void ckpw_CheckedChanged(object sender, EventArgs e)
        {
            //cách 1 UseSystemPassChar để về true
            //if (ckpw.Checked)
            //{
            //    txtmk.UseSystemPasswordChar = false;
            //}
            //else
            //{
            //    txtmk.UseSystemPasswordChar = true;
            //}

            //cách 2 để PasswordChar theo ý
            if (ckpw.Checked)
            {
                txtmk.PasswordChar = '*';
                txtmk.BringToFront();
                txtmk.PasswordChar = '\0';
            }
            else
            {
                txtmk.PasswordChar = '\0';
                txtmk.BringToFront();
                txtmk.PasswordChar = '*';
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
          
        }

        private void label4_MouseClick(object sender, MouseEventArgs e)
        {
            //frmqmk fr = new frmqmk();
            //fr.Show();
            //this.Hide();
            

          // MessageBox.Show("Liên hệ trực tiếp với lễ tân khách sạn", "Thông báo",MessageBoxButtons.OK,MessageBoxIcon.Error);
            
        }

        private void btthoat_Click(object sender, EventArgs e)
        {
           if( MessageBox.Show("Bạn có chắc muốn thoát!", "Thông báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Error) == DialogResult.Yes);
            this.Close();
        }
    }
}
